/**
 * Email Templates
 *
 * Plain functions, not a template-engine dependency — each returns
 * `{ subject, html }` given the data it needs. Kept minimal/inline
 * HTML (no external CSS, since most email clients strip <link> tags
 * anyway); a design-system-matched HTML template is a natural
 * frontend-adjacent follow-up, not a backend integration concern.
 */

function wrapper(bodyHtml: string): string {
  return `
    <div style="font-family: -apple-system, sans-serif; max-width: 480px; margin: 0 auto; padding: 24px;">
      <h2 style="color: #111;">Shemixs</h2>
      ${bodyHtml}
      <p style="color: #888; font-size: 12px; margin-top: 32px;">This is an automated message from Shemixs EduOS.</p>
    </div>
  `;
}

export const emailTemplates = {
  passwordReset(resetUrl: string) {
    return {
      subject: 'Reset your Shemixs password',
      html: wrapper(`
        <p>We received a request to reset your password. This link expires in 1 hour.</p>
        <p><a href="${resetUrl}" style="background:#111;color:#fff;padding:10px 20px;border-radius:6px;text-decoration:none;">Reset Password</a></p>
        <p>If you didn't request this, you can safely ignore this email.</p>
      `),
    };
  },

  admissionStatusUpdate(applicantName: string, status: string, note?: string) {
    return {
      subject: `Your admission application: ${status}`,
      html: wrapper(`
        <p>Hi ${applicantName},</p>
        <p>Your admission application status has been updated to <strong>${status}</strong>.</p>
        ${note ? `<p>${note}</p>` : ''}
      `),
    };
  },

  resultPublished(studentName: string, testTitle: string) {
    return {
      subject: `Results published: ${testTitle}`,
      html: wrapper(`
        <p>Hi ${studentName},</p>
        <p>Results for <strong>${testTitle}</strong> have been published. Log in to your portal to view them.</p>
      `),
    };
  },

  paymentReceipt(studentName: string, amountRupees: number, receiptNumber: string) {
    return {
      subject: `Payment receipt — ${receiptNumber}`,
      html: wrapper(`
        <p>Hi ${studentName},</p>
        <p>We've received your payment of <strong>₹${amountRupees.toFixed(2)}</strong>.</p>
        <p>Receipt number: ${receiptNumber}</p>
      `),
    };
  },

  certificateIssued(studentName: string, certificateTitle: string, verificationCode: string) {
    return {
      subject: `Certificate issued: ${certificateTitle}`,
      html: wrapper(`
        <p>Hi ${studentName},</p>
        <p>Your certificate <strong>${certificateTitle}</strong> has been issued.</p>
        <p>Verification code: <code>${verificationCode}</code></p>
      `),
    };
  },
};
