import { getMailTransporter, getMailFromAddress } from './email.config';
import { logger } from '../lib/logger';

export interface SendEmailInput {
  to: string;
  subject: string;
  html: string;
}

export const emailService = {
  async send(input: SendEmailInput): Promise<{ success: boolean; error?: string }> {
    try {
      const transporter = getMailTransporter();
      await transporter.sendMail({
        from: getMailFromAddress(),
        to: input.to,
        subject: input.subject,
        html: input.html,
      });
      return { success: true };
    } catch (error) {
      logger.error('Email send failed', { error, to: input.to, subject: input.subject });
      return { success: false, error: error instanceof Error ? error.message : 'Unknown email error' };
    }
  },
};
