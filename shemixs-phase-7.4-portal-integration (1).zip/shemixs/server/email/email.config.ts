/**
 * Email (SMTP) Config
 *
 * Uses `nodemailer` against generic SMTP settings (MAIL_HOST/PORT/
 * USER/PASSWORD — the exact env vars Phase 7.1 already reserved),
 * rather than a provider-specific SDK (SendGrid/Resend/etc). This
 * keeps the integration provider-agnostic: any SMTP-speaking service
 * (Gmail, SES, Mailgun, Postmark, a self-hosted relay) works by
 * changing only the env vars, no code changes.
 */
import nodemailer, { type Transporter } from 'nodemailer';
import { z } from 'zod';

const mailEnvSchema = z.object({
  MAIL_HOST: z.string().min(1, 'MAIL_HOST is required'),
  MAIL_PORT: z.coerce.number().int().positive(),
  MAIL_USER: z.string().min(1, 'MAIL_USER is required'),
  MAIL_PASSWORD: z.string().min(1, 'MAIL_PASSWORD is required'),
  MAIL_FROM: z.string().min(1).default('Shemixs <no-reply@shemixs.com>'),
});

let transporter: Transporter | null = null;
let fromAddress: string | null = null;

export function getMailTransporter(): Transporter {
  if (!transporter) {
    const parsed = mailEnvSchema.safeParse(process.env);
    if (!parsed.success) {
      const issues = parsed.error.issues.map((i) => `  - ${i.path.join('.')}: ${i.message}`).join('\n');
      throw new Error(`Invalid email (SMTP) configuration:\n${issues}`);
    }

    transporter = nodemailer.createTransport({
      host: parsed.data.MAIL_HOST,
      port: parsed.data.MAIL_PORT,
      secure: parsed.data.MAIL_PORT === 465, // implicit TLS on 465, STARTTLS otherwise
      auth: { user: parsed.data.MAIL_USER, pass: parsed.data.MAIL_PASSWORD },
    });
    fromAddress = parsed.data.MAIL_FROM;
  }
  return transporter;
}

export function getMailFromAddress(): string {
  if (!fromAddress) {
    // Ensures getMailTransporter() (which sets fromAddress) has run.
    getMailTransporter();
  }
  return fromAddress as string;
}
