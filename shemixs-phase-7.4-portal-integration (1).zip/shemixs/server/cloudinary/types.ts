import type { MediaResourceType } from '@prisma/client';
import type { MediaCategoryKey } from './categories';

/** Normalized shape our services return, independent of Cloudinary's raw API response shape. */
export interface CloudinaryUploadResult {
  publicId: string;
  secureUrl: string;
  resourceType: MediaResourceType;
  format?: string;
  width?: number;
  height?: number;
  duration?: number;
  bytes: number;
}

export interface UploadMediaInput {
  category: MediaCategoryKey;
  entityType?: string;
  entityId?: string;
  /** Base64 data URI or a remote URL — both are valid Cloudinary upload sources. */
  file: string;
  filename?: string;
}
