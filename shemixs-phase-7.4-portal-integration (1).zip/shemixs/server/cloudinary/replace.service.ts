import { withTransaction } from '../db/transaction';
import { mediaRepository } from '../repositories/media.repository';
import { auditLogService } from '../services/audit-log.service';
import { cloudinaryService } from './cloudinary.service';
import { getMediaCategoryConfig } from './categories';
import { validateFile } from './validators';
import { NotFoundError } from '../lib/errors';
import type { ControllerContext } from '../controllers/base.controller';
import type { MediaCategoryKey } from './categories';

export const replaceService = {
  /**
   * Replaces the file behind an existing Media row: uploads the new
   * file, then deletes the old Cloudinary asset, then updates the
   * same row (same id, same entity link — callers don't need to
   * re-attach the media to its owner). The new upload happens BEFORE
   * the old one is destroyed so a failed upload never leaves the
   * entity with no image at all.
   */
  async replace(mediaId: string, file: File, ctx: ControllerContext) {
    const existing = await mediaRepository.findById(mediaId);
    if (!existing) throw new NotFoundError('Media not found');

    const category = existing.category as MediaCategoryKey;
    validateFile(file, category);
    const config = getMediaCategoryConfig(category);

    const arrayBuffer = await file.arrayBuffer();
    const buffer = Buffer.from(arrayBuffer);

    const uploaded = await cloudinaryService.uploadBuffer(buffer, {
      folder: config.folder,
      resourceType: config.resourceType,
    });

    // Old asset is deleted after the new one is safely uploaded.
    // Best-effort: if this fails we still proceed — an orphaned old
    // asset is a cheaper problem than losing the new upload.
    try {
      await cloudinaryService.destroy(existing.publicId, existing.resourceType);
    } catch {
      // logged inside cloudinaryService.destroy already
    }

    return withTransaction(async (tx) => {
      const updated = await mediaRepository.update(
        mediaId,
        {
          publicId: uploaded.publicId,
          secureUrl: uploaded.secureUrl,
          resourceType: uploaded.resourceType,
          format: uploaded.format,
          width: uploaded.width,
          height: uploaded.height,
          duration: uploaded.duration,
          bytes: uploaded.bytes,
        },
        tx
      );

      await auditLogService.record(
        {
          userId: ctx.userId,
          userRole: ctx.role,
          module: 'media',
          action: 'UPDATE',
          entityId: mediaId,
          before: existing,
          after: updated,
          meta: ctx.meta,
        },
        tx
      );

      return updated;
    });
  },
};
