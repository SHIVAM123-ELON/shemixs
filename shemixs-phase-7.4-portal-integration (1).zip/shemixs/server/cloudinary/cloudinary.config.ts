/**
 * Cloudinary Config
 *
 * Configures the official Cloudinary Node SDK once, lazily, the first
 * time any cloudinary module function runs. Kept separate from
 * `server/lib/env.ts`'s `getEnv()` so the rest of the app (auth, the
 * 15 Phase 7.2 modules) never fails to boot just because Cloudinary
 * credentials aren't set — only code that actually touches media
 * requires them.
 */
import { v2 as cloudinary } from 'cloudinary';
import { z } from 'zod';

const cloudinaryEnvSchema = z.object({
  CLOUDINARY_CLOUD_NAME: z.string().min(1, 'CLOUDINARY_CLOUD_NAME is required'),
  CLOUDINARY_API_KEY: z.string().min(1, 'CLOUDINARY_API_KEY is required'),
  CLOUDINARY_API_SECRET: z.string().min(1, 'CLOUDINARY_API_SECRET is required'),
});

let configured = false;

/** Validates Cloudinary env vars and configures the SDK exactly once. Throws a clear error if credentials are missing. */
export function getCloudinaryClient() {
  if (!configured) {
    const parsed = cloudinaryEnvSchema.safeParse(process.env);
    if (!parsed.success) {
      const issues = parsed.error.issues.map((i) => `  - ${i.path.join('.')}: ${i.message}`).join('\n');
      throw new Error(`Invalid Cloudinary configuration:\n${issues}`);
    }

    cloudinary.config({
      cloud_name: parsed.data.CLOUDINARY_CLOUD_NAME,
      api_key: parsed.data.CLOUDINARY_API_KEY,
      api_secret: parsed.data.CLOUDINARY_API_SECRET,
      secure: true, // always issue https URLs
    });
    configured = true;
  }

  return cloudinary;
}
