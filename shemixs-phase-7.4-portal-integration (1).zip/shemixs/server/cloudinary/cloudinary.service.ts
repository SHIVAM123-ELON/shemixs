/**
 * Cloudinary Service (low-level)
 *
 * The only module that calls the `cloudinary` package directly.
 * Upload/delete/replace services above this call these functions
 * rather than touching the SDK, so a future SDK version bump or
 * provider swap touches one file.
 */
import { getCloudinaryClient } from './cloudinary.config';
import type { MediaResourceType } from '@prisma/client';
import type { CloudinaryUploadResult } from './types';
import { logger } from '../lib/logger';

function toCloudinaryResourceType(type: MediaResourceType): 'image' | 'video' | 'raw' {
  if (type === 'IMAGE') return 'image';
  if (type === 'VIDEO') return 'video';
  return 'raw';
}

function fromCloudinaryResourceType(type: string): MediaResourceType {
  if (type === 'image') return 'IMAGE';
  if (type === 'video') return 'VIDEO';
  return 'RAW';
}

export const cloudinaryService = {
  /**
   * Uploads a buffer via Cloudinary's upload_stream (avoids base64
   * inflation of large video/PDF payloads that a data-URI upload
   * would incur).
   */
  async uploadBuffer(
    buffer: Buffer,
    options: { folder: string; resourceType: MediaResourceType; publicId?: string; overwrite?: boolean }
  ): Promise<CloudinaryUploadResult> {
    const cloudinary = getCloudinaryClient();

    return new Promise((resolve, reject) => {
      const stream = cloudinary.uploader.upload_stream(
        {
          folder: options.folder,
          resource_type: toCloudinaryResourceType(options.resourceType),
          public_id: options.publicId,
          overwrite: options.overwrite ?? false,
          // Automatic format/quality optimization for images — the
          // spec's "Automatic Compression" / "Automatic Format
          // Selection" requirements.
          ...(options.resourceType === 'IMAGE' ? { quality: 'auto', fetch_format: 'auto' } : {}),
        },
        (error, result) => {
          if (error || !result) {
            logger.error('Cloudinary upload failed', { error });
            return reject(error ?? new Error('Cloudinary upload returned no result'));
          }
          resolve({
            publicId: result.public_id,
            secureUrl: result.secure_url,
            resourceType: fromCloudinaryResourceType(result.resource_type),
            format: result.format,
            width: result.width,
            height: result.height,
            duration: result.duration,
            bytes: result.bytes,
          });
        }
      );
      stream.end(buffer);
    });
  },

  async destroy(publicId: string, resourceType: MediaResourceType): Promise<void> {
    const cloudinary = getCloudinaryClient();
    const result = await cloudinary.uploader.destroy(publicId, {
      resource_type: toCloudinaryResourceType(resourceType),
    });
    if (result.result !== 'ok' && result.result !== 'not found') {
      logger.error('Cloudinary destroy failed', { publicId, result });
      throw new Error(`Cloudinary delete failed for ${publicId}: ${result.result}`);
    }
  },

  /**
   * Generates a signature for **signed client-side uploads** — lets
   * the frontend upload directly to Cloudinary (skipping our server
   * for the file bytes themselves, useful for large videos) while
   * still proving the upload was authorized by us. The API secret
   * never reaches the browser; only the resulting signature does.
   */
  generateUploadSignature(params: Record<string, string | number>): { signature: string; timestamp: number; apiKey: string; cloudName: string } {
    const cloudinary = getCloudinaryClient();
    const timestamp = Math.round(Date.now() / 1000);

    const signature = cloudinary.utils.api_sign_request(
      { ...params, timestamp },
      cloudinary.config().api_secret as string
    );

    return {
      signature,
      timestamp,
      apiKey: cloudinary.config().api_key as string,
      cloudName: cloudinary.config().cloud_name as string,
    };
  },

  /** Optimized/responsive delivery URL — auto format + quality + a requested width for responsive images. */
  buildResponsiveUrl(publicId: string, width?: number): string {
    const cloudinary = getCloudinaryClient();
    return cloudinary.url(publicId, {
      secure: true,
      quality: 'auto',
      fetch_format: 'auto',
      ...(width ? { width, crop: 'scale' } : {}),
    });
  },
};
