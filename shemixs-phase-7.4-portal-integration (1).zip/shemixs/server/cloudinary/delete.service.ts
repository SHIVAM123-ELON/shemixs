import { withTransaction } from '../db/transaction';
import { mediaRepository } from '../repositories/media.repository';
import { auditLogService } from '../services/audit-log.service';
import { cloudinaryService } from './cloudinary.service';
import { NotFoundError } from '../lib/errors';
import type { ControllerContext } from '../controllers/base.controller';

export const deleteService = {
  async deleteOne(mediaId: string, ctx: ControllerContext) {
    const media = await mediaRepository.findById(mediaId);
    if (!media) throw new NotFoundError('Media not found');

    // Delete from Cloudinary first — if this throws, the DB row is
    // left untouched (nothing to roll back) rather than ending up
    // pointing at an asset that no longer exists.
    await cloudinaryService.destroy(media.publicId, media.resourceType);

    return withTransaction(async (tx) => {
      await mediaRepository.softDelete(mediaId, tx);
      await auditLogService.record(
        { userId: ctx.userId, userRole: ctx.role, module: 'media', action: 'DELETE', entityId: mediaId, before: media, meta: ctx.meta },
        tx
      );
    });
  },

  async deleteBulk(mediaIds: string[], ctx: ControllerContext) {
    const items = await mediaRepository.findByIds(mediaIds);
    if (items.length === 0) throw new NotFoundError('No matching media found');

    // Best-effort per-item Cloudinary delete — one failing asset
    // shouldn't block deleting the rest. Failures are collected and
    // returned so the caller knows what didn't clean up remotely.
    const failures: string[] = [];
    for (const item of items) {
      try {
        await cloudinaryService.destroy(item.publicId, item.resourceType);
      } catch {
        failures.push(item.publicId);
      }
    }

    const succeededIds = items.filter((i) => !failures.includes(i.publicId)).map((i) => i.id);

    await withTransaction(async (tx) => {
      if (succeededIds.length > 0) {
        await mediaRepository.softDeleteMany(succeededIds, tx);
      }
      await auditLogService.record(
        {
          userId: ctx.userId,
          userRole: ctx.role,
          module: 'media',
          action: 'DELETE',
          after: { requested: mediaIds.length, deleted: succeededIds.length, failed: failures.length },
          meta: ctx.meta,
        },
        tx
      );
    });

    return { deleted: succeededIds.length, failed: failures };
  },
};
