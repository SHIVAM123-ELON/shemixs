/**
 * Media Category Registry
 *
 * The single source of truth mapping each media purpose (spec's
 * "Media Types" list) to: its Cloudinary folder, its Cloudinary
 * resource type, and its validation rules (allowed MIME types, max
 * size). Every upload/replace call is required to name a category
 * from this list — this is what makes "Cloudinary Folder Structure"
 * from the spec automatic rather than something callers have to get
 * right themselves.
 */
import type { MediaResourceType } from '@prisma/client';

export type MediaCategoryKey =
  | 'profile-student'
  | 'profile-parent'
  | 'profile-teacher'
  | 'profile-admin'
  | 'course-thumbnail'
  | 'course-video'
  | 'demo-video'
  | 'live-class-recording'
  | 'blog-image'
  | 'gallery-image'
  | 'cms-image'
  | 'certificate-image'
  | 'certificate-document'
  | 'notes-document'
  | 'homework-document'
  | 'assignment-document'
  | 'other-document';

export interface MediaCategoryConfig {
  /** Cloudinary folder path — matches the spec's folder strategy example. */
  folder: string;
  resourceType: MediaResourceType;
  /** MIME type allow-list. */
  allowedMimeTypes: string[];
  maxBytes: number;
}

const MB = 1024 * 1024;

const IMAGE_MIME_TYPES = ['image/jpeg', 'image/png', 'image/webp', 'image/gif'];
const VIDEO_MIME_TYPES = ['video/mp4', 'video/webm', 'video/quicktime'];
const PDF_MIME_TYPES = ['application/pdf'];

export const MEDIA_CATEGORIES: Record<MediaCategoryKey, MediaCategoryConfig> = {
  'profile-student': { folder: 'profiles/students', resourceType: 'IMAGE', allowedMimeTypes: IMAGE_MIME_TYPES, maxBytes: 5 * MB },
  'profile-parent': { folder: 'profiles/parents', resourceType: 'IMAGE', allowedMimeTypes: IMAGE_MIME_TYPES, maxBytes: 5 * MB },
  'profile-teacher': { folder: 'profiles/teachers', resourceType: 'IMAGE', allowedMimeTypes: IMAGE_MIME_TYPES, maxBytes: 5 * MB },
  'profile-admin': { folder: 'profiles/admins', resourceType: 'IMAGE', allowedMimeTypes: IMAGE_MIME_TYPES, maxBytes: 5 * MB },

  'course-thumbnail': { folder: 'courses/thumbnails', resourceType: 'IMAGE', allowedMimeTypes: IMAGE_MIME_TYPES, maxBytes: 5 * MB },
  'course-video': { folder: 'courses/videos', resourceType: 'VIDEO', allowedMimeTypes: VIDEO_MIME_TYPES, maxBytes: 500 * MB },
  'demo-video': { folder: 'courses/videos/demo', resourceType: 'VIDEO', allowedMimeTypes: VIDEO_MIME_TYPES, maxBytes: 500 * MB },
  'live-class-recording': { folder: 'courses/videos/live-classes', resourceType: 'VIDEO', allowedMimeTypes: VIDEO_MIME_TYPES, maxBytes: 1024 * MB },

  'blog-image': { folder: 'blog', resourceType: 'IMAGE', allowedMimeTypes: IMAGE_MIME_TYPES, maxBytes: 5 * MB },
  'gallery-image': { folder: 'gallery', resourceType: 'IMAGE', allowedMimeTypes: IMAGE_MIME_TYPES, maxBytes: 10 * MB },
  'cms-image': { folder: 'cms', resourceType: 'IMAGE', allowedMimeTypes: IMAGE_MIME_TYPES, maxBytes: 5 * MB },
  'certificate-image': { folder: 'certificates', resourceType: 'IMAGE', allowedMimeTypes: IMAGE_MIME_TYPES, maxBytes: 5 * MB },
  'certificate-document': { folder: 'certificates', resourceType: 'RAW', allowedMimeTypes: PDF_MIME_TYPES, maxBytes: 10 * MB },

  'notes-document': { folder: 'notes', resourceType: 'RAW', allowedMimeTypes: PDF_MIME_TYPES, maxBytes: 20 * MB },
  'homework-document': { folder: 'homework', resourceType: 'RAW', allowedMimeTypes: PDF_MIME_TYPES, maxBytes: 20 * MB },
  'assignment-document': { folder: 'assignments', resourceType: 'RAW', allowedMimeTypes: PDF_MIME_TYPES, maxBytes: 20 * MB },
  'other-document': { folder: 'misc', resourceType: 'RAW', allowedMimeTypes: PDF_MIME_TYPES, maxBytes: 20 * MB },
};

export function getMediaCategoryConfig(category: MediaCategoryKey): MediaCategoryConfig {
  return MEDIA_CATEGORIES[category];
}
