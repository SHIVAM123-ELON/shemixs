import { z } from 'zod';
import { MEDIA_CATEGORIES, type MediaCategoryKey } from './categories';
import { ValidationError } from '../lib/errors';

const mediaCategoryEnum = z.enum(Object.keys(MEDIA_CATEGORIES) as [MediaCategoryKey, ...MediaCategoryKey[]]);

export const uploadMediaFieldsSchema = z.object({
  category: mediaCategoryEnum,
  entityType: z.string().min(1).optional(),
  entityId: z.string().uuid().optional(),
});

export const replaceMediaFieldsSchema = z.object({
  mediaId: z.string().uuid(),
});

export const deleteMediaSchema = z.object({
  mediaId: z.string().uuid(),
});

export const bulkDeleteMediaSchema = z.object({
  mediaIds: z.array(z.string().uuid()).min(1, 'At least one media id is required').max(100, 'Cannot delete more than 100 items at once'),
});

export const mediaListQuerySchema = z.object({
  category: mediaCategoryEnum.optional(),
  entityType: z.string().optional(),
  entityId: z.string().uuid().optional(),
  uploadedBy: z.string().uuid().optional(),
  page: z.coerce.number().int().min(1).default(1),
  pageSize: z.coerce.number().int().min(1).max(100).default(20),
});

/**
 * Validates a browser `File` (from FormData) against its category's
 * MIME-type allow-list and max size. Thrown as `ValidationError` (422)
 * — deliberately checked before any Cloudinary API call, so an
 * invalid file never costs an upload round-trip or Cloudinary quota.
 */
export function validateFile(file: File, category: MediaCategoryKey) {
  const config = MEDIA_CATEGORIES[category];

  if (!config.allowedMimeTypes.includes(file.type)) {
    throw new ValidationError(
      `Invalid file type "${file.type}" for category "${category}". Allowed: ${config.allowedMimeTypes.join(', ')}`
    );
  }

  if (file.size > config.maxBytes) {
    const maxMb = (config.maxBytes / (1024 * 1024)).toFixed(0);
    throw new ValidationError(`File exceeds the ${maxMb}MB limit for category "${category}"`);
  }
}

export type UploadMediaFields = z.infer<typeof uploadMediaFieldsSchema>;
export type MediaListQuery = z.infer<typeof mediaListQuerySchema>;
