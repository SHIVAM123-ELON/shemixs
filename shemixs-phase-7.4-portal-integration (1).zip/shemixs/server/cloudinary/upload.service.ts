import { withTransaction } from '../db/transaction';
import { mediaRepository } from '../repositories/media.repository';
import { auditLogService } from '../services/audit-log.service';
import { cloudinaryService } from './cloudinary.service';
import { getMediaCategoryConfig, type MediaCategoryKey } from './categories';
import { validateFile } from './validators';
import type { ControllerContext } from '../controllers/base.controller';

export interface UploadMediaInput {
  file: File;
  category: MediaCategoryKey;
  entityType?: string;
  entityId?: string;
}

export const uploadService = {
  async upload(input: UploadMediaInput, ctx: ControllerContext) {
    validateFile(input.file, input.category);

    const config = getMediaCategoryConfig(input.category);
    const arrayBuffer = await input.file.arrayBuffer();
    const buffer = Buffer.from(arrayBuffer);

    const uploaded = await cloudinaryService.uploadBuffer(buffer, {
      folder: config.folder,
      resourceType: config.resourceType,
    });

    return withTransaction(async (tx) => {
      const media = await mediaRepository.create(
        {
          publicId: uploaded.publicId,
          secureUrl: uploaded.secureUrl,
          resourceType: uploaded.resourceType,
          format: uploaded.format,
          width: uploaded.width,
          height: uploaded.height,
          duration: uploaded.duration,
          bytes: uploaded.bytes,
          folder: config.folder,
          category: input.category,
          entityType: input.entityType,
          entityId: input.entityId,
          uploadedBy: ctx.userId,
        },
        tx
      );

      await auditLogService.record(
        {
          userId: ctx.userId,
          userRole: ctx.role,
          module: 'media',
          action: 'CREATE',
          entityId: media.id,
          after: media,
          meta: ctx.meta,
        },
        tx
      );

      return media;
    });
  },
};
