/**
 * Prisma Client Singleton
 *
 * Next.js hot-reloads server modules in development, which would
 * otherwise create a new PrismaClient (and a new DB connection pool)
 * on every file change. We cache the instance on `globalThis` in
 * development and create a fresh one in production.
 */
import { PrismaClient } from '@prisma/client';

const globalForPrisma = globalThis as unknown as {
  prisma: PrismaClient | undefined;
};

export const prisma =
  globalForPrisma.prisma ??
  new PrismaClient({
    log: process.env.NODE_ENV === 'development' ? ['warn', 'error'] : ['error'],
  });

if (process.env.NODE_ENV !== 'production') {
  globalForPrisma.prisma = prisma;
}
