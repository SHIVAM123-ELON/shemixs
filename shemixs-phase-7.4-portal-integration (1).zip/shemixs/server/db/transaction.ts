/**
 * Transaction Helper
 *
 * Thin wrapper around Prisma's interactive transactions so services
 * don't reach for `prisma.$transaction` directly — keeps a single,
 * consistent place to tune timeouts/isolation later.
 */
import type { Prisma, PrismaClient } from '@prisma/client';
import { prisma } from './client';

export type TransactionClient = Prisma.TransactionClient;

interface TransactionOptions {
  maxWait?: number;
  timeout?: number;
  isolationLevel?: Prisma.TransactionIsolationLevel;
}

export async function withTransaction<T>(
  fn: (tx: TransactionClient) => Promise<T>,
  options: TransactionOptions = {}
): Promise<T> {
  return prisma.$transaction(fn, {
    maxWait: options.maxWait ?? 5000,
    timeout: options.timeout ?? 10000,
    isolationLevel: options.isolationLevel,
  });
}

export type { PrismaClient };
