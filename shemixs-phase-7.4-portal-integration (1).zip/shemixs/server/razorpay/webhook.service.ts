import { withTransaction } from '../db/transaction';
import { paymentRepository } from '../repositories/payment.repository';
import { auditLogService } from '../services/audit-log.service';
import { razorpayService } from './razorpay.service';
import { recomputeFeeStatus } from './verify.service';
import { logger } from '../lib/logger';
import { UnauthorizedError } from '../lib/errors';

interface RazorpayWebhookPayload {
  event: string;
  payload: {
    payment?: {
      entity: {
        id: string;
        order_id: string;
        status: string;
        error_description?: string;
      };
    };
  };
}

export const webhookService = {
  /**
   * The source of truth for payment settlement — fires from
   * Razorpay's servers independent of whether the user's browser is
   * still open, so a payment that succeeds but whose client-side
   * `verify` call never arrives (closed tab, network drop) still gets
   * recorded correctly here.
   */
  async handle(rawBody: string, signature: string) {
    const valid = razorpayService.verifyWebhookSignature(rawBody, signature);
    if (!valid) throw new UnauthorizedError('Invalid webhook signature');

    const payload = JSON.parse(rawBody) as RazorpayWebhookPayload;
    const paymentEntity = payload.payload.payment?.entity;

    if (!paymentEntity) {
      logger.info('Razorpay webhook received with no payment entity, ignoring', { event: payload.event });
      return;
    }

    const payment = await paymentRepository.findByRazorpayOrderId(paymentEntity.order_id);
    if (!payment) {
      logger.warn('Razorpay webhook for unknown order', { orderId: paymentEntity.order_id });
      return;
    }

    await withTransaction(async (tx) => {
      if (payload.event === 'payment.captured' && payment.status !== 'PAID') {
        const updated = await paymentRepository.update(
          payment.id,
          { status: 'PAID', razorpayPaymentId: paymentEntity.id },
          tx
        );
        await recomputeFeeStatus(payment.feeId, tx);
        await auditLogService.record(
          { module: 'payments', action: 'UPDATE', entityId: payment.id, before: { status: payment.status }, after: { status: 'PAID' } },
          tx
        );
        return updated;
      }

      if (payload.event === 'payment.failed' && payment.status !== 'PAID') {
        await paymentRepository.update(
          payment.id,
          { status: 'FAILED', failureReason: paymentEntity.error_description ?? 'Payment failed' },
          tx
        );
        await auditLogService.record(
          { module: 'payments', action: 'UPDATE', entityId: payment.id, before: { status: payment.status }, after: { status: 'FAILED' } },
          tx
        );
      }
    });
  },
};
