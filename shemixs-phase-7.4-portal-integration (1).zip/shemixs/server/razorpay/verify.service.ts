import { withTransaction } from '../db/transaction';
import { feeRepository } from '../repositories/fee.repository';
import { paymentRepository } from '../repositories/payment.repository';
import { auditLogService } from '../services/audit-log.service';
import { notificationService } from '../services/notification.service';
import { emailTemplates } from '../email/templates';
import { razorpayService } from './razorpay.service';
import { UnauthorizedError, NotFoundError } from '../lib/errors';
import type { VerifyPaymentInput } from './validators';
import type { ControllerContext } from '../controllers/base.controller';
import type { TransactionClient } from '../db/transaction';

/**
 * Recomputes a Fee's status from the sum of its PAID payments.
 * Shared between the client-side verify flow and the webhook flow so
 * both paths land on identical logic — a fee should reach the same
 * status no matter which one happens to fire first for a given payment.
 */
export async function recomputeFeeStatus(feeId: string, tx: TransactionClient) {
  const fee = await feeRepository.findById(feeId, tx);
  if (!fee) return;

  const paidTotal = await feeRepository.paidTotal(feeId, tx);

  let status: 'PENDING' | 'PARTIALLY_PAID' | 'PAID' = 'PENDING';
  if (paidTotal >= fee.amount) status = 'PAID';
  else if (paidTotal > 0) status = 'PARTIALLY_PAID';

  if (status !== fee.status) {
    await feeRepository.update(feeId, { status }, tx);
  }
}

export const verifyService = {
  /**
   * Called by the frontend immediately after Razorpay's checkout
   * widget returns a successful result. This is a UX-speed path —
   * the webhook (below) is the source of truth that fires
   * independently and would still settle the payment even if the
   * user closes their browser right after paying.
   */
  async verify(input: VerifyPaymentInput, ctx: ControllerContext) {
    const valid = razorpayService.verifyPaymentSignature(
      input.razorpayOrderId,
      input.razorpayPaymentId,
      input.razorpaySignature
    );
    if (!valid) throw new UnauthorizedError('Payment signature verification failed');

    const payment = await paymentRepository.findByRazorpayOrderId(input.razorpayOrderId);
    if (!payment) throw new NotFoundError('Payment record not found for this order');

    // Already settled (e.g. webhook beat us to it) — idempotent no-op.
    if (payment.status === 'PAID') return payment;

    const settled = await withTransaction(async (tx) => {
      const updated = await paymentRepository.update(
        payment.id,
        { status: 'PAID', razorpayPaymentId: input.razorpayPaymentId, razorpaySignature: input.razorpaySignature },
        tx
      );

      await recomputeFeeStatus(payment.feeId, tx);

      await auditLogService.record(
        { userId: ctx.userId, userRole: ctx.role, module: 'payments', action: 'UPDATE', entityId: payment.id, before: { status: payment.status }, after: { status: 'PAID' }, meta: ctx.meta },
        tx
      );

      return updated;
    });

    // Notification is deliberately outside the transaction: sending
    // email/in-app is external I/O with its own failure modes (SMTP
    // timeout, etc) that must never roll back a payment that has
    // already, factually, succeeded with Razorpay.
    const amountRupees = settled.amount / 100;
    const { html } = emailTemplates.paymentReceipt(
      settled.student.user.fullName,
      amountRupees,
      settled.receiptNumber ?? settled.id
    );
    await notificationService.notify({
      userId: settled.student.userId,
      title: 'Payment received',
      body: `We've received your payment of ₹${amountRupees.toFixed(2)}.`,
      emailHtml: html,
      channels: ['IN_APP', 'EMAIL'],
    });

    return settled;
  },
};
