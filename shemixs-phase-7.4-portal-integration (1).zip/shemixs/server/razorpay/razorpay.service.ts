/**
 * Razorpay Service (low-level)
 *
 * The only module that calls the `razorpay` package or Node's
 * `crypto` HMAC directly for signature verification — mirrors
 * `cloudinary.service.ts`'s role in the media module.
 */
import { createHmac, timingSafeEqual } from 'crypto';
import { getRazorpayClient, getRazorpayWebhookSecret } from './razorpay.config';

export interface RazorpayOrder {
  id: string;
  amount: number;
  currency: string;
  receipt?: string;
  status: string;
}

function hmacHex(payload: string, secret: string): string {
  return createHmac('sha256', secret).update(payload).digest('hex');
}

function safeCompare(a: string, b: string): boolean {
  const bufA = Buffer.from(a);
  const bufB = Buffer.from(b);
  if (bufA.length !== bufB.length) return false;
  return timingSafeEqual(bufA, bufB);
}

export const razorpayService = {
  async createOrder(amountPaise: number, currency: string, receipt: string): Promise<RazorpayOrder> {
    const client = getRazorpayClient();
    const order = await client.orders.create({ amount: amountPaise, currency, receipt });
    return {
      id: order.id,
      amount: Number(order.amount),
      currency: order.currency,
      receipt: order.receipt,
      status: order.status,
    };
  },

  /**
   * Verifies the signature Razorpay's client-side checkout returns
   * after a successful payment. Formula per Razorpay docs:
   * HMAC_SHA256(order_id + "|" + payment_id, key_secret).
   */
  verifyPaymentSignature(orderId: string, paymentId: string, signature: string): boolean {
    const client = getRazorpayClient();
    const expected = hmacHex(`${orderId}|${paymentId}`, (client as unknown as { key_secret: string }).key_secret);
    return safeCompare(expected, signature);
  },

  /** Verifies the X-Razorpay-Signature header on incoming webhook requests against the raw request body. */
  verifyWebhookSignature(rawBody: string, signature: string): boolean {
    const secret = getRazorpayWebhookSecret();
    const expected = hmacHex(rawBody, secret);
    return safeCompare(expected, signature);
  },

  async fetchPayment(paymentId: string) {
    const client = getRazorpayClient();
    return client.payments.fetch(paymentId);
  },
};
