/**
 * Razorpay Config
 *
 * Mirrors `server/cloudinary/cloudinary.config.ts`: lazily configures
 * the SDK the first time it's needed, validates its own env vars
 * separately from the app-wide `getEnv()`, so the rest of the app
 * never fails to boot just because Razorpay credentials aren't set.
 */
import Razorpay from 'razorpay';
import { z } from 'zod';

const razorpayEnvSchema = z.object({
  RAZORPAY_KEY_ID: z.string().min(1, 'RAZORPAY_KEY_ID is required'),
  RAZORPAY_KEY_SECRET: z.string().min(1, 'RAZORPAY_KEY_SECRET is required'),
});

let client: Razorpay | null = null;
let webhookSecret: string | null = null;

export function getRazorpayClient(): Razorpay {
  if (!client) {
    const parsed = razorpayEnvSchema.safeParse(process.env);
    if (!parsed.success) {
      const issues = parsed.error.issues.map((i) => `  - ${i.path.join('.')}: ${i.message}`).join('\n');
      throw new Error(`Invalid Razorpay configuration:\n${issues}`);
    }
    client = new Razorpay({ key_id: parsed.data.RAZORPAY_KEY_ID, key_secret: parsed.data.RAZORPAY_KEY_SECRET });
  }
  return client;
}

/** Separate from the API secret — Razorpay signs webhook payloads with a distinct secret configured in the dashboard. */
export function getRazorpayWebhookSecret(): string {
  if (!webhookSecret) {
    const value = process.env.RAZORPAY_WEBHOOK_SECRET;
    if (!value) throw new Error('RAZORPAY_WEBHOOK_SECRET is required to verify webhook signatures');
    webhookSecret = value;
  }
  return webhookSecret;
}

export function getRazorpayKeyId(): string {
  const parsed = razorpayEnvSchema.safeParse(process.env);
  if (!parsed.success) throw new Error('RAZORPAY_KEY_ID is not configured');
  return parsed.data.RAZORPAY_KEY_ID;
}
