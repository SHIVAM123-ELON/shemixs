import { randomBytes } from 'crypto';
import { withTransaction } from '../db/transaction';
import { feeRepository } from '../repositories/fee.repository';
import { paymentRepository } from '../repositories/payment.repository';
import { auditLogService } from '../services/audit-log.service';
import { razorpayService } from './razorpay.service';
import { getRazorpayKeyId } from './razorpay.config';
import { NotFoundError, ConflictError } from '../lib/errors';
import type { ControllerContext } from '../controllers/base.controller';

function generateReceiptNumber(): string {
  return `RCPT-${Date.now()}-${randomBytes(3).toString('hex').toUpperCase()}`;
}

export const orderService = {
  /**
   * Creates a Razorpay order for the *remaining balance* of a fee
   * (amount minus whatever's already been PAID against it) — supports
   * partial payments cleanly without the caller needing to compute
   * the balance themselves.
   */
  async createOrderForFee(feeId: string, ctx: ControllerContext) {
    const fee = await feeRepository.findById(feeId);
    if (!fee) throw new NotFoundError('Fee not found');
    if (fee.status === 'PAID' || fee.status === 'WAIVED') {
      throw new ConflictError(`This fee is already ${fee.status.toLowerCase()}`);
    }

    const paidSoFar = await feeRepository.paidTotal(feeId);
    const remaining = fee.amount - paidSoFar;
    if (remaining <= 0) throw new ConflictError('This fee has already been fully paid');

    const receipt = generateReceiptNumber();
    const order = await razorpayService.createOrder(remaining, 'INR', receipt);

    return withTransaction(async (tx) => {
      const payment = await paymentRepository.create(
        {
          feeId,
          studentId: fee.studentId,
          amount: remaining,
          currency: 'INR',
          status: 'CREATED',
          razorpayOrderId: order.id,
          receiptNumber: receipt,
        },
        tx
      );

      await auditLogService.record(
        { userId: ctx.userId, userRole: ctx.role, module: 'payments', action: 'CREATE', entityId: payment.id, after: payment, meta: ctx.meta },
        tx
      );

      return {
        payment,
        razorpayOrderId: order.id,
        razorpayKeyId: getRazorpayKeyId(),
        amount: remaining,
        currency: 'INR',
      };
    });
  },
};
