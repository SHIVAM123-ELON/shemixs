import { z } from 'zod';

export const feeStatusEnum = z.enum(['PENDING', 'PARTIALLY_PAID', 'PAID', 'OVERDUE', 'WAIVED']);
export const paymentStatusEnum = z.enum(['CREATED', 'PENDING', 'PAID', 'FAILED', 'REFUNDED']);

export const createFeeSchema = z.object({
  studentId: z.string().uuid(),
  title: z.string().min(1, 'Title is required'),
  description: z.string().optional(),
  amount: z.coerce.number().int().positive('Amount must be a positive number of paise'),
  dueDate: z.coerce.date().optional(),
});

export const updateFeeSchema = z.object({
  title: z.string().min(1).optional(),
  description: z.string().optional(),
  amount: z.coerce.number().int().positive().optional(),
  dueDate: z.coerce.date().nullable().optional(),
  status: feeStatusEnum.optional(),
});

export const feeListQuerySchema = z.object({
  studentId: z.string().uuid().optional(),
  status: feeStatusEnum.optional(),
  page: z.coerce.number().int().min(1).default(1),
  pageSize: z.coerce.number().int().min(1).max(100).default(20),
});

export const createOrderSchema = z.object({
  feeId: z.string().uuid(),
});

export const verifyPaymentSchema = z.object({
  razorpayOrderId: z.string().min(1),
  razorpayPaymentId: z.string().min(1),
  razorpaySignature: z.string().min(1),
});

export const paymentListQuerySchema = z.object({
  studentId: z.string().uuid().optional(),
  status: paymentStatusEnum.optional(),
  page: z.coerce.number().int().min(1).default(1),
  pageSize: z.coerce.number().int().min(1).max(100).default(20),
});

export type CreateFeeInput = z.infer<typeof createFeeSchema>;
export type UpdateFeeInput = z.infer<typeof updateFeeSchema>;
export type FeeListQuery = z.infer<typeof feeListQuerySchema>;
export type CreateOrderInput = z.infer<typeof createOrderSchema>;
export type VerifyPaymentInput = z.infer<typeof verifyPaymentSchema>;
export type PaymentListQuery = z.infer<typeof paymentListQuerySchema>;
