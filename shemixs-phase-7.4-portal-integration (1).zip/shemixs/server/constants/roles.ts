import type { RoleName } from '@prisma/client';

export const ROLES: Record<RoleName, RoleName> = {
  SUPER_ADMIN: 'SUPER_ADMIN',
  ADMIN: 'ADMIN',
  PRINCIPAL: 'PRINCIPAL',
  COORDINATOR: 'COORDINATOR',
  TEACHER: 'TEACHER',
  STUDENT: 'STUDENT',
  PARENT: 'PARENT',
  ACCOUNTANT: 'ACCOUNTANT',
  RECEPTIONIST: 'RECEPTIONIST',
};

/**
 * Module-level RBAC for API authorization (as opposed to
 * PORTAL_ROLE_MAP, which is page/route-level). SUPER_ADMIN is
 * implicitly allowed everywhere by convention — checked separately in
 * `hasModuleAccess` below rather than repeated in every array.
 */
export const MODULE_ROLE_MAP: Record<string, RoleName[]> = {
  students: ['ADMIN', 'PRINCIPAL', 'COORDINATOR', 'TEACHER'],
  teachers: ['ADMIN', 'PRINCIPAL'],
  parents: ['ADMIN', 'PRINCIPAL', 'COORDINATOR', 'RECEPTIONIST'],
  admissions: ['ADMIN', 'PRINCIPAL', 'COORDINATOR', 'RECEPTIONIST'],
  courses: ['ADMIN', 'PRINCIPAL', 'COORDINATOR'],
  subjects: ['ADMIN', 'PRINCIPAL', 'COORDINATOR'],
  batches: ['ADMIN', 'PRINCIPAL', 'COORDINATOR', 'TEACHER'],
  sections: ['ADMIN', 'PRINCIPAL', 'COORDINATOR'],
  timetable: ['ADMIN', 'PRINCIPAL', 'COORDINATOR', 'TEACHER'],
  attendance: ['ADMIN', 'PRINCIPAL', 'TEACHER'],
  homework: ['TEACHER', 'ADMIN'],
  assignments: ['TEACHER', 'ADMIN'],
  tests: ['TEACHER', 'ADMIN'],
  results: ['TEACHER', 'ADMIN', 'PRINCIPAL'],
  certificates: ['ADMIN', 'PRINCIPAL'],
  finance: ['ACCOUNTANT', 'SUPER_ADMIN'],
};

export function moduleRoles(module: keyof typeof MODULE_ROLE_MAP): RoleName[] {
  // SUPER_ADMIN always has access, in addition to the module's own list.
  return ['SUPER_ADMIN', ...MODULE_ROLE_MAP[module]];
}

/**
 * Maps each portal route segment (app/portal/<segment>) to the roles
 * allowed to access it. Used by middleware for coarse-grained route
 * protection; fine-grained action checks go through permissions.
 */
export const PORTAL_ROLE_MAP: Record<string, RoleName[]> = {
  admin: ['SUPER_ADMIN', 'ADMIN', 'PRINCIPAL', 'COORDINATOR'],
  teacher: ['TEACHER', 'SUPER_ADMIN'],
  student: ['STUDENT', 'SUPER_ADMIN'],
  parent: ['PARENT', 'SUPER_ADMIN'],
};
