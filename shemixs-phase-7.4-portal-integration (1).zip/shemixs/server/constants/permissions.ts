import type { PermissionAction } from '@prisma/client';

export const PERMISSION_ACTIONS: PermissionAction[] = [
  'CREATE',
  'READ',
  'UPDATE',
  'DELETE',
  'EXPORT',
  'IMPORT',
  'PUBLISH',
  'APPROVE',
  'ASSIGN',
  'MANAGE',
];

/** Business-module resources permissions apply to. Extend as new modules ship. */
export const PERMISSION_RESOURCES = [
  'users',
  'roles',
  'students',
  'teachers',
  'parents',
  'admissions',
  'attendance',
  'results',
  'fees',
  'timetable',
  'reports',
] as const;

export type PermissionResource = (typeof PERMISSION_RESOURCES)[number];
