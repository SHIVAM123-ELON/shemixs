import type { NextRequest } from 'next/server';
import { authorize, parseSearchParams } from './base.controller';
import { parentService } from '../services/parent.service';
import { moduleRoles } from '../constants/roles';
import { apiPaginated, apiSuccess } from '../lib/api-response';
import { createParentSchema, updateParentSchema, linkStudentSchema, unlinkStudentSchema, parentListQuerySchema } from '../validators/parent.validators';
import { idParamSchema } from '../validators/common.validators';

const ROLES = moduleRoles('parents');

export const parentController = {
  async list(req: NextRequest) {
    await authorize(req, ROLES);
    const query = parentListQuerySchema.parse(parseSearchParams(req));
    const { items, pagination } = await parentService.list(query);
    return apiPaginated(items, pagination);
  },

  async getById(req: NextRequest, params: { id: string }) {
    await authorize(req, ROLES);
    const { id } = idParamSchema.parse(params);
    const parent = await parentService.getById(id);
    return apiSuccess(parent);
  },

  async create(req: NextRequest) {
    const ctx = await authorize(req, ROLES);
    const body = createParentSchema.parse(await req.json());
    const parent = await parentService.create(body, ctx);
    return apiSuccess(parent, { status: 201, message: 'Parent created successfully' });
  },

  async update(req: NextRequest, params: { id: string }) {
    const ctx = await authorize(req, ROLES);
    const { id } = idParamSchema.parse(params);
    const body = updateParentSchema.parse(await req.json());
    const parent = await parentService.update(id, body, ctx);
    return apiSuccess(parent, { message: 'Parent updated successfully' });
  },

  async linkStudent(req: NextRequest, params: { id: string }) {
    const ctx = await authorize(req, ROLES);
    const { id } = idParamSchema.parse(params);
    const body = linkStudentSchema.parse(await req.json());
    const parent = await parentService.linkStudent(id, body, ctx);
    return apiSuccess(parent, { message: 'Student linked successfully' });
  },

  async unlinkStudent(req: NextRequest, params: { id: string }) {
    const ctx = await authorize(req, ROLES);
    const { id } = idParamSchema.parse(params);
    const body = unlinkStudentSchema.parse(await req.json());
    const parent = await parentService.unlinkStudent(id, body, ctx);
    return apiSuccess(parent, { message: 'Student unlinked successfully' });
  },

  async remove(req: NextRequest, params: { id: string }) {
    const ctx = await authorize(req, ROLES);
    const { id } = idParamSchema.parse(params);
    await parentService.softDelete(id, ctx);
    return apiSuccess(null, { message: 'Parent deleted successfully' });
  },
};
