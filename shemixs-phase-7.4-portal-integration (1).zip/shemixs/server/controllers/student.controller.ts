import type { NextRequest } from 'next/server';
import { authorize, parseSearchParams } from './base.controller';
import { studentService } from '../services/student.service';
import { moduleRoles } from '../constants/roles';
import { apiPaginated, apiSuccess } from '../lib/api-response';
import {
  createStudentSchema,
  updateStudentSchema,
  updateStudentStatusSchema,
  enrollStudentSchema,
  studentListQuerySchema,
} from '../validators/student.validators';
import { idParamSchema } from '../validators/common.validators';

const ROLES = moduleRoles('students');

export const studentController = {
  async list(req: NextRequest) {
    await authorize(req, ROLES);
    const query = studentListQuerySchema.parse(parseSearchParams(req));
    const { items, pagination } = await studentService.list(query);
    return apiPaginated(items, pagination);
  },

  async getById(req: NextRequest, params: { id: string }) {
    await authorize(req, ROLES);
    const { id } = idParamSchema.parse(params);
    const student = await studentService.getById(id);
    return apiSuccess(student);
  },

  async create(req: NextRequest) {
    const ctx = await authorize(req, ROLES);
    const body = createStudentSchema.parse(await req.json());
    const student = await studentService.create(body, ctx);
    return apiSuccess(student, { status: 201, message: 'Student created successfully' });
  },

  async update(req: NextRequest, params: { id: string }) {
    const ctx = await authorize(req, ROLES);
    const { id } = idParamSchema.parse(params);
    const body = updateStudentSchema.parse(await req.json());
    const student = await studentService.update(id, body, ctx);
    return apiSuccess(student, { message: 'Student updated successfully' });
  },

  async updateStatus(req: NextRequest, params: { id: string }) {
    const ctx = await authorize(req, ROLES);
    const { id } = idParamSchema.parse(params);
    const body = updateStudentStatusSchema.parse(await req.json());
    const student = await studentService.updateStatus(id, body, ctx);
    return apiSuccess(student, { message: 'Student status updated' });
  },

  async enroll(req: NextRequest, params: { id: string }) {
    const ctx = await authorize(req, ROLES);
    const { id } = idParamSchema.parse(params);
    const body = enrollStudentSchema.parse(await req.json());
    const student = await studentService.enroll(id, body, ctx);
    return apiSuccess(student, { message: 'Student enrolled successfully' });
  },

  async remove(req: NextRequest, params: { id: string }) {
    const ctx = await authorize(req, ROLES);
    const { id } = idParamSchema.parse(params);
    await studentService.softDelete(id, ctx);
    return apiSuccess(null, { message: 'Student deleted successfully' });
  },

  async restore(req: NextRequest, params: { id: string }) {
    const ctx = await authorize(req, ROLES);
    const { id } = idParamSchema.parse(params);
    const student = await studentService.restore(id, ctx);
    return apiSuccess(student, { message: 'Student restored successfully' });
  },
};
