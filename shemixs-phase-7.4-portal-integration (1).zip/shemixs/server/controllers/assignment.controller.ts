import type { NextRequest } from 'next/server';
import { z } from 'zod';
import { authorize, parseSearchParams } from './base.controller';
import { assignmentService } from '../services/assignment.service';
import { moduleRoles } from '../constants/roles';
import { apiPaginated, apiSuccess } from '../lib/api-response';
import {
  createAssignmentSchema,
  updateAssignmentSchema,
  submitAssignmentSchema,
  evaluateAssignmentSchema,
  assignmentListQuerySchema,
} from '../validators/assignment.validators';
import { idParamSchema } from '../validators/common.validators';

const ROLES = moduleRoles('assignments');
const studentIdParamSchema = z.object({ studentId: z.string().uuid() });

export const assignmentController = {
  async list(req: NextRequest) {
    await authorize(req, ROLES);
    const query = assignmentListQuerySchema.parse(parseSearchParams(req));
    const { items, pagination } = await assignmentService.list(query);
    return apiPaginated(items, pagination);
  },

  async getById(req: NextRequest, params: { id: string }) {
    await authorize(req, ROLES);
    const { id } = idParamSchema.parse(params);
    const assignment = await assignmentService.getById(id);
    return apiSuccess(assignment);
  },

  async create(req: NextRequest) {
    const ctx = await authorize(req, ROLES);
    const body = createAssignmentSchema.parse(await req.json());
    const assignment = await assignmentService.create(body, ctx);
    return apiSuccess(assignment, { status: 201, message: 'Assignment created successfully' });
  },

  async update(req: NextRequest, params: { id: string }) {
    const ctx = await authorize(req, ROLES);
    const { id } = idParamSchema.parse(params);
    const body = updateAssignmentSchema.parse(await req.json());
    const assignment = await assignmentService.update(id, body, ctx);
    return apiSuccess(assignment, { message: 'Assignment updated successfully' });
  },

  async publish(req: NextRequest, params: { id: string }) {
    const ctx = await authorize(req, ROLES);
    const { id } = idParamSchema.parse(params);
    const assignment = await assignmentService.publish(id, ctx);
    return apiSuccess(assignment, { message: 'Assignment published' });
  },

  async listSubmissions(req: NextRequest, params: { id: string }) {
    await authorize(req, ROLES);
    const { id } = idParamSchema.parse(params);
    const submissions = await assignmentService.listSubmissions(id);
    return apiSuccess(submissions);
  },

  async submit(req: NextRequest, params: { id: string }) {
    // Students submit their own work — allow the STUDENT role here in
    // addition to the module's staff roles.
    const ctx = await authorize(req, [...ROLES, 'STUDENT']);
    const { id } = idParamSchema.parse(params);
    const body = submitAssignmentSchema.parse(await req.json());
    const submission = await assignmentService.submit(id, body, ctx);
    return apiSuccess(submission, { message: 'Assignment submitted successfully' });
  },

  async evaluate(req: NextRequest, params: { id: string; studentId: string }) {
    const ctx = await authorize(req, ROLES);
    const { id } = idParamSchema.parse({ id: params.id });
    const { studentId } = studentIdParamSchema.parse({ studentId: params.studentId });
    const body = evaluateAssignmentSchema.parse(await req.json());
    const result = await assignmentService.evaluate(id, studentId, body, ctx);
    return apiSuccess(result, { message: 'Submission evaluated' });
  },

  async remove(req: NextRequest, params: { id: string }) {
    const ctx = await authorize(req, ROLES);
    const { id } = idParamSchema.parse(params);
    await assignmentService.softDelete(id, ctx);
    return apiSuccess(null, { message: 'Assignment deleted successfully' });
  },
};
