import type { NextRequest } from 'next/server';
import { z } from 'zod';
import { requireUser } from '../auth/guard';
import { parseSearchParams } from './base.controller';
import { notificationService } from '../services/notification.service';
import { apiSuccess } from '../lib/api-response';
import { NotFoundError, ForbiddenError } from '../lib/errors';
import { notificationRepository } from '../repositories/notification.repository';

const listQuerySchema = z.object({
  channel: z.enum(['IN_APP', 'EMAIL', 'WHATSAPP']).optional(),
  status: z.enum(['QUEUED', 'SENT', 'FAILED', 'READ']).optional(),
  page: z.coerce.number().int().min(1).default(1),
  pageSize: z.coerce.number().int().min(1).max(100).default(20),
});

export const notificationController = {
  /** Every user (any role) reads only their own notifications — no module-level RBAC needed, ownership is the check. */
  async list(req: NextRequest) {
    const payload = await requireUser(req);
    const query = listQuerySchema.parse(parseSearchParams(req));
    const result = await notificationService.list({ ...query, userId: payload.sub });
    return apiSuccess(result.items, { meta: { pagination: result.pagination, unreadCount: result.unreadCount } });
  },

  async markRead(req: NextRequest, params: { id: string }) {
    const payload = await requireUser(req);
    const notification = await notificationRepository.findById(params.id);
    if (!notification) throw new NotFoundError('Notification not found');
    if (notification.userId !== payload.sub) throw new ForbiddenError();

    const updated = await notificationService.markRead(params.id);
    return apiSuccess(updated, { message: 'Marked as read' });
  },

  async markAllRead(req: NextRequest) {
    const payload = await requireUser(req);
    await notificationService.markAllRead(payload.sub);
    return apiSuccess(null, { message: 'All notifications marked as read' });
  },
};
