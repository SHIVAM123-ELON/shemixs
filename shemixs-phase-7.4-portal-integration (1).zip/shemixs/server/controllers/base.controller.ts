/**
 * Controller Helpers
 *
 * Route handlers (app/api/**\/route.ts) are kept to 3 lines each:
 * parse → delegate to a controller function → the controller calls
 * requireRole, parses/validates input, calls the service, and shapes
 * the response. This file holds what every controller needs in
 * common so individual module controllers (student.controller.ts,
 * teacher.controller.ts, ...) don't repeat it.
 */
import type { NextRequest } from 'next/server';
import { requireRole } from '../auth/guard';
import { getRequestMeta } from '../lib/request-meta';
import type { RoleName } from '@prisma/client';

export interface ControllerContext {
  userId: string;
  role: RoleName;
  email: string;
  meta: ReturnType<typeof getRequestMeta>;
}

/**
 * Verifies the caller is authenticated and holds one of `allowedRoles`,
 * and returns everything a controller typically needs (identity +
 * request metadata for audit logging) in one call.
 */
export async function authorize(req: NextRequest, allowedRoles: RoleName[]): Promise<ControllerContext> {
  const payload = await requireRole(req, allowedRoles);
  return {
    userId: payload.sub,
    role: payload.role as RoleName,
    email: payload.email,
    meta: getRequestMeta(req),
  };
}

export function parseSearchParams(req: NextRequest): Record<string, string> {
  return Object.fromEntries(req.nextUrl.searchParams.entries());
}
