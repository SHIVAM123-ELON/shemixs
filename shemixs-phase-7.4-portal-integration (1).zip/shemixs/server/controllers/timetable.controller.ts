import type { NextRequest } from 'next/server';
import { authorize, parseSearchParams } from './base.controller';
import { timetableService } from '../services/timetable.service';
import { moduleRoles } from '../constants/roles';
import { apiSuccess } from '../lib/api-response';
import { createTimetableEntrySchema, updateTimetableEntrySchema, timetableListQuerySchema } from '../validators/timetable.validators';
import { idParamSchema } from '../validators/common.validators';

const ROLES = moduleRoles('timetable');

export const timetableController = {
  async list(req: NextRequest) {
    await authorize(req, ROLES);
    const query = timetableListQuerySchema.parse(parseSearchParams(req));
    const entries = await timetableService.list(query);
    return apiSuccess(entries);
  },

  async teacherSchedule(req: NextRequest, params: { id: string }) {
    await authorize(req, ROLES);
    const { id } = idParamSchema.parse(params);
    const entries = await timetableService.teacherSchedule(id);
    return apiSuccess(entries);
  },

  async classTimetable(req: NextRequest, params: { id: string }) {
    await authorize(req, ROLES);
    const { id } = idParamSchema.parse(params);
    const entries = await timetableService.classTimetable(id);
    return apiSuccess(entries);
  },

  async studentSchedule(req: NextRequest, params: { id: string }) {
    await authorize(req, ROLES);
    const { id } = idParamSchema.parse(params);
    const entries = await timetableService.studentSchedule(id);
    return apiSuccess(entries);
  },

  async getById(req: NextRequest, params: { id: string }) {
    await authorize(req, ROLES);
    const { id } = idParamSchema.parse(params);
    const entry = await timetableService.getById(id);
    return apiSuccess(entry);
  },

  async create(req: NextRequest) {
    const ctx = await authorize(req, ROLES);
    const body = createTimetableEntrySchema.parse(await req.json());
    const entry = await timetableService.create(body, ctx);
    return apiSuccess(entry, { status: 201, message: 'Timetable entry created successfully' });
  },

  async update(req: NextRequest, params: { id: string }) {
    const ctx = await authorize(req, ROLES);
    const { id } = idParamSchema.parse(params);
    const body = updateTimetableEntrySchema.parse(await req.json());
    const entry = await timetableService.update(id, body, ctx);
    return apiSuccess(entry, { message: 'Timetable entry updated successfully' });
  },

  async remove(req: NextRequest, params: { id: string }) {
    const ctx = await authorize(req, ROLES);
    const { id } = idParamSchema.parse(params);
    await timetableService.softDelete(id, ctx);
    return apiSuccess(null, { message: 'Timetable entry deleted successfully' });
  },
};
