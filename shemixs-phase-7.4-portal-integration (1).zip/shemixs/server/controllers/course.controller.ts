import { z } from 'zod';
import type { NextRequest } from 'next/server';
import { authorize, parseSearchParams } from './base.controller';
import { courseService } from '../services/course.service';
import { moduleRoles } from '../constants/roles';
import { apiPaginated, apiSuccess } from '../lib/api-response';
import { createCourseSchema, updateCourseSchema, updateCourseStatusSchema, courseListQuerySchema } from '../validators/course.validators';
import { idParamSchema } from '../validators/common.validators';

const ROLES = moduleRoles('courses');
const assignInstructorsSchema = z.object({ teacherIds: z.array(z.string().uuid()) });

export const courseController = {
  async list(req: NextRequest) {
    await authorize(req, ROLES);
    const query = courseListQuerySchema.parse(parseSearchParams(req));
    const { items, pagination } = await courseService.list(query);
    return apiPaginated(items, pagination);
  },

  async getById(req: NextRequest, params: { id: string }) {
    await authorize(req, ROLES);
    const { id } = idParamSchema.parse(params);
    const course = await courseService.getById(id);
    return apiSuccess(course);
  },

  async create(req: NextRequest) {
    const ctx = await authorize(req, ROLES);
    const body = createCourseSchema.parse(await req.json());
    const course = await courseService.create(body, ctx);
    return apiSuccess(course, { status: 201, message: 'Course created successfully' });
  },

  async update(req: NextRequest, params: { id: string }) {
    const ctx = await authorize(req, ROLES);
    const { id } = idParamSchema.parse(params);
    const body = updateCourseSchema.parse(await req.json());
    const course = await courseService.update(id, body, ctx);
    return apiSuccess(course, { message: 'Course updated successfully' });
  },

  async updateStatus(req: NextRequest, params: { id: string }) {
    const ctx = await authorize(req, ROLES);
    const { id } = idParamSchema.parse(params);
    const body = updateCourseStatusSchema.parse(await req.json());
    const course = await courseService.updateStatus(id, body, ctx);
    return apiSuccess(course, { message: 'Course status updated' });
  },

  async assignInstructors(req: NextRequest, params: { id: string }) {
    const ctx = await authorize(req, ROLES);
    const { id } = idParamSchema.parse(params);
    const body = assignInstructorsSchema.parse(await req.json());
    const course = await courseService.assignInstructors(id, body.teacherIds, ctx);
    return apiSuccess(course, { message: 'Instructors assigned successfully' });
  },

  async remove(req: NextRequest, params: { id: string }) {
    const ctx = await authorize(req, ROLES);
    const { id } = idParamSchema.parse(params);
    await courseService.softDelete(id, ctx);
    return apiSuccess(null, { message: 'Course deleted successfully' });
  },
};
