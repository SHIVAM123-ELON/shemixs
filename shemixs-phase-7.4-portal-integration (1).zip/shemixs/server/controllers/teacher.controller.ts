import type { NextRequest } from 'next/server';
import { authorize, parseSearchParams } from './base.controller';
import { teacherService } from '../services/teacher.service';
import { moduleRoles } from '../constants/roles';
import { apiPaginated, apiSuccess } from '../lib/api-response';
import {
  createTeacherSchema,
  updateTeacherSchema,
  updateTeacherStatusSchema,
  assignTeacherSubjectsSchema,
  teacherListQuerySchema,
} from '../validators/teacher.validators';
import { idParamSchema } from '../validators/common.validators';

const ROLES = moduleRoles('teachers');

export const teacherController = {
  async list(req: NextRequest) {
    await authorize(req, ROLES);
    const query = teacherListQuerySchema.parse(parseSearchParams(req));
    const { items, pagination } = await teacherService.list(query);
    return apiPaginated(items, pagination);
  },

  async getById(req: NextRequest, params: { id: string }) {
    await authorize(req, ROLES);
    const { id } = idParamSchema.parse(params);
    const teacher = await teacherService.getById(id);
    return apiSuccess(teacher);
  },

  async create(req: NextRequest) {
    const ctx = await authorize(req, ROLES);
    const body = createTeacherSchema.parse(await req.json());
    const teacher = await teacherService.create(body, ctx);
    return apiSuccess(teacher, { status: 201, message: 'Teacher created successfully' });
  },

  async update(req: NextRequest, params: { id: string }) {
    const ctx = await authorize(req, ROLES);
    const { id } = idParamSchema.parse(params);
    const body = updateTeacherSchema.parse(await req.json());
    const teacher = await teacherService.update(id, body, ctx);
    return apiSuccess(teacher, { message: 'Teacher updated successfully' });
  },

  async updateStatus(req: NextRequest, params: { id: string }) {
    const ctx = await authorize(req, ROLES);
    const { id } = idParamSchema.parse(params);
    const body = updateTeacherStatusSchema.parse(await req.json());
    const teacher = await teacherService.updateStatus(id, body, ctx);
    return apiSuccess(teacher, { message: 'Teacher status updated' });
  },

  async assignSubjects(req: NextRequest, params: { id: string }) {
    const ctx = await authorize(req, ROLES);
    const { id } = idParamSchema.parse(params);
    const body = assignTeacherSubjectsSchema.parse(await req.json());
    const teacher = await teacherService.assignSubjects(id, body, ctx);
    return apiSuccess(teacher, { message: 'Subjects assigned successfully' });
  },

  async remove(req: NextRequest, params: { id: string }) {
    const ctx = await authorize(req, ROLES);
    const { id } = idParamSchema.parse(params);
    await teacherService.softDelete(id, ctx);
    return apiSuccess(null, { message: 'Teacher deleted successfully' });
  },
};
