import { prisma } from '../db/client';
import { studentRepository } from '../repositories/student.repository';
import { ForbiddenError } from '../lib/errors';
import type { ControllerContext } from './base.controller';

/**
 * Staff roles bypass the ownership check entirely (they're already
 * gated by module-level RBAC upstream). For STUDENT/PARENT, this is
 * the enforcement point spec section 15 requires: "A parent must only
 * access their own child's data. A student must only access their own
 * data" — never left to the frontend alone.
 */
export async function assertOwnsStudent(ctx: ControllerContext, studentId: string): Promise<void> {
  if (ctx.role !== 'STUDENT' && ctx.role !== 'PARENT') return; // staff roles already RBAC-gated by the caller

  if (ctx.role === 'STUDENT') {
    const own = await studentRepository.findByUserId(ctx.userId);
    if (!own || own.id !== studentId) throw new ForbiddenError('You can only access your own data');
    return;
  }

  // PARENT
  const parent = await prisma.parent.findFirst({ where: { userId: ctx.userId, deletedAt: null } });
  if (!parent) throw new ForbiddenError();
  const link = await prisma.parentStudent.findUnique({ where: { parentId_studentId: { parentId: parent.id, studentId } } });
  if (!link) throw new ForbiddenError('You can only access your own child\'s data');
}
