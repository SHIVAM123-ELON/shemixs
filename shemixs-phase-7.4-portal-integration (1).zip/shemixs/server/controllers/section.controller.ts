import type { NextRequest } from 'next/server';
import { authorize, parseSearchParams } from './base.controller';
import { sectionService } from '../services/section.service';
import { moduleRoles } from '../constants/roles';
import { apiPaginated, apiSuccess } from '../lib/api-response';
import {
  createSectionSchema,
  updateSectionSchema,
  assignSectionBatchSchema,
  assignSectionStudentsSchema,
  sectionListQuerySchema,
} from '../validators/section.validators';
import { idParamSchema } from '../validators/common.validators';

const ROLES = moduleRoles('sections');

export const sectionController = {
  async list(req: NextRequest) {
    await authorize(req, ROLES);
    const query = sectionListQuerySchema.parse(parseSearchParams(req));
    const { items, pagination } = await sectionService.list(query);
    return apiPaginated(items, pagination);
  },

  async getById(req: NextRequest, params: { id: string }) {
    await authorize(req, ROLES);
    const { id } = idParamSchema.parse(params);
    const section = await sectionService.getById(id);
    return apiSuccess(section);
  },

  async create(req: NextRequest) {
    const ctx = await authorize(req, ROLES);
    const body = createSectionSchema.parse(await req.json());
    const section = await sectionService.create(body, ctx);
    return apiSuccess(section, { status: 201, message: 'Section created successfully' });
  },

  async update(req: NextRequest, params: { id: string }) {
    const ctx = await authorize(req, ROLES);
    const { id } = idParamSchema.parse(params);
    const body = updateSectionSchema.parse(await req.json());
    const section = await sectionService.update(id, body, ctx);
    return apiSuccess(section, { message: 'Section updated successfully' });
  },

  async assignBatch(req: NextRequest, params: { id: string }) {
    const ctx = await authorize(req, ROLES);
    const { id } = idParamSchema.parse(params);
    const body = assignSectionBatchSchema.parse(await req.json());
    const section = await sectionService.assignBatch(id, body.batchId, ctx);
    return apiSuccess(section, { message: 'Batch assigned successfully' });
  },

  async assignStudents(req: NextRequest, params: { id: string }) {
    const ctx = await authorize(req, ROLES);
    const { id } = idParamSchema.parse(params);
    const body = assignSectionStudentsSchema.parse(await req.json());
    const section = await sectionService.assignStudents(id, body.studentIds, ctx);
    return apiSuccess(section, { message: 'Students assigned successfully' });
  },

  async remove(req: NextRequest, params: { id: string }) {
    const ctx = await authorize(req, ROLES);
    const { id } = idParamSchema.parse(params);
    await sectionService.softDelete(id, ctx);
    return apiSuccess(null, { message: 'Section deleted successfully' });
  },
};
