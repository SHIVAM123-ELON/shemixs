import type { NextRequest } from 'next/server';
import { authorize, parseSearchParams } from './base.controller';
import { assertOwnsStudent } from './ownership';
import { orderService } from '../razorpay/order.service';
import { verifyService } from '../razorpay/verify.service';
import { paymentRepository } from '../repositories/payment.repository';
import { apiPaginated, apiSuccess } from '../lib/api-response';
import { NotFoundError } from '../lib/errors';
import { createOrderSchema, verifyPaymentSchema, paymentListQuerySchema } from '../razorpay/validators';
import { feeRepository } from '../repositories/fee.repository';

const READ_ROLES = ['SUPER_ADMIN', 'ADMIN', 'ACCOUNTANT', 'STUDENT', 'PARENT'] as const;

export const paymentController = {
  async createOrder(req: NextRequest) {
    // A student (or their parent) pays their own fee — broad
    // authenticated access, same reasoning as the media module.
    const ctx = await authorize(req, [...READ_ROLES]);
    const body = createOrderSchema.parse(await req.json());

    const fee = await feeRepository.findById(body.feeId);
    if (!fee) throw new NotFoundError('Fee not found');
    await assertOwnsStudent(ctx, fee.studentId);

    const result = await orderService.createOrderForFee(body.feeId, ctx);
    return apiSuccess(result, { status: 201, message: 'Order created' });
  },

  async verify(req: NextRequest) {
    const ctx = await authorize(req, [...READ_ROLES]);
    const body = verifyPaymentSchema.parse(await req.json());
    const payment = await verifyService.verify(body, ctx);
    return apiSuccess(payment, { message: 'Payment verified successfully' });
  },

  async list(req: NextRequest) {
    await authorize(req, [...READ_ROLES]);
    const query = paymentListQuerySchema.parse(parseSearchParams(req));
    const { items, totalItems } = await paymentRepository.findMany(query);
    const totalPages = Math.max(1, Math.ceil(totalItems / query.pageSize));
    return apiPaginated(items, {
      page: query.page,
      pageSize: query.pageSize,
      totalItems,
      totalPages,
      hasNextPage: query.page < totalPages,
      hasPreviousPage: query.page > 1,
    });
  },

  async receipt(req: NextRequest, params: { id: string }) {
    await authorize(req, [...READ_ROLES]);
    const payment = await paymentRepository.findById(params.id);
    if (!payment) throw new NotFoundError('Payment not found');
    return apiSuccess({
      receiptNumber: payment.receiptNumber,
      amount: payment.amount,
      currency: payment.currency,
      status: payment.status,
      paidAt: payment.updatedAt,
      fee: payment.fee,
      student: payment.student,
      razorpayPaymentId: payment.razorpayPaymentId,
    });
  },

  async studentPayments(req: NextRequest, params: { id: string }) {
    const ctx = await authorize(req, [...READ_ROLES]);
    await assertOwnsStudent(ctx, params.id);
    const { items, totalItems } = await paymentRepository.findMany({ studentId: params.id, page: 1, pageSize: 100 });
    const totalPages = Math.max(1, Math.ceil(totalItems / 100));
    return apiPaginated(items, { page: 1, pageSize: 100, totalItems, totalPages, hasNextPage: false, hasPreviousPage: false });
  },
};
