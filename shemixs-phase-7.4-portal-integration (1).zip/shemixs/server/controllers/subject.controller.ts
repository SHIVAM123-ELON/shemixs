import type { NextRequest } from 'next/server';
import { authorize, parseSearchParams } from './base.controller';
import { subjectService } from '../services/subject.service';
import { moduleRoles } from '../constants/roles';
import { apiPaginated, apiSuccess } from '../lib/api-response';
import {
  createSubjectSchema,
  updateSubjectSchema,
  assignSubjectCourseSchema,
  assignSubjectTeachersSchema,
  subjectListQuerySchema,
} from '../validators/subject.validators';
import { idParamSchema } from '../validators/common.validators';

const ROLES = moduleRoles('subjects');

export const subjectController = {
  async list(req: NextRequest) {
    await authorize(req, ROLES);
    const query = subjectListQuerySchema.parse(parseSearchParams(req));
    const { items, pagination } = await subjectService.list(query);
    return apiPaginated(items, pagination);
  },

  async getById(req: NextRequest, params: { id: string }) {
    await authorize(req, ROLES);
    const { id } = idParamSchema.parse(params);
    const subject = await subjectService.getById(id);
    return apiSuccess(subject);
  },

  async create(req: NextRequest) {
    const ctx = await authorize(req, ROLES);
    const body = createSubjectSchema.parse(await req.json());
    const subject = await subjectService.create(body, ctx);
    return apiSuccess(subject, { status: 201, message: 'Subject created successfully' });
  },

  async update(req: NextRequest, params: { id: string }) {
    const ctx = await authorize(req, ROLES);
    const { id } = idParamSchema.parse(params);
    const body = updateSubjectSchema.parse(await req.json());
    const subject = await subjectService.update(id, body, ctx);
    return apiSuccess(subject, { message: 'Subject updated successfully' });
  },

  async assignCourse(req: NextRequest, params: { id: string }) {
    const ctx = await authorize(req, ROLES);
    const { id } = idParamSchema.parse(params);
    const body = assignSubjectCourseSchema.parse(await req.json());
    const subject = await subjectService.assignCourse(id, body.courseId, ctx);
    return apiSuccess(subject, { message: 'Course assigned successfully' });
  },

  async assignTeachers(req: NextRequest, params: { id: string }) {
    const ctx = await authorize(req, ROLES);
    const { id } = idParamSchema.parse(params);
    const body = assignSubjectTeachersSchema.parse(await req.json());
    const subject = await subjectService.assignTeachers(id, body.teacherIds, ctx);
    return apiSuccess(subject, { message: 'Teachers assigned successfully' });
  },

  async remove(req: NextRequest, params: { id: string }) {
    const ctx = await authorize(req, ROLES);
    const { id } = idParamSchema.parse(params);
    await subjectService.softDelete(id, ctx);
    return apiSuccess(null, { message: 'Subject deleted successfully' });
  },
};
