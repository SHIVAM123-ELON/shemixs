import type { NextRequest } from 'next/server';
import { authorize, parseSearchParams } from './base.controller';
import { homeworkService } from '../services/homework.service';
import { moduleRoles } from '../constants/roles';
import { apiPaginated, apiSuccess } from '../lib/api-response';
import { createHomeworkSchema, updateHomeworkSchema, homeworkListQuerySchema } from '../validators/homework.validators';
import { idParamSchema } from '../validators/common.validators';

const ROLES = moduleRoles('homework');

export const homeworkController = {
  async list(req: NextRequest) {
    await authorize(req, ROLES);
    const query = homeworkListQuerySchema.parse(parseSearchParams(req));
    const { items, pagination } = await homeworkService.list(query);
    return apiPaginated(items, pagination);
  },

  async getById(req: NextRequest, params: { id: string }) {
    await authorize(req, ROLES);
    const { id } = idParamSchema.parse(params);
    const homework = await homeworkService.getById(id);
    return apiSuccess(homework);
  },

  async create(req: NextRequest) {
    const ctx = await authorize(req, ROLES);
    const body = createHomeworkSchema.parse(await req.json());
    const homework = await homeworkService.create(body, ctx);
    return apiSuccess(homework, { status: 201, message: 'Homework created successfully' });
  },

  async update(req: NextRequest, params: { id: string }) {
    const ctx = await authorize(req, ROLES);
    const { id } = idParamSchema.parse(params);
    const body = updateHomeworkSchema.parse(await req.json());
    const homework = await homeworkService.update(id, body, ctx);
    return apiSuccess(homework, { message: 'Homework updated successfully' });
  },

  async publish(req: NextRequest, params: { id: string }) {
    const ctx = await authorize(req, ROLES);
    const { id } = idParamSchema.parse(params);
    const homework = await homeworkService.publish(id, ctx);
    return apiSuccess(homework, { message: 'Homework published' });
  },

  async unpublish(req: NextRequest, params: { id: string }) {
    const ctx = await authorize(req, ROLES);
    const { id } = idParamSchema.parse(params);
    const homework = await homeworkService.unpublish(id, ctx);
    return apiSuccess(homework, { message: 'Homework moved to draft' });
  },

  async remove(req: NextRequest, params: { id: string }) {
    const ctx = await authorize(req, ROLES);
    const { id } = idParamSchema.parse(params);
    await homeworkService.softDelete(id, ctx);
    return apiSuccess(null, { message: 'Homework deleted successfully' });
  },
};
