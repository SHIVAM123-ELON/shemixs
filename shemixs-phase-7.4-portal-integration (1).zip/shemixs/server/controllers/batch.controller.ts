import type { NextRequest } from 'next/server';
import { authorize, parseSearchParams } from './base.controller';
import { batchService } from '../services/batch.service';
import { moduleRoles } from '../constants/roles';
import { apiPaginated, apiSuccess } from '../lib/api-response';
import {
  createBatchSchema,
  updateBatchSchema,
  updateBatchStatusSchema,
  assignBatchStudentsSchema,
  assignBatchTeachersSchema,
  batchListQuerySchema,
} from '../validators/batch.validators';
import { idParamSchema } from '../validators/common.validators';

const ROLES = moduleRoles('batches');

export const batchController = {
  async list(req: NextRequest) {
    await authorize(req, ROLES);
    const query = batchListQuerySchema.parse(parseSearchParams(req));
    const { items, pagination } = await batchService.list(query);
    return apiPaginated(items, pagination);
  },

  async getById(req: NextRequest, params: { id: string }) {
    await authorize(req, ROLES);
    const { id } = idParamSchema.parse(params);
    const batch = await batchService.getById(id);
    return apiSuccess(batch);
  },

  async create(req: NextRequest) {
    const ctx = await authorize(req, ROLES);
    const body = createBatchSchema.parse(await req.json());
    const batch = await batchService.create(body, ctx);
    return apiSuccess(batch, { status: 201, message: 'Batch created successfully' });
  },

  async update(req: NextRequest, params: { id: string }) {
    const ctx = await authorize(req, ROLES);
    const { id } = idParamSchema.parse(params);
    const body = updateBatchSchema.parse(await req.json());
    const batch = await batchService.update(id, body, ctx);
    return apiSuccess(batch, { message: 'Batch updated successfully' });
  },

  async updateStatus(req: NextRequest, params: { id: string }) {
    const ctx = await authorize(req, ROLES);
    const { id } = idParamSchema.parse(params);
    const body = updateBatchStatusSchema.parse(await req.json());
    const batch = await batchService.updateStatus(id, body, ctx);
    return apiSuccess(batch, { message: 'Batch status updated' });
  },

  async assignStudents(req: NextRequest, params: { id: string }) {
    const ctx = await authorize(req, ROLES);
    const { id } = idParamSchema.parse(params);
    const body = assignBatchStudentsSchema.parse(await req.json());
    const batch = await batchService.assignStudents(id, body.studentIds, ctx);
    return apiSuccess(batch, { message: 'Students assigned successfully' });
  },

  async assignTeachers(req: NextRequest, params: { id: string }) {
    const ctx = await authorize(req, ROLES);
    const { id } = idParamSchema.parse(params);
    const body = assignBatchTeachersSchema.parse(await req.json());
    const batch = await batchService.assignTeachers(id, body.teacherIds, ctx);
    return apiSuccess(batch, { message: 'Teachers assigned successfully' });
  },

  async remove(req: NextRequest, params: { id: string }) {
    const ctx = await authorize(req, ROLES);
    const { id } = idParamSchema.parse(params);
    await batchService.softDelete(id, ctx);
    return apiSuccess(null, { message: 'Batch deleted successfully' });
  },
};
