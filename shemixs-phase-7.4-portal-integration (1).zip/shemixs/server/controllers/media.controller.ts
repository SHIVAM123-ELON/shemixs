import type { NextRequest } from 'next/server';
import { z } from 'zod';
import { authorize, parseSearchParams } from './base.controller';
import { mediaService } from '../services/media.service';
import { uploadService } from '../cloudinary/upload.service';
import { deleteService } from '../cloudinary/delete.service';
import { replaceService } from '../cloudinary/replace.service';
import { cloudinaryService } from '../cloudinary/cloudinary.service';
import { apiPaginated, apiSuccess } from '../lib/api-response';
import { ValidationError } from '../lib/errors';
import {
  uploadMediaFieldsSchema,
  replaceMediaFieldsSchema,
  deleteMediaSchema,
  bulkDeleteMediaSchema,
  mediaListQuerySchema,
} from '../cloudinary/validators';

// Media touches nearly every role (a teacher uploads homework PDFs, a
// student uploads assignment submissions, admins manage profile
// photos) — RBAC here is intentionally broader than a typical module
// and mostly relies on authentication + entity-level checks upstream
// (e.g. a student can only be the entityId on their own submission)
// rather than a fixed role allow-list.
const ALL_STAFF_AND_STUDENT_ROLES = [
  'SUPER_ADMIN', 'ADMIN', 'PRINCIPAL', 'COORDINATOR', 'TEACHER', 'STUDENT', 'PARENT', 'ACCOUNTANT', 'RECEPTIONIST',
] as const;

const signatureRequestSchema = z.object({
  folder: z.string().min(1),
});

export const mediaController = {
  async list(req: NextRequest) {
    await authorize(req, [...ALL_STAFF_AND_STUDENT_ROLES]);
    const query = mediaListQuerySchema.parse(parseSearchParams(req));
    const { items, pagination } = await mediaService.list(query);
    return apiPaginated(items, pagination);
  },

  async getById(req: NextRequest, params: { id: string }) {
    await authorize(req, [...ALL_STAFF_AND_STUDENT_ROLES]);
    const media = await mediaService.getById(params.id);
    return apiSuccess(media);
  },

  async upload(req: NextRequest) {
    const ctx = await authorize(req, [...ALL_STAFF_AND_STUDENT_ROLES]);

    const formData = await req.formData();
    const file = formData.get('file');
    if (!(file instanceof File)) {
      throw new ValidationError('A "file" field is required in the multipart form data');
    }

    const fields = uploadMediaFieldsSchema.parse({
      category: formData.get('category'),
      entityType: formData.get('entityType') ?? undefined,
      entityId: formData.get('entityId') ?? undefined,
    });

    const media = await uploadService.upload({ file, ...fields }, ctx);
    return apiSuccess(media, { status: 201, message: 'Media uploaded successfully' });
  },

  async replace(req: NextRequest) {
    const ctx = await authorize(req, [...ALL_STAFF_AND_STUDENT_ROLES]);

    const formData = await req.formData();
    const file = formData.get('file');
    if (!(file instanceof File)) {
      throw new ValidationError('A "file" field is required in the multipart form data');
    }

    const { mediaId } = replaceMediaFieldsSchema.parse({ mediaId: formData.get('mediaId') });
    const media = await replaceService.replace(mediaId, file, ctx);
    return apiSuccess(media, { message: 'Media replaced successfully' });
  },

  async delete(req: NextRequest) {
    const ctx = await authorize(req, [...ALL_STAFF_AND_STUDENT_ROLES]);
    const body = deleteMediaSchema.parse(await req.json());
    await deleteService.deleteOne(body.mediaId, ctx);
    return apiSuccess(null, { message: 'Media deleted successfully' });
  },

  async bulkDelete(req: NextRequest) {
    const ctx = await authorize(req, [...ALL_STAFF_AND_STUDENT_ROLES]);
    const body = bulkDeleteMediaSchema.parse(await req.json());
    const result = await deleteService.deleteBulk(body.mediaIds, ctx);
    return apiSuccess(result, { message: `Deleted ${result.deleted} of ${body.mediaIds.length} item(s)` });
  },

  /** Issues a short-lived signature so the frontend can upload directly to Cloudinary for large files. */
  async signature(req: NextRequest) {
    await authorize(req, [...ALL_STAFF_AND_STUDENT_ROLES]);
    const body = signatureRequestSchema.parse(await req.json());
    const signature = cloudinaryService.generateUploadSignature({ folder: body.folder });
    return apiSuccess(signature);
  },
};
