import type { NextRequest } from 'next/server';
import { authorize, parseSearchParams } from './base.controller';
import { certificateService } from '../services/certificate.service';
import { moduleRoles } from '../constants/roles';
import { apiPaginated, apiSuccess } from '../lib/api-response';
import { issueCertificateSchema, certificateListQuerySchema } from '../validators/certificate.validators';
import { idParamSchema } from '../validators/common.validators';

const ROLES = moduleRoles('certificates');

export const certificateController = {
  async list(req: NextRequest) {
    await authorize(req, ROLES);
    const query = certificateListQuerySchema.parse(parseSearchParams(req));
    const { items, pagination } = await certificateService.list(query);
    return apiPaginated(items, pagination);
  },

  async getById(req: NextRequest, params: { id: string }) {
    await authorize(req, ROLES);
    const { id } = idParamSchema.parse(params);
    const certificate = await certificateService.getById(id);
    return apiSuccess(certificate);
  },

  /** Deliberately no authorize() call — certificate verification is a
   *  public-facing check (e.g. an employer scanning a QR code), not an
   *  internal ERP operation. Only the verification code (not the
   *  internal id) is accepted, and the response reveals no PII beyond
   *  the student's name. */
  async verify(req: NextRequest, params: { code: string }) {
    const result = await certificateService.verify(params.code);
    return apiSuccess(result);
  },

  async issue(req: NextRequest) {
    const ctx = await authorize(req, ROLES);
    const body = issueCertificateSchema.parse(await req.json());
    const certificate = await certificateService.issue(body, ctx);
    return apiSuccess(certificate, { status: 201, message: 'Certificate issued successfully' });
  },

  async revoke(req: NextRequest, params: { id: string }) {
    const ctx = await authorize(req, ROLES);
    const { id } = idParamSchema.parse(params);
    const certificate = await certificateService.revoke(id, ctx);
    return apiSuccess(certificate, { message: 'Certificate revoked' });
  },

  async studentHistory(req: NextRequest, params: { id: string }) {
    await authorize(req, ROLES);
    const { id } = idParamSchema.parse(params);
    const history = await certificateService.studentHistory(id);
    return apiSuccess(history);
  },
};
