import type { NextRequest } from 'next/server';
import { authorize, parseSearchParams } from './base.controller';
import { admissionService } from '../services/admission.service';
import { moduleRoles } from '../constants/roles';
import { apiPaginated, apiSuccess } from '../lib/api-response';
import {
  createAdmissionSchema,
  updateAdmissionSchema,
  verifyAdmissionSchema,
  approveAdmissionSchema,
  rejectAdmissionSchema,
  admissionListQuerySchema,
} from '../validators/admission.validators';
import { idParamSchema } from '../validators/common.validators';

const ROLES = moduleRoles('admissions');

export const admissionController = {
  async list(req: NextRequest) {
    await authorize(req, ROLES);
    const query = admissionListQuerySchema.parse(parseSearchParams(req));
    const { items, pagination } = await admissionService.list(query);
    return apiPaginated(items, pagination);
  },

  async getById(req: NextRequest, params: { id: string }) {
    await authorize(req, ROLES);
    const { id } = idParamSchema.parse(params);
    const admission = await admissionService.getById(id);
    return apiSuccess(admission);
  },

  async timeline(req: NextRequest, params: { id: string }) {
    await authorize(req, ROLES);
    const { id } = idParamSchema.parse(params);
    const admission = await admissionService.timeline(id);
    return apiSuccess({ events: admission.events });
  },

  async create(req: NextRequest) {
    const ctx = await authorize(req, ROLES);
    const body = createAdmissionSchema.parse(await req.json());
    const admission = await admissionService.create(body, ctx);
    return apiSuccess(admission, { status: 201, message: 'Admission application submitted' });
  },

  async update(req: NextRequest, params: { id: string }) {
    const ctx = await authorize(req, ROLES);
    const { id } = idParamSchema.parse(params);
    const body = updateAdmissionSchema.parse(await req.json());
    const admission = await admissionService.update(id, body, ctx);
    return apiSuccess(admission, { message: 'Admission updated successfully' });
  },

  async verify(req: NextRequest, params: { id: string }) {
    const ctx = await authorize(req, ROLES);
    const { id } = idParamSchema.parse(params);
    const body = verifyAdmissionSchema.parse(await req.json().catch(() => ({})));
    const admission = await admissionService.verify(id, body, ctx);
    return apiSuccess(admission, { message: 'Admission verified' });
  },

  async approve(req: NextRequest, params: { id: string }) {
    const ctx = await authorize(req, ROLES);
    const { id } = idParamSchema.parse(params);
    const body = approveAdmissionSchema.parse(await req.json().catch(() => ({})));
    const result = await admissionService.approve(id, body, ctx);
    return apiSuccess(result, { message: 'Admission approved and student created' });
  },

  async reject(req: NextRequest, params: { id: string }) {
    const ctx = await authorize(req, ROLES);
    const { id } = idParamSchema.parse(params);
    const body = rejectAdmissionSchema.parse(await req.json());
    const admission = await admissionService.reject(id, body, ctx);
    return apiSuccess(admission, { message: 'Admission rejected' });
  },
};
