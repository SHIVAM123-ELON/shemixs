import type { NextRequest } from 'next/server';
import { authorize, parseSearchParams } from './base.controller';
import { assertOwnsStudent } from './ownership';
import { feeService } from '../services/fee.service';
import { apiPaginated, apiSuccess } from '../lib/api-response';
import { createFeeSchema, updateFeeSchema, feeListQuerySchema } from '../razorpay/validators';

const STAFF_ROLES = ['SUPER_ADMIN', 'ADMIN', 'ACCOUNTANT'] as const;
const READ_ROLES = ['SUPER_ADMIN', 'ADMIN', 'ACCOUNTANT', 'STUDENT', 'PARENT'] as const;

export const feeController = {
  async list(req: NextRequest) {
    await authorize(req, [...READ_ROLES]);
    const query = feeListQuerySchema.parse(parseSearchParams(req));
    const { items, pagination } = await feeService.list(query);
    return apiPaginated(items, pagination);
  },

  async getById(req: NextRequest, params: { id: string }) {
    await authorize(req, [...READ_ROLES]);
    const fee = await feeService.getById(params.id);
    return apiSuccess(fee);
  },

  async create(req: NextRequest) {
    const ctx = await authorize(req, [...STAFF_ROLES]);
    const body = createFeeSchema.parse(await req.json());
    const fee = await feeService.create(body, ctx);
    return apiSuccess(fee, { status: 201, message: 'Fee created successfully' });
  },

  async update(req: NextRequest, params: { id: string }) {
    const ctx = await authorize(req, [...STAFF_ROLES]);
    const body = updateFeeSchema.parse(await req.json());
    const fee = await feeService.update(params.id, body, ctx);
    return apiSuccess(fee, { message: 'Fee updated successfully' });
  },

  async remove(req: NextRequest, params: { id: string }) {
    const ctx = await authorize(req, [...STAFF_ROLES]);
    await feeService.softDelete(params.id, ctx);
    return apiSuccess(null, { message: 'Fee deleted successfully' });
  },

  async studentFees(req: NextRequest, params: { id: string }) {
    const ctx = await authorize(req, [...READ_ROLES]);
    await assertOwnsStudent(ctx, params.id);
    const { items, pagination } = await feeService.list({ studentId: params.id, page: 1, pageSize: 100 });
    return apiPaginated(items, pagination);
  },
};
