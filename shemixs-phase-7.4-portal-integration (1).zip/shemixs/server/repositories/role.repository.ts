import type { Role, RoleName } from '@prisma/client';
import { BaseRepository } from './base.repository';
import type { TransactionClient } from '../db/transaction';

export class RoleRepository extends BaseRepository {
  async findByName(name: RoleName, tx?: TransactionClient): Promise<Role | null> {
    return this.db(tx).role.findUnique({ where: { name } });
  }

  async findWithPermissions(roleId: string, tx?: TransactionClient) {
    return this.db(tx).role.findUnique({
      where: { id: roleId },
      include: { rolePermissions: { include: { permission: true } } },
    });
  }
}

export const roleRepository = new RoleRepository();
