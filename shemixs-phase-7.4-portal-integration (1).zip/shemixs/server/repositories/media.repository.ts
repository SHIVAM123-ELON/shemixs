import type { Prisma } from '@prisma/client';
import { BaseRepository } from './base.repository';
import type { TransactionClient } from '../db/transaction';

export interface MediaListFilters {
  category?: string;
  entityType?: string;
  entityId?: string;
  uploadedBy?: string;
  page: number;
  pageSize: number;
}

export class MediaRepository extends BaseRepository {
  async findMany(filters: MediaListFilters, tx?: TransactionClient) {
    const where: Prisma.MediaWhereInput = {
      deletedAt: null,
      ...(filters.category ? { category: filters.category } : {}),
      ...(filters.entityType ? { entityType: filters.entityType } : {}),
      ...(filters.entityId ? { entityId: filters.entityId } : {}),
      ...(filters.uploadedBy ? { uploadedBy: filters.uploadedBy } : {}),
    };

    const [items, totalItems] = await Promise.all([
      this.db(tx).media.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        skip: (filters.page - 1) * filters.pageSize,
        take: filters.pageSize,
      }),
      this.db(tx).media.count({ where }),
    ]);

    return { items, totalItems };
  }

  async findById(id: string, tx?: TransactionClient) {
    return this.db(tx).media.findFirst({ where: { id, deletedAt: null } });
  }

  async findByIds(ids: string[], tx?: TransactionClient) {
    return this.db(tx).media.findMany({ where: { id: { in: ids }, deletedAt: null } });
  }

  async create(data: Prisma.MediaUncheckedCreateInput, tx?: TransactionClient) {
    return this.db(tx).media.create({ data });
  }

  async update(id: string, data: Prisma.MediaUncheckedUpdateInput, tx?: TransactionClient) {
    return this.db(tx).media.update({ where: { id }, data });
  }

  async softDelete(id: string, tx?: TransactionClient) {
    return this.db(tx).media.update({ where: { id }, data: { deletedAt: new Date() } });
  }

  async softDeleteMany(ids: string[], tx?: TransactionClient) {
    await this.db(tx).media.updateMany({ where: { id: { in: ids } }, data: { deletedAt: new Date() } });
  }
}

export const mediaRepository = new MediaRepository();
