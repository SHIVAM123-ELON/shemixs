import type { Prisma } from '@prisma/client';
import { BaseRepository } from './base.repository';
import type { TransactionClient } from '../db/transaction';
import { toPrismaBaseWhere, toPrismaOrderBy, toPrismaSkipTake, type ListQuery } from '../lib/query';

const SECTION_SORT_FIELDS = ['createdAt', 'updatedAt', 'name'] as const;

const sectionInclude = {
  batch: { select: { id: true, name: true } },
  _count: { select: { students: true } },
} satisfies Prisma.SectionInclude;

export interface SectionListFilters extends ListQuery {
  batchId?: string;
}

export class SectionRepository extends BaseRepository {
  async findMany(filters: SectionListFilters, tx?: TransactionClient) {
    const where: Prisma.SectionWhereInput = {
      ...toPrismaBaseWhere(filters),
      ...(filters.batchId ? { batchId: filters.batchId } : {}),
      ...(filters.search ? { name: { contains: filters.search, mode: 'insensitive' } } : {}),
    };

    const [items, totalItems] = await Promise.all([
      this.db(tx).section.findMany({
        where,
        include: sectionInclude,
        orderBy: toPrismaOrderBy(filters, SECTION_SORT_FIELDS),
        ...toPrismaSkipTake(filters),
      }),
      this.db(tx).section.count({ where }),
    ]);

    return { items, totalItems };
  }

  async findById(id: string, tx?: TransactionClient) {
    return this.db(tx).section.findFirst({ where: { id, deletedAt: null }, include: sectionInclude });
  }

  async create(data: Prisma.SectionUncheckedCreateInput, tx?: TransactionClient) {
    return this.db(tx).section.create({ data, include: sectionInclude });
  }

  async update(id: string, data: Prisma.SectionUncheckedUpdateInput, tx?: TransactionClient) {
    return this.db(tx).section.update({ where: { id }, data, include: sectionInclude });
  }

  async softDelete(id: string, tx?: TransactionClient) {
    return this.db(tx).section.update({ where: { id }, data: { deletedAt: new Date() } });
  }

  async assignStudents(sectionId: string, studentIds: string[], tx?: TransactionClient) {
    await this.db(tx).student.updateMany({ where: { id: { in: studentIds } }, data: { sectionId } });
    return this.findById(sectionId, tx);
  }
}

export const sectionRepository = new SectionRepository();
