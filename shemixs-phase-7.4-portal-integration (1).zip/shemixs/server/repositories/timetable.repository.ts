import type { Prisma, DayOfWeek } from '@prisma/client';
import { BaseRepository } from './base.repository';
import type { TransactionClient } from '../db/transaction';

const timetableInclude = {
  batch: { select: { id: true, name: true } },
  section: { select: { id: true, name: true } },
  subject: { select: { id: true, name: true, code: true } },
  teacher: { select: { id: true, user: { select: { fullName: true } } } },
} satisfies Prisma.TimetableEntryInclude;

export interface TimetableFilters {
  batchId?: string;
  sectionId?: string;
  teacherId?: string;
  dayOfWeek?: DayOfWeek;
}

export class TimetableRepository extends BaseRepository {
  async findMany(filters: TimetableFilters, tx?: TransactionClient) {
    const where: Prisma.TimetableEntryWhereInput = {
      deletedAt: null,
      ...(filters.batchId ? { batchId: filters.batchId } : {}),
      ...(filters.sectionId ? { sectionId: filters.sectionId } : {}),
      ...(filters.teacherId ? { teacherId: filters.teacherId } : {}),
      ...(filters.dayOfWeek ? { dayOfWeek: filters.dayOfWeek } : {}),
    };

    return this.db(tx).timetableEntry.findMany({
      where,
      include: timetableInclude,
      orderBy: [{ dayOfWeek: 'asc' }, { startTime: 'asc' }],
    });
  }

  async findById(id: string, tx?: TransactionClient) {
    return this.db(tx).timetableEntry.findFirst({ where: { id, deletedAt: null }, include: timetableInclude });
  }

  /**
   * A teacher or a section can't be in two places at once. Finds any
   * existing entry for the same teacher OR section, on the same day,
   * whose time range overlaps the proposed one. `excludeId` lets
   * `update` check without flagging itself as a conflict.
   */
  async findConflicts(
    input: { teacherId?: string; sectionId?: string; dayOfWeek: DayOfWeek; startTime: string; endTime: string },
    excludeId?: string,
    tx?: TransactionClient
  ) {
    const overlapCondition: Prisma.TimetableEntryWhereInput = {
      dayOfWeek: input.dayOfWeek,
      deletedAt: null,
      startTime: { lt: input.endTime },
      endTime: { gt: input.startTime },
      ...(excludeId ? { NOT: { id: excludeId } } : {}),
    };

    const orConditions: Prisma.TimetableEntryWhereInput[] = [];
    if (input.teacherId) orConditions.push({ ...overlapCondition, teacherId: input.teacherId });
    if (input.sectionId) orConditions.push({ ...overlapCondition, sectionId: input.sectionId });

    if (orConditions.length === 0) return [];

    return this.db(tx).timetableEntry.findMany({ where: { OR: orConditions }, include: timetableInclude });
  }

  async create(data: Prisma.TimetableEntryUncheckedCreateInput, tx?: TransactionClient) {
    return this.db(tx).timetableEntry.create({ data, include: timetableInclude });
  }

  async update(id: string, data: Prisma.TimetableEntryUncheckedUpdateInput, tx?: TransactionClient) {
    return this.db(tx).timetableEntry.update({ where: { id }, data, include: timetableInclude });
  }

  async softDelete(id: string, tx?: TransactionClient) {
    return this.db(tx).timetableEntry.update({ where: { id }, data: { deletedAt: new Date() } });
  }
}

export const timetableRepository = new TimetableRepository();
