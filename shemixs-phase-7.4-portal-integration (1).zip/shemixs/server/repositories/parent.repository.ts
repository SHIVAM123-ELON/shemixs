import type { Prisma } from '@prisma/client';
import { BaseRepository } from './base.repository';
import type { TransactionClient } from '../db/transaction';
import { toPrismaBaseWhere, toPrismaOrderBy, toPrismaSkipTake, type ListQuery } from '../lib/query';

const PARENT_SORT_FIELDS = ['createdAt', 'updatedAt'] as const;

const parentInclude = {
  user: { select: { id: true, fullName: true, email: true, phone: true, avatar: true, status: true } },
  studentLinks: {
    include: {
      student: {
        select: { id: true, admissionNo: true, user: { select: { fullName: true, email: true } } },
      },
    },
  },
} satisfies Prisma.ParentInclude;

export class ParentRepository extends BaseRepository {
  async findMany(filters: ListQuery, tx?: TransactionClient) {
    const where: Prisma.ParentWhereInput = {
      ...toPrismaBaseWhere(filters),
      ...(filters.search
        ? {
            OR: [
              { user: { fullName: { contains: filters.search, mode: 'insensitive' } } },
              { user: { email: { contains: filters.search, mode: 'insensitive' } } },
            ],
          }
        : {}),
    };

    const [items, totalItems] = await Promise.all([
      this.db(tx).parent.findMany({
        where,
        include: parentInclude,
        orderBy: toPrismaOrderBy(filters, PARENT_SORT_FIELDS),
        ...toPrismaSkipTake(filters),
      }),
      this.db(tx).parent.count({ where }),
    ]);

    return { items, totalItems };
  }

  async findById(id: string, tx?: TransactionClient) {
    return this.db(tx).parent.findFirst({ where: { id, deletedAt: null }, include: parentInclude });
  }

  async create(data: Prisma.ParentUncheckedCreateInput, tx?: TransactionClient) {
    return this.db(tx).parent.create({ data, include: parentInclude });
  }

  async update(id: string, data: Prisma.ParentUncheckedUpdateInput, tx?: TransactionClient) {
    return this.db(tx).parent.update({ where: { id }, data, include: parentInclude });
  }

  async softDelete(id: string, tx?: TransactionClient) {
    return this.db(tx).parent.update({ where: { id }, data: { deletedAt: new Date() } });
  }

  async linkStudent(parentId: string, studentId: string, relationship: string | undefined, tx?: TransactionClient) {
    return this.db(tx).parentStudent.upsert({
      where: { parentId_studentId: { parentId, studentId } },
      update: { relationship },
      create: { parentId, studentId, relationship },
    });
  }

  async unlinkStudent(parentId: string, studentId: string, tx?: TransactionClient) {
    await this.db(tx).parentStudent.deleteMany({ where: { parentId, studentId } });
  }

  async findLink(parentId: string, studentId: string, tx?: TransactionClient) {
    return this.db(tx).parentStudent.findUnique({ where: { parentId_studentId: { parentId, studentId } } });
  }
}

export const parentRepository = new ParentRepository();
