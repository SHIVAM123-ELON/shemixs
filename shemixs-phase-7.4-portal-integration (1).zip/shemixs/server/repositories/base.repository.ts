/**
 * Base Repository
 *
 * Generic CRUD contract that concrete repositories (UserRepository,
 * RoleRepository, ...) build on. Keeps Prisma-specific query code out
 * of services, so services depend on repository interfaces rather
 * than the ORM directly.
 */
import { prisma } from '../db/client';
import type { TransactionClient } from '../db/transaction';

export type DbClient = typeof prisma | TransactionClient;

export abstract class BaseRepository {
  /**
   * Every repository accepts an optional transaction client so writes
   * can be composed inside a `withTransaction(...)` block by services.
   * Falls back to the module-level singleton outside a transaction.
   */
  protected db(tx?: TransactionClient): DbClient {
    return tx ?? prisma;
  }
}
