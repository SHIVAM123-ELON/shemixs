import type { Prisma } from '@prisma/client';
import { BaseRepository } from './base.repository';
import type { TransactionClient } from '../db/transaction';
import { toPrismaBaseWhere, toPrismaOrderBy, toPrismaSkipTake, type ListQuery } from '../lib/query';

const SUBJECT_SORT_FIELDS = ['createdAt', 'updatedAt', 'name', 'code'] as const;

const subjectInclude = {
  course: { select: { id: true, title: true } },
  teachers: { include: { teacher: { select: { id: true, user: { select: { fullName: true } } } } } },
} satisfies Prisma.SubjectInclude;

export interface SubjectListFilters extends ListQuery {
  courseId?: string;
}

export class SubjectRepository extends BaseRepository {
  async findMany(filters: SubjectListFilters, tx?: TransactionClient) {
    const where: Prisma.SubjectWhereInput = {
      ...toPrismaBaseWhere(filters),
      ...(filters.courseId ? { courseId: filters.courseId } : {}),
      ...(filters.search
        ? { OR: [{ name: { contains: filters.search, mode: 'insensitive' } }, { code: { contains: filters.search, mode: 'insensitive' } }] }
        : {}),
    };

    const [items, totalItems] = await Promise.all([
      this.db(tx).subject.findMany({
        where,
        include: subjectInclude,
        orderBy: toPrismaOrderBy(filters, SUBJECT_SORT_FIELDS),
        ...toPrismaSkipTake(filters),
      }),
      this.db(tx).subject.count({ where }),
    ]);

    return { items, totalItems };
  }

  async findById(id: string, tx?: TransactionClient) {
    return this.db(tx).subject.findFirst({ where: { id, deletedAt: null }, include: subjectInclude });
  }

  async findByCode(code: string, tx?: TransactionClient) {
    return this.db(tx).subject.findFirst({ where: { code, deletedAt: null } });
  }

  async create(data: Prisma.SubjectUncheckedCreateInput, tx?: TransactionClient) {
    return this.db(tx).subject.create({ data, include: subjectInclude });
  }

  async update(id: string, data: Prisma.SubjectUncheckedUpdateInput, tx?: TransactionClient) {
    return this.db(tx).subject.update({ where: { id }, data, include: subjectInclude });
  }

  async softDelete(id: string, tx?: TransactionClient) {
    return this.db(tx).subject.update({ where: { id }, data: { deletedAt: new Date() } });
  }

  async replaceTeachers(subjectId: string, teacherIds: string[], tx?: TransactionClient) {
    const db = this.db(tx);
    await db.teacherSubject.deleteMany({ where: { subjectId } });
    if (teacherIds.length > 0) {
      await db.teacherSubject.createMany({
        data: teacherIds.map((teacherId) => ({ subjectId, teacherId })),
        skipDuplicates: true,
      });
    }
    return this.findById(subjectId, tx);
  }
}

export const subjectRepository = new SubjectRepository();
