import type { Prisma } from '@prisma/client';
import { BaseRepository } from './base.repository';
import type { TransactionClient } from '../db/transaction';
import { toPrismaBaseWhere, toPrismaOrderBy, toPrismaSkipTake, type ListQuery } from '../lib/query';

const HOMEWORK_SORT_FIELDS = ['createdAt', 'updatedAt', 'dueDate', 'title'] as const;

const homeworkInclude = {
  subject: { select: { id: true, name: true, code: true } },
  batch: { select: { id: true, name: true } },
  section: { select: { id: true, name: true } },
  teacher: { select: { id: true, user: { select: { fullName: true } } } },
} satisfies Prisma.HomeworkInclude;

export interface HomeworkListFilters extends ListQuery {
  status?: string;
  subjectId?: string;
  batchId?: string;
  teacherId?: string;
}

export class HomeworkRepository extends BaseRepository {
  async findMany(filters: HomeworkListFilters, tx?: TransactionClient) {
    const where: Prisma.HomeworkWhereInput = {
      ...toPrismaBaseWhere(filters),
      ...(filters.status ? { status: filters.status } : {}),
      ...(filters.subjectId ? { subjectId: filters.subjectId } : {}),
      ...(filters.batchId ? { batchId: filters.batchId } : {}),
      ...(filters.teacherId ? { teacherId: filters.teacherId } : {}),
      ...(filters.search ? { title: { contains: filters.search, mode: 'insensitive' } } : {}),
    };

    const [items, totalItems] = await Promise.all([
      this.db(tx).homework.findMany({
        where,
        include: homeworkInclude,
        orderBy: toPrismaOrderBy(filters, HOMEWORK_SORT_FIELDS),
        ...toPrismaSkipTake(filters),
      }),
      this.db(tx).homework.count({ where }),
    ]);

    return { items, totalItems };
  }

  async findById(id: string, tx?: TransactionClient) {
    return this.db(tx).homework.findFirst({ where: { id, deletedAt: null }, include: homeworkInclude });
  }

  async create(data: Prisma.HomeworkUncheckedCreateInput, tx?: TransactionClient) {
    return this.db(tx).homework.create({ data, include: homeworkInclude });
  }

  async update(id: string, data: Prisma.HomeworkUncheckedUpdateInput, tx?: TransactionClient) {
    return this.db(tx).homework.update({ where: { id }, data, include: homeworkInclude });
  }

  async softDelete(id: string, tx?: TransactionClient) {
    return this.db(tx).homework.update({ where: { id }, data: { deletedAt: new Date() } });
  }
}

export const homeworkRepository = new HomeworkRepository();
