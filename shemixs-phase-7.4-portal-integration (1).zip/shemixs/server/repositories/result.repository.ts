import type { Prisma } from '@prisma/client';
import { BaseRepository } from './base.repository';
import type { TransactionClient } from '../db/transaction';

const resultInclude = {
  test: { select: { id: true, title: true, maxMarks: true } },
  student: { select: { id: true, userId: true, user: { select: { fullName: true } } } },
} satisfies Prisma.ResultInclude;

export interface ResultListFilters {
  testId?: string;
  studentId?: string;
  status?: string;
}

export class ResultRepository extends BaseRepository {
  async findMany(filters: ResultListFilters, tx?: TransactionClient) {
    const where: Prisma.ResultWhereInput = {
      ...(filters.testId ? { testId: filters.testId } : {}),
      ...(filters.studentId ? { studentId: filters.studentId } : {}),
      ...(filters.status ? { status: filters.status } : {}),
    };
    return this.db(tx).result.findMany({ where, include: resultInclude, orderBy: [{ rank: 'asc' }] });
  }

  async findById(id: string, tx?: TransactionClient) {
    return this.db(tx).result.findUnique({ where: { id }, include: resultInclude });
  }

  async findByTestAndStudent(testId: string, studentId: string, tx?: TransactionClient) {
    return this.db(tx).result.findUnique({ where: { testId_studentId: { testId, studentId } } });
  }

  async upsert(testId: string, studentId: string, marksObtained: number | undefined, grade: string | undefined, tx?: TransactionClient) {
    return this.db(tx).result.upsert({
      where: { testId_studentId: { testId, studentId } },
      update: { marksObtained, grade },
      create: { testId, studentId, marksObtained, grade, status: 'DRAFT' },
      include: resultInclude,
    });
  }

  async update(id: string, data: Prisma.ResultUncheckedUpdateInput, tx?: TransactionClient) {
    return this.db(tx).result.update({ where: { id }, data, include: resultInclude });
  }

  async findAllForTest(testId: string, tx?: TransactionClient) {
    return this.db(tx).result.findMany({ where: { testId }, orderBy: { marksObtained: 'desc' } });
  }

  async setRank(id: string, rank: number, tx?: TransactionClient) {
    return this.db(tx).result.update({ where: { id }, data: { rank } });
  }

  async publishAllForTest(testId: string, tx?: TransactionClient) {
    await this.db(tx).result.updateMany({ where: { testId }, data: { status: 'PUBLISHED' } });
  }

  async studentHistory(studentId: string, tx?: TransactionClient) {
    return this.db(tx).result.findMany({
      where: { studentId, status: 'PUBLISHED' },
      include: resultInclude,
      orderBy: { createdAt: 'desc' },
    });
  }
}

export const resultRepository = new ResultRepository();
