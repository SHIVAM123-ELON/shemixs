import type { AuditAction } from '@prisma/client';
import { BaseRepository } from './base.repository';
import type { TransactionClient } from '../db/transaction';

export interface CreateAuditLogInput {
  userId?: string;
  userRole?: string;
  module: string;
  action: AuditAction;
  entityId?: string;
  before?: unknown;
  after?: unknown;
  ipAddress?: string;
  userAgent?: string;
}

export class AuditLogRepository extends BaseRepository {
  async create(input: CreateAuditLogInput, tx?: TransactionClient) {
    return this.db(tx).auditLog.create({
      data: {
        userId: input.userId,
        userRole: input.userRole,
        module: input.module,
        action: input.action,
        entityId: input.entityId,
        before: input.before === undefined ? undefined : (input.before as object),
        after: input.after === undefined ? undefined : (input.after as object),
        ipAddress: input.ipAddress,
        userAgent: input.userAgent,
      },
    });
  }

  async listForEntity(module: string, entityId: string, tx?: TransactionClient) {
    return this.db(tx).auditLog.findMany({
      where: { module, entityId },
      orderBy: { createdAt: 'desc' },
    });
  }
}

export const auditLogRepository = new AuditLogRepository();
