import type { Prisma, StudentStatus } from '@prisma/client';
import { BaseRepository } from './base.repository';
import type { TransactionClient } from '../db/transaction';
import { toPrismaBaseWhere, toPrismaOrderBy, toPrismaSkipTake, type ListQuery } from '../lib/query';

const STUDENT_SORT_FIELDS = ['createdAt', 'updatedAt', 'admissionNo'] as const;

const studentInclude = {
  user: { select: { id: true, fullName: true, email: true, phone: true, avatar: true, status: true } },
  batch: { select: { id: true, name: true } },
  section: { select: { id: true, name: true } },
} satisfies Prisma.StudentInclude;

export interface StudentListFilters extends ListQuery {
  status?: StudentStatus;
  batchId?: string;
  sectionId?: string;
}

export class StudentRepository extends BaseRepository {
  async findMany(filters: StudentListFilters, tx?: TransactionClient) {
    const where: Prisma.StudentWhereInput = {
      ...toPrismaBaseWhere(filters),
      ...(filters.status ? { status: filters.status } : {}),
      ...(filters.batchId ? { batchId: filters.batchId } : {}),
      ...(filters.sectionId ? { sectionId: filters.sectionId } : {}),
      ...(filters.search
        ? {
            OR: [
              { admissionNo: { contains: filters.search, mode: 'insensitive' } },
              { user: { fullName: { contains: filters.search, mode: 'insensitive' } } },
              { user: { email: { contains: filters.search, mode: 'insensitive' } } },
            ],
          }
        : {}),
    };

    const [items, totalItems] = await Promise.all([
      this.db(tx).student.findMany({
        where,
        include: studentInclude,
        orderBy: toPrismaOrderBy(filters, STUDENT_SORT_FIELDS),
        ...toPrismaSkipTake(filters),
      }),
      this.db(tx).student.count({ where }),
    ]);

    return { items, totalItems };
  }

  async findById(id: string, tx?: TransactionClient) {
    return this.db(tx).student.findFirst({
      where: { id, deletedAt: null },
      include: studentInclude,
    });
  }

  async findByUserId(userId: string, tx?: TransactionClient) {
    return this.db(tx).student.findFirst({ where: { userId, deletedAt: null } });
  }

  async findByAdmissionNo(admissionNo: string, tx?: TransactionClient) {
    return this.db(tx).student.findFirst({ where: { admissionNo, deletedAt: null } });
  }

  async create(data: Prisma.StudentUncheckedCreateInput, tx?: TransactionClient) {
    return this.db(tx).student.create({ data, include: studentInclude });
  }

  async update(id: string, data: Prisma.StudentUncheckedUpdateInput, tx?: TransactionClient) {
    return this.db(tx).student.update({ where: { id }, data, include: studentInclude });
  }

  async softDelete(id: string, tx?: TransactionClient) {
    return this.db(tx).student.update({ where: { id }, data: { deletedAt: new Date() } });
  }

  async restore(id: string, tx?: TransactionClient) {
    return this.db(tx).student.update({ where: { id }, data: { deletedAt: null } });
  }

  /** Bypasses the deletedAt:null filter — used only by the restore flow to confirm the record exists at all. */
  async findByIdIncludingDeleted(id: string, tx?: TransactionClient) {
    return this.db(tx).student.findUnique({ where: { id }, include: studentInclude });
  }
}

export const studentRepository = new StudentRepository();
