import type { Session } from '@prisma/client';
import { BaseRepository } from './base.repository';
import type { TransactionClient } from '../db/transaction';

export class SessionRepository extends BaseRepository {
  async create(
    data: {
      userId: string;
      refreshToken: string;
      device?: string;
      browser?: string;
      ipAddress?: string;
      expiresAt: Date;
    },
    tx?: TransactionClient
  ): Promise<Session> {
    return this.db(tx).session.create({ data });
  }

  async findByRefreshToken(refreshToken: string, tx?: TransactionClient): Promise<Session | null> {
    return this.db(tx).session.findUnique({ where: { refreshToken } });
  }

  async revoke(sessionId: string, tx?: TransactionClient): Promise<Session> {
    return this.db(tx).session.update({
      where: { id: sessionId },
      data: { revoked: true, revokedAt: new Date() },
    });
  }

  async revokeByRefreshToken(refreshToken: string, tx?: TransactionClient): Promise<void> {
    await this.db(tx).session.updateMany({
      where: { refreshToken },
      data: { revoked: true, revokedAt: new Date() },
    });
  }

  async revokeAllForUser(userId: string, tx?: TransactionClient): Promise<void> {
    await this.db(tx).session.updateMany({
      where: { userId, revoked: false },
      data: { revoked: true, revokedAt: new Date() },
    });
  }
}

export const sessionRepository = new SessionRepository();
