import type { Prisma } from '@prisma/client';
import { BaseRepository } from './base.repository';
import type { TransactionClient } from '../db/transaction';
import { toPrismaBaseWhere, toPrismaOrderBy, toPrismaSkipTake, type ListQuery } from '../lib/query';

const BATCH_SORT_FIELDS = ['createdAt', 'updatedAt', 'name'] as const;

const batchInclude = {
  teachers: { include: { teacher: { select: { id: true, user: { select: { fullName: true } } } } } },
  _count: { select: { students: true } },
} satisfies Prisma.BatchInclude;

export interface BatchListFilters extends ListQuery {
  status?: string;
}

export class BatchRepository extends BaseRepository {
  async findMany(filters: BatchListFilters, tx?: TransactionClient) {
    const where: Prisma.BatchWhereInput = {
      ...toPrismaBaseWhere(filters),
      ...(filters.status ? { status: filters.status } : {}),
      ...(filters.search ? { name: { contains: filters.search, mode: 'insensitive' } } : {}),
    };

    const [items, totalItems] = await Promise.all([
      this.db(tx).batch.findMany({
        where,
        include: batchInclude,
        orderBy: toPrismaOrderBy(filters, BATCH_SORT_FIELDS),
        ...toPrismaSkipTake(filters),
      }),
      this.db(tx).batch.count({ where }),
    ]);

    return { items, totalItems };
  }

  async findById(id: string, tx?: TransactionClient) {
    return this.db(tx).batch.findFirst({ where: { id, deletedAt: null }, include: batchInclude });
  }

  async create(data: Prisma.BatchUncheckedCreateInput, tx?: TransactionClient) {
    return this.db(tx).batch.create({ data, include: batchInclude });
  }

  async update(id: string, data: Prisma.BatchUncheckedUpdateInput, tx?: TransactionClient) {
    return this.db(tx).batch.update({ where: { id }, data, include: batchInclude });
  }

  async softDelete(id: string, tx?: TransactionClient) {
    return this.db(tx).batch.update({ where: { id }, data: { deletedAt: new Date() } });
  }

  async studentCount(id: string, tx?: TransactionClient) {
    return this.db(tx).student.count({ where: { batchId: id, deletedAt: null } });
  }

  async assignStudents(batchId: string, studentIds: string[], tx?: TransactionClient) {
    await this.db(tx).student.updateMany({ where: { id: { in: studentIds } }, data: { batchId } });
    return this.findById(batchId, tx);
  }

  async replaceTeachers(batchId: string, teacherIds: string[], tx?: TransactionClient) {
    const db = this.db(tx);
    await db.batchTeacher.deleteMany({ where: { batchId } });
    if (teacherIds.length > 0) {
      await db.batchTeacher.createMany({
        data: teacherIds.map((teacherId) => ({ batchId, teacherId })),
        skipDuplicates: true,
      });
    }
    return this.findById(batchId, tx);
  }
}

export const batchRepository = new BatchRepository();
