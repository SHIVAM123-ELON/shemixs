import type { Prisma } from '@prisma/client';
import { BaseRepository } from './base.repository';
import type { TransactionClient } from '../db/transaction';
import { toPrismaBaseWhere, toPrismaOrderBy, toPrismaSkipTake, type ListQuery } from '../lib/query';

const TEST_SORT_FIELDS = ['createdAt', 'updatedAt', 'scheduledAt', 'title'] as const;

const testInclude = {
  subject: { select: { id: true, name: true, code: true } },
  batch: { select: { id: true, name: true } },
  teacher: { select: { id: true, user: { select: { fullName: true } } } },
  questions: { orderBy: { order: 'asc' } },
} satisfies Prisma.TestInclude;

export interface TestListFilters extends ListQuery {
  status?: string;
  type?: string;
  mode?: string;
  subjectId?: string;
  batchId?: string;
}

export class TestRepository extends BaseRepository {
  async findMany(filters: TestListFilters, tx?: TransactionClient) {
    const where: Prisma.TestWhereInput = {
      ...toPrismaBaseWhere(filters),
      ...(filters.status ? { status: filters.status } : {}),
      ...(filters.type ? ({ type: filters.type } as Prisma.TestWhereInput) : {}),
      ...(filters.mode ? ({ mode: filters.mode } as Prisma.TestWhereInput) : {}),
      ...(filters.subjectId ? { subjectId: filters.subjectId } : {}),
      ...(filters.batchId ? { batchId: filters.batchId } : {}),
      ...(filters.search ? { title: { contains: filters.search, mode: 'insensitive' } } : {}),
    };

    const [items, totalItems] = await Promise.all([
      this.db(tx).test.findMany({
        where,
        include: testInclude,
        orderBy: toPrismaOrderBy(filters, TEST_SORT_FIELDS),
        ...toPrismaSkipTake(filters),
      }),
      this.db(tx).test.count({ where }),
    ]);

    return { items, totalItems };
  }

  async findById(id: string, tx?: TransactionClient) {
    return this.db(tx).test.findFirst({ where: { id, deletedAt: null }, include: testInclude });
  }

  async create(data: Prisma.TestUncheckedCreateInput, tx?: TransactionClient) {
    return this.db(tx).test.create({ data, include: testInclude });
  }

  async update(id: string, data: Prisma.TestUncheckedUpdateInput, tx?: TransactionClient) {
    return this.db(tx).test.update({ where: { id }, data, include: testInclude });
  }

  async softDelete(id: string, tx?: TransactionClient) {
    return this.db(tx).test.update({ where: { id }, data: { deletedAt: new Date() } });
  }

  async createQuestions(testId: string, questions: Prisma.TestQuestionCreateManyInput[], tx?: TransactionClient) {
    if (questions.length === 0) return;
    await this.db(tx).testQuestion.createMany({ data: questions.map((q) => ({ ...q, testId })) });
  }
}

export const testRepository = new TestRepository();
