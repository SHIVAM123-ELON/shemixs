import type { Prisma } from '@prisma/client';
import { BaseRepository } from './base.repository';
import type { TransactionClient } from '../db/transaction';
import { toPrismaBaseWhere, toPrismaOrderBy, toPrismaSkipTake, type ListQuery } from '../lib/query';

const COURSE_SORT_FIELDS = ['createdAt', 'updatedAt', 'title', 'status'] as const;

const courseInclude = {
  instructors: { include: { teacher: { select: { id: true, user: { select: { fullName: true } } } } } },
  chapters: { include: { lessons: true }, orderBy: { order: 'asc' } },
} satisfies Prisma.CourseInclude;

export interface CourseListFilters extends ListQuery {
  status?: string;
  category?: string;
}

export class CourseRepository extends BaseRepository {
  async findMany(filters: CourseListFilters, tx?: TransactionClient) {
    const where: Prisma.CourseWhereInput = {
      ...toPrismaBaseWhere(filters),
      ...(filters.status ? { status: filters.status } : {}),
      ...(filters.category ? { category: filters.category } : {}),
      ...(filters.search ? { title: { contains: filters.search, mode: 'insensitive' } } : {}),
    };

    const [items, totalItems] = await Promise.all([
      this.db(tx).course.findMany({
        where,
        include: courseInclude,
        orderBy: toPrismaOrderBy(filters, COURSE_SORT_FIELDS),
        ...toPrismaSkipTake(filters),
      }),
      this.db(tx).course.count({ where }),
    ]);

    return { items, totalItems };
  }

  async findById(id: string, tx?: TransactionClient) {
    return this.db(tx).course.findFirst({ where: { id, deletedAt: null }, include: courseInclude });
  }

  async findBySlug(slug: string, tx?: TransactionClient) {
    return this.db(tx).course.findFirst({ where: { slug, deletedAt: null } });
  }

  async create(data: Prisma.CourseUncheckedCreateInput, tx?: TransactionClient) {
    return this.db(tx).course.create({ data, include: courseInclude });
  }

  async update(id: string, data: Prisma.CourseUncheckedUpdateInput, tx?: TransactionClient) {
    return this.db(tx).course.update({ where: { id }, data, include: courseInclude });
  }

  async softDelete(id: string, tx?: TransactionClient) {
    return this.db(tx).course.update({ where: { id }, data: { deletedAt: new Date() } });
  }

  async replaceInstructors(courseId: string, teacherIds: string[], tx?: TransactionClient) {
    const db = this.db(tx);
    await db.courseInstructor.deleteMany({ where: { courseId } });
    if (teacherIds.length > 0) {
      await db.courseInstructor.createMany({
        data: teacherIds.map((teacherId) => ({ courseId, teacherId })),
        skipDuplicates: true,
      });
    }
    return this.findById(courseId, tx);
  }
}

export const courseRepository = new CourseRepository();
