import type { Prisma } from '@prisma/client';
import { BaseRepository } from './base.repository';
import type { TransactionClient } from '../db/transaction';

export interface NotificationListFilters {
  userId: string;
  channel?: string;
  status?: string;
  page: number;
  pageSize: number;
}

export class NotificationRepository extends BaseRepository {
  async findMany(filters: NotificationListFilters, tx?: TransactionClient) {
    const where: Prisma.NotificationWhereInput = {
      userId: filters.userId,
      ...(filters.channel ? ({ channel: filters.channel } as Prisma.NotificationWhereInput) : {}),
      ...(filters.status ? ({ status: filters.status } as Prisma.NotificationWhereInput) : {}),
    };

    const [items, totalItems, unreadCount] = await Promise.all([
      this.db(tx).notification.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        skip: (filters.page - 1) * filters.pageSize,
        take: filters.pageSize,
      }),
      this.db(tx).notification.count({ where }),
      this.db(tx).notification.count({ where: { userId: filters.userId, channel: 'IN_APP', readAt: null } }),
    ]);

    return { items, totalItems, unreadCount };
  }

  async findById(id: string, tx?: TransactionClient) {
    return this.db(tx).notification.findUnique({ where: { id } });
  }

  async create(data: Prisma.NotificationUncheckedCreateInput, tx?: TransactionClient) {
    return this.db(tx).notification.create({ data });
  }

  async update(id: string, data: Prisma.NotificationUncheckedUpdateInput, tx?: TransactionClient) {
    return this.db(tx).notification.update({ where: { id }, data });
  }

  async markRead(id: string, tx?: TransactionClient) {
    return this.db(tx).notification.update({ where: { id }, data: { status: 'READ', readAt: new Date() } });
  }

  async markAllRead(userId: string, tx?: TransactionClient) {
    await this.db(tx).notification.updateMany({
      where: { userId, channel: 'IN_APP', readAt: null },
      data: { status: 'READ', readAt: new Date() },
    });
  }
}

export const notificationRepository = new NotificationRepository();
