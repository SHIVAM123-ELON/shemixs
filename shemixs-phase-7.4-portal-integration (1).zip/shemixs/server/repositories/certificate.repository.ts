import type { Prisma } from '@prisma/client';
import { BaseRepository } from './base.repository';
import type { TransactionClient } from '../db/transaction';
import { toPrismaBaseWhere, toPrismaOrderBy, toPrismaSkipTake, type ListQuery } from '../lib/query';

const CERTIFICATE_SORT_FIELDS = ['createdAt', 'issuedAt', 'type'] as const;

const certificateInclude = {
  student: { select: { id: true, admissionNo: true, user: { select: { fullName: true, email: true } } } },
} satisfies Prisma.CertificateInclude;

export interface CertificateListFilters extends ListQuery {
  status?: string;
  studentId?: string;
  type?: string;
}

export class CertificateRepository extends BaseRepository {
  async findMany(filters: CertificateListFilters, tx?: TransactionClient) {
    const where: Prisma.CertificateWhereInput = {
      ...toPrismaBaseWhere(filters),
      ...(filters.status ? ({ status: filters.status } as Prisma.CertificateWhereInput) : {}),
      ...(filters.studentId ? { studentId: filters.studentId } : {}),
      ...(filters.type ? { type: filters.type } : {}),
      ...(filters.search ? { title: { contains: filters.search, mode: 'insensitive' } } : {}),
    };

    const [items, totalItems] = await Promise.all([
      this.db(tx).certificate.findMany({
        where,
        include: certificateInclude,
        orderBy: toPrismaOrderBy(filters, CERTIFICATE_SORT_FIELDS, 'issuedAt'),
        ...toPrismaSkipTake(filters),
      }),
      this.db(tx).certificate.count({ where }),
    ]);

    return { items, totalItems };
  }

  async findById(id: string, tx?: TransactionClient) {
    return this.db(tx).certificate.findFirst({ where: { id, deletedAt: null }, include: certificateInclude });
  }

  async findByVerificationCode(code: string, tx?: TransactionClient) {
    return this.db(tx).certificate.findFirst({ where: { verificationCode: code, deletedAt: null }, include: certificateInclude });
  }

  async create(data: Prisma.CertificateUncheckedCreateInput, tx?: TransactionClient) {
    return this.db(tx).certificate.create({ data, include: certificateInclude });
  }

  async revoke(id: string, tx?: TransactionClient) {
    return this.db(tx).certificate.update({
      where: { id },
      data: { status: 'REVOKED', revokedAt: new Date() },
      include: certificateInclude,
    });
  }

  async studentHistory(studentId: string, tx?: TransactionClient) {
    return this.db(tx).certificate.findMany({
      where: { studentId, deletedAt: null },
      include: certificateInclude,
      orderBy: { issuedAt: 'desc' },
    });
  }
}

export const certificateRepository = new CertificateRepository();
