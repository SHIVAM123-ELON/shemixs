import type { Prisma, AdmissionStatus } from '@prisma/client';
import { BaseRepository } from './base.repository';
import type { TransactionClient } from '../db/transaction';
import { toPrismaBaseWhere, toPrismaOrderBy, toPrismaSkipTake, type ListQuery } from '../lib/query';

const ADMISSION_SORT_FIELDS = ['createdAt', 'updatedAt', 'applicantName', 'status'] as const;

const admissionInclude = {
  desiredBatch: { select: { id: true, name: true } },
  events: { orderBy: { createdAt: 'desc' } },
} satisfies Prisma.AdmissionInclude;

export interface AdmissionListFilters extends ListQuery {
  status?: AdmissionStatus;
}

export class AdmissionRepository extends BaseRepository {
  async findMany(filters: AdmissionListFilters, tx?: TransactionClient) {
    const where: Prisma.AdmissionWhereInput = {
      ...toPrismaBaseWhere(filters),
      ...(filters.status ? { status: filters.status } : {}),
      ...(filters.search
        ? {
            OR: [
              { applicantName: { contains: filters.search, mode: 'insensitive' } },
              { email: { contains: filters.search, mode: 'insensitive' } },
            ],
          }
        : {}),
    };

    const [items, totalItems] = await Promise.all([
      this.db(tx).admission.findMany({
        where,
        include: admissionInclude,
        orderBy: toPrismaOrderBy(filters, ADMISSION_SORT_FIELDS),
        ...toPrismaSkipTake(filters),
      }),
      this.db(tx).admission.count({ where }),
    ]);

    return { items, totalItems };
  }

  async findById(id: string, tx?: TransactionClient) {
    return this.db(tx).admission.findFirst({ where: { id, deletedAt: null }, include: admissionInclude });
  }

  async create(data: Prisma.AdmissionUncheckedCreateInput, tx?: TransactionClient) {
    return this.db(tx).admission.create({ data, include: admissionInclude });
  }

  async update(id: string, data: Prisma.AdmissionUncheckedUpdateInput, tx?: TransactionClient) {
    return this.db(tx).admission.update({ where: { id }, data, include: admissionInclude });
  }

  async addEvent(admissionId: string, status: AdmissionStatus, note: string | undefined, actorUserId: string | undefined, tx?: TransactionClient) {
    return this.db(tx).admissionEvent.create({ data: { admissionId, status, note, actorUserId } });
  }
}

export const admissionRepository = new AdmissionRepository();
