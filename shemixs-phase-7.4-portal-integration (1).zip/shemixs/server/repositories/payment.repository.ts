import type { Prisma } from '@prisma/client';
import { BaseRepository } from './base.repository';
import type { TransactionClient } from '../db/transaction';

export interface PaymentListFilters {
  studentId?: string;
  status?: string;
  page: number;
  pageSize: number;
}

const paymentInclude = {
  fee: { select: { id: true, title: true, amount: true } },
  student: { select: { id: true, userId: true, user: { select: { fullName: true, email: true } } } },
} satisfies Prisma.PaymentInclude;

export class PaymentRepository extends BaseRepository {
  async findMany(filters: PaymentListFilters, tx?: TransactionClient) {
    const where: Prisma.PaymentWhereInput = {
      ...(filters.studentId ? { studentId: filters.studentId } : {}),
      ...(filters.status ? ({ status: filters.status } as Prisma.PaymentWhereInput) : {}),
    };

    const [items, totalItems] = await Promise.all([
      this.db(tx).payment.findMany({
        where,
        include: paymentInclude,
        orderBy: { createdAt: 'desc' },
        skip: (filters.page - 1) * filters.pageSize,
        take: filters.pageSize,
      }),
      this.db(tx).payment.count({ where }),
    ]);

    return { items, totalItems };
  }

  async findById(id: string, tx?: TransactionClient) {
    return this.db(tx).payment.findUnique({ where: { id }, include: paymentInclude });
  }

  async findByRazorpayOrderId(orderId: string, tx?: TransactionClient) {
    return this.db(tx).payment.findUnique({ where: { razorpayOrderId: orderId }, include: paymentInclude });
  }

  async create(data: Prisma.PaymentUncheckedCreateInput, tx?: TransactionClient) {
    return this.db(tx).payment.create({ data, include: paymentInclude });
  }

  async update(id: string, data: Prisma.PaymentUncheckedUpdateInput, tx?: TransactionClient) {
    return this.db(tx).payment.update({ where: { id }, data, include: paymentInclude });
  }
}

export const paymentRepository = new PaymentRepository();
