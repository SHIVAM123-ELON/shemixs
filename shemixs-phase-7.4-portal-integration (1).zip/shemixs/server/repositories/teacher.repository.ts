import type { Prisma, TeacherStatus } from '@prisma/client';
import { BaseRepository } from './base.repository';
import type { TransactionClient } from '../db/transaction';
import { toPrismaBaseWhere, toPrismaOrderBy, toPrismaSkipTake, type ListQuery } from '../lib/query';

const TEACHER_SORT_FIELDS = ['createdAt', 'updatedAt', 'employeeCode', 'department'] as const;

const teacherInclude = {
  user: { select: { id: true, fullName: true, email: true, phone: true, avatar: true, status: true } },
  subjects: { include: { subject: { select: { id: true, name: true, code: true } } } },
} satisfies Prisma.TeacherInclude;

export interface TeacherListFilters extends ListQuery {
  status?: TeacherStatus;
  department?: string;
}

export class TeacherRepository extends BaseRepository {
  async findMany(filters: TeacherListFilters, tx?: TransactionClient) {
    const where: Prisma.TeacherWhereInput = {
      ...toPrismaBaseWhere(filters),
      ...(filters.status ? { status: filters.status } : {}),
      ...(filters.department ? { department: filters.department } : {}),
      ...(filters.search
        ? {
            OR: [
              { employeeCode: { contains: filters.search, mode: 'insensitive' } },
              { user: { fullName: { contains: filters.search, mode: 'insensitive' } } },
              { user: { email: { contains: filters.search, mode: 'insensitive' } } },
            ],
          }
        : {}),
    };

    const [items, totalItems] = await Promise.all([
      this.db(tx).teacher.findMany({
        where,
        include: teacherInclude,
        orderBy: toPrismaOrderBy(filters, TEACHER_SORT_FIELDS),
        ...toPrismaSkipTake(filters),
      }),
      this.db(tx).teacher.count({ where }),
    ]);

    return { items, totalItems };
  }

  async findById(id: string, tx?: TransactionClient) {
    return this.db(tx).teacher.findFirst({ where: { id, deletedAt: null }, include: teacherInclude });
  }

  async findByEmployeeCode(employeeCode: string, tx?: TransactionClient) {
    return this.db(tx).teacher.findFirst({ where: { employeeCode, deletedAt: null } });
  }

  async create(data: Prisma.TeacherUncheckedCreateInput, tx?: TransactionClient) {
    return this.db(tx).teacher.create({ data, include: teacherInclude });
  }

  async update(id: string, data: Prisma.TeacherUncheckedUpdateInput, tx?: TransactionClient) {
    return this.db(tx).teacher.update({ where: { id }, data, include: teacherInclude });
  }

  async softDelete(id: string, tx?: TransactionClient) {
    return this.db(tx).teacher.update({ where: { id }, data: { deletedAt: new Date() } });
  }

  async replaceSubjects(teacherId: string, subjectIds: string[], tx?: TransactionClient) {
    const db = this.db(tx);
    await db.teacherSubject.deleteMany({ where: { teacherId } });
    if (subjectIds.length > 0) {
      await db.teacherSubject.createMany({
        data: subjectIds.map((subjectId) => ({ teacherId, subjectId })),
        skipDuplicates: true,
      });
    }
    return this.findById(teacherId, tx);
  }
}

export const teacherRepository = new TeacherRepository();
