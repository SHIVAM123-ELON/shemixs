import type { Prisma } from '@prisma/client';
import { BaseRepository } from './base.repository';
import type { TransactionClient } from '../db/transaction';

export interface FeeListFilters {
  studentId?: string;
  status?: string;
  page: number;
  pageSize: number;
}

const feeInclude = {
  student: { select: { id: true, admissionNo: true, user: { select: { fullName: true } } } },
} satisfies Prisma.FeeInclude;

export class FeeRepository extends BaseRepository {
  async findMany(filters: FeeListFilters, tx?: TransactionClient) {
    const where: Prisma.FeeWhereInput = {
      deletedAt: null,
      ...(filters.studentId ? { studentId: filters.studentId } : {}),
      ...(filters.status ? ({ status: filters.status } as Prisma.FeeWhereInput) : {}),
    };

    const [items, totalItems] = await Promise.all([
      this.db(tx).fee.findMany({
        where,
        include: feeInclude,
        orderBy: { createdAt: 'desc' },
        skip: (filters.page - 1) * filters.pageSize,
        take: filters.pageSize,
      }),
      this.db(tx).fee.count({ where }),
    ]);

    return { items, totalItems };
  }

  async findById(id: string, tx?: TransactionClient) {
    return this.db(tx).fee.findFirst({ where: { id, deletedAt: null }, include: feeInclude });
  }

  async create(data: Prisma.FeeUncheckedCreateInput, tx?: TransactionClient) {
    return this.db(tx).fee.create({ data, include: feeInclude });
  }

  async update(id: string, data: Prisma.FeeUncheckedUpdateInput, tx?: TransactionClient) {
    return this.db(tx).fee.update({ where: { id }, data, include: feeInclude });
  }

  async softDelete(id: string, tx?: TransactionClient) {
    return this.db(tx).fee.update({ where: { id }, data: { deletedAt: new Date() } });
  }

  /** Sum of successfully PAID payments against a fee — used to derive whether it's now fully/partially settled. */
  async paidTotal(feeId: string, tx?: TransactionClient) {
    const result = await this.db(tx).payment.aggregate({
      where: { feeId, status: 'PAID' },
      _sum: { amount: true },
    });
    return result._sum.amount ?? 0;
  }
}

export const feeRepository = new FeeRepository();
