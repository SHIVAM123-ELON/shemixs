import type { Prisma, AttendanceStatus } from '@prisma/client';
import { BaseRepository } from './base.repository';
import type { TransactionClient } from '../db/transaction';

export interface AttendanceHistoryFilters {
  dateFrom?: Date;
  dateTo?: Date;
  status?: AttendanceStatus;
}

export class AttendanceRepository extends BaseRepository {
  // --- Student attendance -----------------------------------------------

  async upsertStudentAttendance(
    studentId: string,
    date: Date,
    status: AttendanceStatus,
    remarks: string | undefined,
    markedBy: string,
    tx?: TransactionClient
  ) {
    return this.db(tx).studentAttendance.upsert({
      where: { studentId_date: { studentId, date } },
      update: { status, remarks, markedBy },
      create: { studentId, date, status, remarks, markedBy },
    });
  }

  async findStudentAttendanceById(id: string, tx?: TransactionClient) {
    return this.db(tx).studentAttendance.findUnique({ where: { id } });
  }

  async updateStudentAttendance(id: string, data: Prisma.StudentAttendanceUncheckedUpdateInput, tx?: TransactionClient) {
    return this.db(tx).studentAttendance.update({ where: { id }, data });
  }

  async studentHistory(studentId: string, filters: AttendanceHistoryFilters, tx?: TransactionClient) {
    const where: Prisma.StudentAttendanceWhereInput = {
      studentId,
      ...(filters.status ? { status: filters.status } : {}),
      ...(filters.dateFrom || filters.dateTo
        ? { date: { ...(filters.dateFrom ? { gte: filters.dateFrom } : {}), ...(filters.dateTo ? { lte: filters.dateTo } : {}) } }
        : {}),
    };
    return this.db(tx).studentAttendance.findMany({ where, orderBy: { date: 'desc' } });
  }

  /** Aggregate present/absent/late/etc counts for a student or a whole batch/section, for the "Attendance Reports" requirement. */
  async studentReport(where: Prisma.StudentAttendanceWhereInput, tx?: TransactionClient) {
    return this.db(tx).studentAttendance.groupBy({
      by: ['status'],
      where,
      _count: { _all: true },
    });
  }

  // --- Teacher attendance -------------------------------------------------

  async upsertTeacherAttendance(
    teacherId: string,
    date: Date,
    status: AttendanceStatus,
    remarks: string | undefined,
    markedBy: string,
    tx?: TransactionClient
  ) {
    return this.db(tx).teacherAttendance.upsert({
      where: { teacherId_date: { teacherId, date } },
      update: { status, remarks, markedBy },
      create: { teacherId, date, status, remarks, markedBy },
    });
  }

  async findTeacherAttendanceById(id: string, tx?: TransactionClient) {
    return this.db(tx).teacherAttendance.findUnique({ where: { id } });
  }

  async updateTeacherAttendance(id: string, data: Prisma.TeacherAttendanceUncheckedUpdateInput, tx?: TransactionClient) {
    return this.db(tx).teacherAttendance.update({ where: { id }, data });
  }

  async teacherHistory(teacherId: string, filters: AttendanceHistoryFilters, tx?: TransactionClient) {
    const where: Prisma.TeacherAttendanceWhereInput = {
      teacherId,
      ...(filters.status ? { status: filters.status } : {}),
      ...(filters.dateFrom || filters.dateTo
        ? { date: { ...(filters.dateFrom ? { gte: filters.dateFrom } : {}), ...(filters.dateTo ? { lte: filters.dateTo } : {}) } }
        : {}),
    };
    return this.db(tx).teacherAttendance.findMany({ where, orderBy: { date: 'desc' } });
  }
}

export const attendanceRepository = new AttendanceRepository();
