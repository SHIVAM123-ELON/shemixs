import type { User } from '@prisma/client';
import { BaseRepository } from './base.repository';
import type { TransactionClient } from '../db/transaction';

export class UserRepository extends BaseRepository {
  async findByEmail(email: string, tx?: TransactionClient): Promise<User | null> {
    return this.db(tx).user.findFirst({
      where: { email: email.toLowerCase(), deletedAt: null },
      include: { role: true },
    });
  }

  async findById(id: string, tx?: TransactionClient): Promise<User | null> {
    return this.db(tx).user.findFirst({
      where: { id, deletedAt: null },
      include: { role: true },
    });
  }

  async create(
    data: {
      fullName: string;
      email: string;
      phone?: string;
      passwordHash: string;
      roleId: string;
    },
    tx?: TransactionClient
  ): Promise<User> {
    return this.db(tx).user.create({
      data: {
        ...data,
        email: data.email.toLowerCase(),
      },
    });
  }

  async updatePassword(userId: string, passwordHash: string, tx?: TransactionClient): Promise<User> {
    return this.db(tx).user.update({
      where: { id: userId },
      data: { passwordHash },
    });
  }

  async markEmailVerified(userId: string, tx?: TransactionClient): Promise<User> {
    return this.db(tx).user.update({
      where: { id: userId },
      data: { emailVerified: true, status: 'ACTIVE' },
    });
  }

  async updateLastProfile(userId: string, data: Partial<Pick<User, 'fullName' | 'avatar' | 'phone'>>, tx?: TransactionClient): Promise<User> {
    return this.db(tx).user.update({
      where: { id: userId },
      data,
    });
  }
}

export const userRepository = new UserRepository();
