import type { Prisma } from '@prisma/client';
import { BaseRepository } from './base.repository';
import type { TransactionClient } from '../db/transaction';
import { toPrismaBaseWhere, toPrismaOrderBy, toPrismaSkipTake, type ListQuery } from '../lib/query';

const ASSIGNMENT_SORT_FIELDS = ['createdAt', 'updatedAt', 'dueDate', 'title'] as const;

const assignmentInclude = {
  subject: { select: { id: true, name: true, code: true } },
  batch: { select: { id: true, name: true } },
  teacher: { select: { id: true, user: { select: { fullName: true } } } },
} satisfies Prisma.AssignmentInclude;

export interface AssignmentListFilters extends ListQuery {
  status?: string;
  subjectId?: string;
  batchId?: string;
}

export class AssignmentRepository extends BaseRepository {
  async findMany(filters: AssignmentListFilters, tx?: TransactionClient) {
    const where: Prisma.AssignmentWhereInput = {
      ...toPrismaBaseWhere(filters),
      ...(filters.status ? { status: filters.status } : {}),
      ...(filters.subjectId ? { subjectId: filters.subjectId } : {}),
      ...(filters.batchId ? { batchId: filters.batchId } : {}),
      ...(filters.search ? { title: { contains: filters.search, mode: 'insensitive' } } : {}),
    };

    const [items, totalItems] = await Promise.all([
      this.db(tx).assignment.findMany({
        where,
        include: assignmentInclude,
        orderBy: toPrismaOrderBy(filters, ASSIGNMENT_SORT_FIELDS),
        ...toPrismaSkipTake(filters),
      }),
      this.db(tx).assignment.count({ where }),
    ]);

    return { items, totalItems };
  }

  async findById(id: string, tx?: TransactionClient) {
    return this.db(tx).assignment.findFirst({ where: { id, deletedAt: null }, include: assignmentInclude });
  }

  async create(data: Prisma.AssignmentUncheckedCreateInput, tx?: TransactionClient) {
    return this.db(tx).assignment.create({ data, include: assignmentInclude });
  }

  async update(id: string, data: Prisma.AssignmentUncheckedUpdateInput, tx?: TransactionClient) {
    return this.db(tx).assignment.update({ where: { id }, data, include: assignmentInclude });
  }

  async softDelete(id: string, tx?: TransactionClient) {
    return this.db(tx).assignment.update({ where: { id }, data: { deletedAt: new Date() } });
  }

  async listSubmissions(assignmentId: string, tx?: TransactionClient) {
    return this.db(tx).assignmentSubmission.findMany({
      where: { assignmentId },
      include: { student: { select: { id: true, user: { select: { fullName: true } } } } },
      orderBy: { createdAt: 'desc' },
    });
  }

  async upsertSubmission(
    assignmentId: string,
    studentId: string,
    contentUrl: string | undefined,
    isLate: boolean,
    tx?: TransactionClient
  ) {
    return this.db(tx).assignmentSubmission.upsert({
      where: { assignmentId_studentId: { assignmentId, studentId } },
      update: { contentUrl, status: isLate ? 'LATE' : 'SUBMITTED', submittedAt: new Date() },
      create: { assignmentId, studentId, contentUrl, status: isLate ? 'LATE' : 'SUBMITTED', submittedAt: new Date() },
    });
  }

  async findSubmission(assignmentId: string, studentId: string, tx?: TransactionClient) {
    return this.db(tx).assignmentSubmission.findUnique({ where: { assignmentId_studentId: { assignmentId, studentId } } });
  }

  async evaluateSubmission(submissionId: string, marks: number, feedback: string | undefined, tx?: TransactionClient) {
    return this.db(tx).assignmentSubmission.update({
      where: { id: submissionId },
      data: { marks, feedback, status: 'EVALUATED' },
    });
  }
}

export const assignmentRepository = new AssignmentRepository();
