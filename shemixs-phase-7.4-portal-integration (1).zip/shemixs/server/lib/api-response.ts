/**
 * API Response Helper
 *
 * Every route handler returns responses shaped through these helpers
 * so API consumers (the frontend, future mobile clients) can rely on
 * one consistent envelope instead of each route inventing its own.
 */
import { NextResponse } from 'next/server';
import type { PaginationMeta } from './query';

interface SuccessBody<T> {
  success: true;
  data: T;
  message?: string;
  meta?: { pagination?: PaginationMeta } & Record<string, unknown>;
}

interface ErrorBody {
  success: false;
  error: {
    message: string;
    code: string;
    details?: unknown;
  };
}

export function apiSuccess<T>(
  data: T,
  options?: { message?: string; status?: number; meta?: SuccessBody<T>['meta'] }
) {
  const body: SuccessBody<T> = { success: true, data };
  if (options?.message) body.message = options.message;
  if (options?.meta) body.meta = options.meta;
  return NextResponse.json(body, { status: options?.status ?? 200 });
}

/**
 * Convenience wrapper for list endpoints: wraps `items` as `data` and
 * attaches the standard `meta.pagination` block every list response
 * shares.
 */
export function apiPaginated<T>(items: T[], pagination: PaginationMeta, options?: { message?: string }) {
  return apiSuccess(items, { message: options?.message, meta: { pagination } });
}

export function apiError(message: string, options?: { status?: number; code?: string; details?: unknown }) {
  const body: ErrorBody = {
    success: false,
    error: {
      message,
      code: options?.code ?? 'INTERNAL_ERROR',
      ...(options?.details !== undefined ? { details: options.details } : {}),
    },
  };
  return NextResponse.json(body, { status: options?.status ?? 500 });
}
