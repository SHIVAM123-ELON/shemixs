/**
 * Pagination / Search / Sort Query Helper
 *
 * Every list endpoint (GET /api/students, /api/teachers, ...) accepts
 * the same shape of query params and returns the same `meta.pagination`
 * block. This module is the single place that parses those params and
 * builds the corresponding Prisma `skip`/`take`/`orderBy` args, so
 * each module's repository only has to describe *what* fields are
 * searchable/sortable — not re-implement pagination math.
 */
import { z } from 'zod';

export const listQuerySchema = z.object({
  page: z.coerce.number().int().min(1).default(1),
  pageSize: z.coerce.number().int().min(1).max(100).default(20),
  search: z.string().trim().optional(),
  sortBy: z.string().optional(),
  sortOrder: z.enum(['asc', 'desc']).default('desc'),
  status: z.string().optional(),
  dateFrom: z.coerce.date().optional(),
  dateTo: z.coerce.date().optional(),
  createdBy: z.string().uuid().optional(),
  updatedBy: z.string().uuid().optional(),
});

export type ListQuery = z.infer<typeof listQuerySchema>;

export interface PaginationMeta {
  page: number;
  pageSize: number;
  totalItems: number;
  totalPages: number;
  hasNextPage: boolean;
  hasPreviousPage: boolean;
}

export function buildPaginationMeta(query: Pick<ListQuery, 'page' | 'pageSize'>, totalItems: number): PaginationMeta {
  const totalPages = Math.max(1, Math.ceil(totalItems / query.pageSize));
  return {
    page: query.page,
    pageSize: query.pageSize,
    totalItems,
    totalPages,
    hasNextPage: query.page < totalPages,
    hasPreviousPage: query.page > 1,
  };
}

export function toPrismaSkipTake(query: Pick<ListQuery, 'page' | 'pageSize'>) {
  return {
    skip: (query.page - 1) * query.pageSize,
    take: query.pageSize,
  };
}

/**
 * Builds a Prisma `orderBy` object from `sortBy`/`sortOrder`, falling
 * back to `defaultSortField` (usually `createdAt`) if the requested
 * field isn't in the module's allow-list — prevents sorting by an
 * arbitrary/relation field that could error or leak data shape.
 */
export function toPrismaOrderBy(
  query: Pick<ListQuery, 'sortBy' | 'sortOrder'>,
  allowedSortFields: readonly string[],
  defaultSortField = 'createdAt'
) {
  const field = query.sortBy && allowedSortFields.includes(query.sortBy) ? query.sortBy : defaultSortField;
  return { [field]: query.sortOrder };
}

/**
 * Builds the shared `createdAt` date-range + soft-delete Prisma
 * `where` fragment every module needs. Module-specific search/status
 * filters are merged on top by the caller.
 */
export function toPrismaBaseWhere(query: Pick<ListQuery, 'dateFrom' | 'dateTo'>, includeSoftDeleted = false) {
  const where: Record<string, unknown> = {};

  if (!includeSoftDeleted) {
    where.deletedAt = null;
  }

  if (query.dateFrom || query.dateTo) {
    where.createdAt = {
      ...(query.dateFrom ? { gte: query.dateFrom } : {}),
      ...(query.dateTo ? { lte: query.dateTo } : {}),
    };
  }

  return where;
}
