import type { NextRequest } from 'next/server';
import type { RequestMeta } from '../types/auth.types';

/**
 * Extracts device/browser/IP metadata from a request for session
 * tracking. Deliberately lightweight (no UA-parsing dependency) —
 * stores the raw User-Agent string; a dedicated parser can replace
 * this without touching call sites.
 */
export function getRequestMeta(req: NextRequest): RequestMeta {
  const userAgent = req.headers.get('user-agent') ?? undefined;
  const forwardedFor = req.headers.get('x-forwarded-for');
  const ipAddress = forwardedFor?.split(',')[0]?.trim() ?? req.headers.get('x-real-ip') ?? undefined;

  return {
    device: userAgent,
    browser: userAgent,
    ipAddress,
  };
}
