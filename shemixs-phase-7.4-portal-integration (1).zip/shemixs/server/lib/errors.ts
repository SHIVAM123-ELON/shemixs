/**
 * Error Handling
 *
 * A small hierarchy of typed application errors + a single
 * `handleApiError` function that route handlers call from their
 * catch block. This keeps HTTP-status-code decisions out of business
 * logic (services/repositories throw AppError subclasses; only the
 * route layer knows about HTTP).
 */
import { ZodError } from 'zod';
import { logger } from './logger';
import { apiError } from './api-response';

export class AppError extends Error {
  readonly status: number;
  readonly code: string;
  readonly details?: unknown;

  constructor(message: string, status: number, code: string, details?: unknown) {
    super(message);
    this.name = 'AppError';
    this.status = status;
    this.code = code;
    this.details = details;
  }
}

export class ValidationError extends AppError {
  constructor(message = 'Validation failed', details?: unknown) {
    super(message, 422, 'VALIDATION_ERROR', details);
  }
}

export class UnauthorizedError extends AppError {
  constructor(message = 'Authentication required') {
    super(message, 401, 'UNAUTHORIZED');
  }
}

export class ForbiddenError extends AppError {
  constructor(message = 'You do not have permission to perform this action') {
    super(message, 403, 'FORBIDDEN');
  }
}

export class NotFoundError extends AppError {
  constructor(message = 'Resource not found') {
    super(message, 404, 'NOT_FOUND');
  }
}

export class ConflictError extends AppError {
  constructor(message = 'Resource already exists') {
    super(message, 409, 'CONFLICT');
  }
}

export class TooManyRequestsError extends AppError {
  constructor(message = 'Too many requests, please try again later') {
    super(message, 429, 'TOO_MANY_REQUESTS');
  }
}

/**
 * Route handlers wrap their body in try/catch and call this in the
 * catch block. Never leaks internal error messages/stack traces to
 * the client for unrecognized errors — only AppError subclasses
 * (which we authored deliberately) surface their message.
 */
export function handleApiError(error: unknown) {
  if (error instanceof AppError) {
    return apiError(error.message, { status: error.status, code: error.code, details: error.details });
  }

  if (error instanceof ZodError) {
    return apiError('Validation failed', {
      status: 422,
      code: 'VALIDATION_ERROR',
      details: error.flatten(),
    });
  }

  logger.error('Unhandled API error', { error });
  return apiError('Something went wrong. Please try again.', { status: 500, code: 'INTERNAL_ERROR' });
}
