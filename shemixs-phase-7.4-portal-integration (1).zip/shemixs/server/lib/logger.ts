/**
 * Logger
 *
 * Minimal structured logger. Kept dependency-free for this phase —
 * swap the internals for pino/winston later without touching call
 * sites, since everything goes through this module.
 */
type LogLevel = 'debug' | 'info' | 'warn' | 'error';

function log(level: LogLevel, message: string, meta?: Record<string, unknown>) {
  const entry = {
    timestamp: new Date().toISOString(),
    level,
    message,
    ...(meta ? { meta: serializeMeta(meta) } : {}),
  };

  const serialized = JSON.stringify(entry);

  if (level === 'error') console.error(serialized);
  else if (level === 'warn') console.warn(serialized);
  else console.log(serialized);
}

function serializeMeta(meta: Record<string, unknown>) {
  if (meta.error instanceof Error) {
    return {
      ...meta,
      error: { name: meta.error.name, message: meta.error.message, stack: meta.error.stack },
    };
  }
  return meta;
}

export const logger = {
  debug: (message: string, meta?: Record<string, unknown>) => log('debug', message, meta),
  info: (message: string, meta?: Record<string, unknown>) => log('info', message, meta),
  warn: (message: string, meta?: Record<string, unknown>) => log('warn', message, meta),
  error: (message: string, meta?: Record<string, unknown>) => log('error', message, meta),
};
