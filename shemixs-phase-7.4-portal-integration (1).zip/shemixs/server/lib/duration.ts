/**
 * Parses short duration strings like "15m", "30d", "1h" into
 * milliseconds. Mirrors the subset of the `jose`/`jsonwebtoken`
 * expiry string format we actually use in env vars, so a single
 * config value (e.g. JWT_REFRESH_EXPIRES_IN) can drive both the JWT
 * expiration and the corresponding DB/cookie maxAge.
 */
const UNIT_MS: Record<string, number> = {
  s: 1000,
  m: 60 * 1000,
  h: 60 * 60 * 1000,
  d: 24 * 60 * 60 * 1000,
};

export function parseDurationToMs(duration: string): number {
  const match = /^(\d+)\s*(s|m|h|d)$/.exec(duration.trim());
  if (!match) {
    throw new Error(`Invalid duration string: "${duration}". Expected format like "15m", "1h", "30d".`);
  }
  const [, value, unit] = match;
  return Number(value) * UNIT_MS[unit];
}

export function parseDurationToSeconds(duration: string): number {
  return Math.floor(parseDurationToMs(duration) / 1000);
}
