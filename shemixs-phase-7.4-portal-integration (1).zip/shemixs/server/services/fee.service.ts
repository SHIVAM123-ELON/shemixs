import { withTransaction } from '../db/transaction';
import { feeRepository, type FeeListFilters } from '../repositories/fee.repository';
import { auditLogService } from './audit-log.service';
import { NotFoundError } from '../lib/errors';
import type { CreateFeeInput, UpdateFeeInput } from '../razorpay/validators';
import type { ControllerContext } from '../controllers/base.controller';

function buildPagination(filters: { page: number; pageSize: number }, totalItems: number) {
  const totalPages = Math.max(1, Math.ceil(totalItems / filters.pageSize));
  return {
    page: filters.page,
    pageSize: filters.pageSize,
    totalItems,
    totalPages,
    hasNextPage: filters.page < totalPages,
    hasPreviousPage: filters.page > 1,
  };
}

export const feeService = {
  async list(filters: FeeListFilters) {
    const { items, totalItems } = await feeRepository.findMany(filters);
    return { items, pagination: buildPagination(filters, totalItems) };
  },

  async getById(id: string) {
    const fee = await feeRepository.findById(id);
    if (!fee) throw new NotFoundError('Fee not found');
    return fee;
  },

  async create(input: CreateFeeInput, ctx: ControllerContext) {
    return withTransaction(async (tx) => {
      const created = await feeRepository.create(
        { studentId: input.studentId, title: input.title, description: input.description, amount: input.amount, dueDate: input.dueDate, status: 'PENDING' },
        tx
      );
      await auditLogService.record(
        { userId: ctx.userId, userRole: ctx.role, module: 'fees', action: 'CREATE', entityId: created.id, after: created, meta: ctx.meta },
        tx
      );
      return created;
    });
  },

  async update(id: string, input: UpdateFeeInput, ctx: ControllerContext) {
    const existing = await feeRepository.findById(id);
    if (!existing) throw new NotFoundError('Fee not found');

    return withTransaction(async (tx) => {
      const result = await feeRepository.update(id, input, tx);
      await auditLogService.record(
        { userId: ctx.userId, userRole: ctx.role, module: 'fees', action: 'UPDATE', entityId: id, before: existing, after: result, meta: ctx.meta },
        tx
      );
      return result;
    });
  },

  async softDelete(id: string, ctx: ControllerContext) {
    const existing = await feeRepository.findById(id);
    if (!existing) throw new NotFoundError('Fee not found');

    await withTransaction(async (tx) => {
      await feeRepository.softDelete(id, tx);
      await auditLogService.record(
        { userId: ctx.userId, userRole: ctx.role, module: 'fees', action: 'DELETE', entityId: id, before: existing, meta: ctx.meta },
        tx
      );
    });
  },
};
