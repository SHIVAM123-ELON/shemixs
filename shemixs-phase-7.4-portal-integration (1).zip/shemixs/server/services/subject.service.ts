import { withTransaction } from '../db/transaction';
import { subjectRepository, type SubjectListFilters } from '../repositories/subject.repository';
import { auditLogService } from './audit-log.service';
import { buildPaginationMeta } from '../lib/query';
import { ConflictError, NotFoundError } from '../lib/errors';
import type { CreateSubjectInput, UpdateSubjectInput } from '../validators/subject.validators';
import type { ControllerContext } from '../controllers/base.controller';

export const subjectService = {
  async list(filters: SubjectListFilters) {
    const { items, totalItems } = await subjectRepository.findMany(filters);
    return { items, pagination: buildPaginationMeta(filters, totalItems) };
  },

  async getById(id: string) {
    const subject = await subjectRepository.findById(id);
    if (!subject) throw new NotFoundError('Subject not found');
    return subject;
  },

  async create(input: CreateSubjectInput, ctx: ControllerContext) {
    const existing = await subjectRepository.findByCode(input.code);
    if (existing) throw new ConflictError('A subject with this code already exists');

    return withTransaction(async (tx) => {
      const created = await subjectRepository.create(
        { name: input.name, code: input.code, courseId: input.courseId },
        tx
      );
      await auditLogService.record(
        { userId: ctx.userId, userRole: ctx.role, module: 'subjects', action: 'CREATE', entityId: created.id, after: created, meta: ctx.meta },
        tx
      );
      return created;
    });
  },

  async update(id: string, input: UpdateSubjectInput, ctx: ControllerContext) {
    const existing = await subjectRepository.findById(id);
    if (!existing) throw new NotFoundError('Subject not found');

    if (input.code && input.code !== existing.code) {
      const conflict = await subjectRepository.findByCode(input.code);
      if (conflict) throw new ConflictError('A subject with this code already exists');
    }

    return withTransaction(async (tx) => {
      const result = await subjectRepository.update(id, input, tx);
      await auditLogService.record(
        { userId: ctx.userId, userRole: ctx.role, module: 'subjects', action: 'UPDATE', entityId: id, before: existing, after: result, meta: ctx.meta },
        tx
      );
      return result;
    });
  },

  async assignCourse(id: string, courseId: string | null, ctx: ControllerContext) {
    const existing = await subjectRepository.findById(id);
    if (!existing) throw new NotFoundError('Subject not found');

    return withTransaction(async (tx) => {
      const result = await subjectRepository.update(id, { courseId }, tx);
      await auditLogService.record(
        {
          userId: ctx.userId,
          userRole: ctx.role,
          module: 'subjects',
          action: 'ASSIGN',
          entityId: id,
          before: { courseId: existing.courseId },
          after: { courseId },
          meta: ctx.meta,
        },
        tx
      );
      return result;
    });
  },

  async assignTeachers(id: string, teacherIds: string[], ctx: ControllerContext) {
    const existing = await subjectRepository.findById(id);
    if (!existing) throw new NotFoundError('Subject not found');

    return withTransaction(async (tx) => {
      const result = await subjectRepository.replaceTeachers(id, teacherIds, tx);
      await auditLogService.record(
        {
          userId: ctx.userId,
          userRole: ctx.role,
          module: 'subjects',
          action: 'ASSIGN',
          entityId: id,
          before: { teacherIds: existing.teachers.map((t) => t.teacherId) },
          after: { teacherIds },
          meta: ctx.meta,
        },
        tx
      );
      return result;
    });
  },

  async softDelete(id: string, ctx: ControllerContext) {
    const existing = await subjectRepository.findById(id);
    if (!existing) throw new NotFoundError('Subject not found');

    await withTransaction(async (tx) => {
      await subjectRepository.softDelete(id, tx);
      await auditLogService.record(
        { userId: ctx.userId, userRole: ctx.role, module: 'subjects', action: 'DELETE', entityId: id, before: existing, meta: ctx.meta },
        tx
      );
    });
  },
};
