import { withTransaction } from '../db/transaction';
import { sectionRepository, type SectionListFilters } from '../repositories/section.repository';
import { auditLogService } from './audit-log.service';
import { buildPaginationMeta } from '../lib/query';
import { NotFoundError } from '../lib/errors';
import type { CreateSectionInput, UpdateSectionInput } from '../validators/section.validators';
import type { ControllerContext } from '../controllers/base.controller';

export const sectionService = {
  async list(filters: SectionListFilters) {
    const { items, totalItems } = await sectionRepository.findMany(filters);
    return { items, pagination: buildPaginationMeta(filters, totalItems) };
  },

  async getById(id: string) {
    const section = await sectionRepository.findById(id);
    if (!section) throw new NotFoundError('Section not found');
    return section;
  },

  async create(input: CreateSectionInput, ctx: ControllerContext) {
    return withTransaction(async (tx) => {
      const created = await sectionRepository.create({ name: input.name, batchId: input.batchId }, tx);
      await auditLogService.record(
        { userId: ctx.userId, userRole: ctx.role, module: 'sections', action: 'CREATE', entityId: created.id, after: created, meta: ctx.meta },
        tx
      );
      return created;
    });
  },

  async update(id: string, input: UpdateSectionInput, ctx: ControllerContext) {
    const existing = await sectionRepository.findById(id);
    if (!existing) throw new NotFoundError('Section not found');

    return withTransaction(async (tx) => {
      const result = await sectionRepository.update(id, input, tx);
      await auditLogService.record(
        { userId: ctx.userId, userRole: ctx.role, module: 'sections', action: 'UPDATE', entityId: id, before: existing, after: result, meta: ctx.meta },
        tx
      );
      return result;
    });
  },

  /** Batch mapping doubles as "class mapping" — Phase 7.1/7.2 model a
   *  batch as the class-level grouping; there's no separate Class entity. */
  async assignBatch(id: string, batchId: string | null, ctx: ControllerContext) {
    const existing = await sectionRepository.findById(id);
    if (!existing) throw new NotFoundError('Section not found');

    return withTransaction(async (tx) => {
      const result = await sectionRepository.update(id, { batchId }, tx);
      await auditLogService.record(
        {
          userId: ctx.userId,
          userRole: ctx.role,
          module: 'sections',
          action: 'ASSIGN',
          entityId: id,
          before: { batchId: existing.batchId },
          after: { batchId },
          meta: ctx.meta,
        },
        tx
      );
      return result;
    });
  },

  async assignStudents(id: string, studentIds: string[], ctx: ControllerContext) {
    const existing = await sectionRepository.findById(id);
    if (!existing) throw new NotFoundError('Section not found');

    return withTransaction(async (tx) => {
      const result = await sectionRepository.assignStudents(id, studentIds, tx);
      await auditLogService.record(
        { userId: ctx.userId, userRole: ctx.role, module: 'sections', action: 'ASSIGN', entityId: id, after: { studentIds }, meta: ctx.meta },
        tx
      );
      return result;
    });
  },

  async softDelete(id: string, ctx: ControllerContext) {
    const existing = await sectionRepository.findById(id);
    if (!existing) throw new NotFoundError('Section not found');

    await withTransaction(async (tx) => {
      await sectionRepository.softDelete(id, tx);
      await auditLogService.record(
        { userId: ctx.userId, userRole: ctx.role, module: 'sections', action: 'DELETE', entityId: id, before: existing, meta: ctx.meta },
        tx
      );
    });
  },
};
