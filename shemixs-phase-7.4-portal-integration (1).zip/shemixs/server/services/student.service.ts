/**
 * Student Service
 *
 * Creating a student is a multi-row write (a User row with role
 * STUDENT + a Student profile row) — always wrapped in
 * `withTransaction` so a failure partway through never leaves an
 * orphaned User with no Student profile, or vice versa. The audit log
 * entry is written inside the same transaction for the same reason:
 * the record of "who created this" must be exactly as durable as the
 * record itself.
 */
import { prisma } from '../db/client';
import { withTransaction } from '../db/transaction';
import { studentRepository, type StudentListFilters } from '../repositories/student.repository';
import { roleRepository } from '../repositories/role.repository';
import { auditLogService } from './audit-log.service';
import { hashPassword } from '../auth/password';
import { buildPaginationMeta } from '../lib/query';
import { ConflictError, NotFoundError, ValidationError } from '../lib/errors';
import type {
  CreateStudentInput,
  UpdateStudentInput,
  UpdateStudentStatusInput,
  EnrollStudentInput,
} from '../validators/student.validators';
import type { ControllerContext } from '../controllers/base.controller';
import { randomBytes } from 'crypto';

export const studentService = {
  async list(filters: StudentListFilters) {
    const { items, totalItems } = await studentRepository.findMany(filters);
    return { items, pagination: buildPaginationMeta(filters, totalItems) };
  },

  async getById(id: string) {
    const student = await studentRepository.findById(id);
    if (!student) throw new NotFoundError('Student not found');
    return student;
  },

  async create(input: CreateStudentInput, ctx: ControllerContext) {
    if (input.admissionNo) {
      const existing = await studentRepository.findByAdmissionNo(input.admissionNo);
      if (existing) throw new ConflictError('A student with this admission number already exists');
    }

    const studentRole = await roleRepository.findByName('STUDENT');
    if (!studentRole) throw new ValidationError('STUDENT role is not seeded — run the database seed first');

    const student = await withTransaction(async (tx) => {
      // Students are created by staff, not self-registered — a random
      // temporary password is set; the user resets it via the standard
      // forgot-password flow using their email before first login.
      const tempPassword = randomBytes(16).toString('hex');
      const passwordHash = await hashPassword(tempPassword);

      const user = await tx.user.create({
        data: {
          fullName: input.fullName,
          email: input.email.toLowerCase(),
          phone: input.phone,
          passwordHash,
          roleId: studentRole.id,
          status: 'PENDING',
        },
      });

      const created = await studentRepository.create(
        {
          userId: user.id,
          admissionNo: input.admissionNo,
          dateOfBirth: input.dateOfBirth,
          gender: input.gender,
          address: input.address,
          batchId: input.batchId,
          sectionId: input.sectionId,
          status: input.batchId ? 'ACTIVE' : 'ENROLLMENT_PENDING',
        },
        tx
      );

      await auditLogService.record(
        {
          userId: ctx.userId,
          userRole: ctx.role,
          module: 'students',
          action: 'CREATE',
          entityId: created.id,
          after: created,
          meta: ctx.meta,
        },
        tx
      );

      return created;
    });

    return student;
  },

  async update(id: string, input: UpdateStudentInput, ctx: ControllerContext) {
    const existing = await studentRepository.findById(id);
    if (!existing) throw new NotFoundError('Student not found');

    if (input.admissionNo && input.admissionNo !== existing.admissionNo) {
      const conflict = await studentRepository.findByAdmissionNo(input.admissionNo);
      if (conflict) throw new ConflictError('A student with this admission number already exists');
    }

    const updated = await withTransaction(async (tx) => {
      const result = await studentRepository.update(id, input, tx);
      await auditLogService.record(
        {
          userId: ctx.userId,
          userRole: ctx.role,
          module: 'students',
          action: 'UPDATE',
          entityId: id,
          before: existing,
          after: result,
          meta: ctx.meta,
        },
        tx
      );
      return result;
    });

    return updated;
  },

  async updateStatus(id: string, input: UpdateStudentStatusInput, ctx: ControllerContext) {
    const existing = await studentRepository.findById(id);
    if (!existing) throw new NotFoundError('Student not found');

    const updated = await withTransaction(async (tx) => {
      const result = await studentRepository.update(id, { status: input.status }, tx);
      await auditLogService.record(
        {
          userId: ctx.userId,
          userRole: ctx.role,
          module: 'students',
          action: 'UPDATE',
          entityId: id,
          before: { status: existing.status },
          after: { status: input.status, reason: input.reason },
          meta: ctx.meta,
        },
        tx
      );
      return result;
    });

    return updated;
  },

  async enroll(id: string, input: EnrollStudentInput, ctx: ControllerContext) {
    const existing = await studentRepository.findById(id);
    if (!existing) throw new NotFoundError('Student not found');

    const batch = await prisma.batch.findFirst({ where: { id: input.batchId, deletedAt: null } });
    if (!batch) throw new ValidationError('Selected batch does not exist');

    const updated = await withTransaction(async (tx) => {
      const result = await studentRepository.update(
        id,
        { batchId: input.batchId, sectionId: input.sectionId, status: 'ACTIVE' },
        tx
      );
      await auditLogService.record(
        {
          userId: ctx.userId,
          userRole: ctx.role,
          module: 'students',
          action: 'ASSIGN',
          entityId: id,
          before: { batchId: existing.batchId, sectionId: existing.sectionId },
          after: { batchId: input.batchId, sectionId: input.sectionId },
          meta: ctx.meta,
        },
        tx
      );
      return result;
    });

    return updated;
  },

  async softDelete(id: string, ctx: ControllerContext) {
    const existing = await studentRepository.findById(id);
    if (!existing) throw new NotFoundError('Student not found');

    await withTransaction(async (tx) => {
      await studentRepository.softDelete(id, tx);
      await auditLogService.record(
        {
          userId: ctx.userId,
          userRole: ctx.role,
          module: 'students',
          action: 'DELETE',
          entityId: id,
          before: existing,
          meta: ctx.meta,
        },
        tx
      );
    });
  },

  async restore(id: string, ctx: ControllerContext) {
    const existing = await studentRepository.findByIdIncludingDeleted(id);
    if (!existing) throw new NotFoundError('Student not found');
    if (!existing.deletedAt) throw new ConflictError('Student is not deleted');

    const restored = await withTransaction(async (tx) => {
      const result = await studentRepository.restore(id, tx);
      await auditLogService.record(
        {
          userId: ctx.userId,
          userRole: ctx.role,
          module: 'students',
          action: 'RESTORE',
          entityId: id,
          after: result,
          meta: ctx.meta,
        },
        tx
      );
      return result;
    });

    return restored;
  },
};
