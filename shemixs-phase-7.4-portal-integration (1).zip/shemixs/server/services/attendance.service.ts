import { withTransaction } from '../db/transaction';
import { attendanceRepository, type AttendanceHistoryFilters } from '../repositories/attendance.repository';
import { auditLogService } from './audit-log.service';
import { NotFoundError } from '../lib/errors';
import type {
  MarkStudentAttendanceInput,
  MarkBulkStudentAttendanceInput,
  MarkTeacherAttendanceInput,
  UpdateAttendanceInput,
} from '../validators/attendance.validators';
import type { ControllerContext } from '../controllers/base.controller';

export const attendanceService = {
  async markStudent(input: MarkStudentAttendanceInput, ctx: ControllerContext) {
    return withTransaction(async (tx) => {
      const result = await attendanceRepository.upsertStudentAttendance(
        input.studentId,
        input.date,
        input.status,
        input.remarks,
        ctx.userId,
        tx
      );
      await auditLogService.record(
        {
          userId: ctx.userId,
          userRole: ctx.role,
          module: 'attendance',
          action: 'CREATE',
          entityId: result.id,
          after: result,
          meta: ctx.meta,
        },
        tx
      );
      return result;
    });
  },

  async markBulkStudent(input: MarkBulkStudentAttendanceInput, ctx: ControllerContext) {
    return withTransaction(async (tx) => {
      const results = [];
      for (const entry of input.entries) {
        const result = await attendanceRepository.upsertStudentAttendance(
          entry.studentId,
          input.date,
          entry.status,
          entry.remarks,
          ctx.userId,
          tx
        );
        results.push(result);
      }
      await auditLogService.record(
        {
          userId: ctx.userId,
          userRole: ctx.role,
          module: 'attendance',
          action: 'CREATE',
          after: { date: input.date, count: results.length },
          meta: ctx.meta,
        },
        tx
      );
      return results;
    });
  },

  async updateStudent(id: string, input: UpdateAttendanceInput, ctx: ControllerContext) {
    const existing = await attendanceRepository.findStudentAttendanceById(id);
    if (!existing) throw new NotFoundError('Attendance record not found');

    return withTransaction(async (tx) => {
      const result = await attendanceRepository.updateStudentAttendance(id, input, tx);
      await auditLogService.record(
        { userId: ctx.userId, userRole: ctx.role, module: 'attendance', action: 'UPDATE', entityId: id, before: existing, after: result, meta: ctx.meta },
        tx
      );
      return result;
    });
  },

  async studentHistory(studentId: string, filters: AttendanceHistoryFilters) {
    return attendanceRepository.studentHistory(studentId, filters);
  },

  async studentReport(studentId: string) {
    const rows = await attendanceRepository.studentReport({ studentId });
    return rows.reduce<Record<string, number>>((acc, row) => {
      acc[row.status] = row._count._all;
      return acc;
    }, {});
  },

  async markTeacher(input: MarkTeacherAttendanceInput, ctx: ControllerContext) {
    return withTransaction(async (tx) => {
      const result = await attendanceRepository.upsertTeacherAttendance(
        input.teacherId,
        input.date,
        input.status,
        input.remarks,
        ctx.userId,
        tx
      );
      await auditLogService.record(
        { userId: ctx.userId, userRole: ctx.role, module: 'attendance', action: 'CREATE', entityId: result.id, after: result, meta: ctx.meta },
        tx
      );
      return result;
    });
  },

  async updateTeacher(id: string, input: UpdateAttendanceInput, ctx: ControllerContext) {
    const existing = await attendanceRepository.findTeacherAttendanceById(id);
    if (!existing) throw new NotFoundError('Attendance record not found');

    return withTransaction(async (tx) => {
      const result = await attendanceRepository.updateTeacherAttendance(id, input, tx);
      await auditLogService.record(
        { userId: ctx.userId, userRole: ctx.role, module: 'attendance', action: 'UPDATE', entityId: id, before: existing, after: result, meta: ctx.meta },
        tx
      );
      return result;
    });
  },

  async teacherHistory(teacherId: string, filters: AttendanceHistoryFilters) {
    return attendanceRepository.teacherHistory(teacherId, filters);
  },
};
