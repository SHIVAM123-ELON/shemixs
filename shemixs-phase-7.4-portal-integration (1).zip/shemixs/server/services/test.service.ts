import { withTransaction } from '../db/transaction';
import { testRepository, type TestListFilters } from '../repositories/test.repository';
import { auditLogService } from './audit-log.service';
import { buildPaginationMeta } from '../lib/query';
import { NotFoundError } from '../lib/errors';
import type { CreateTestInput, UpdateTestInput } from '../validators/test.validators';
import type { ControllerContext } from '../controllers/base.controller';

export const testService = {
  async list(filters: TestListFilters) {
    const { items, totalItems } = await testRepository.findMany(filters);
    return { items, pagination: buildPaginationMeta(filters, totalItems) };
  },

  async getById(id: string) {
    const test = await testRepository.findById(id);
    if (!test) throw new NotFoundError('Test not found');
    return test;
  },

  async create(input: CreateTestInput, ctx: ControllerContext) {
    return withTransaction(async (tx) => {
      const created = await testRepository.create(
        {
          title: input.title,
          description: input.description,
          subjectId: input.subjectId,
          batchId: input.batchId,
          teacherId: input.teacherId ?? ctx.userId,
          type: input.type,
          mode: input.mode,
          maxMarks: input.maxMarks,
          durationMinutes: input.durationMinutes,
          scheduledAt: input.scheduledAt,
          status: 'DRAFT',
        },
        tx
      );

      if (input.questions.length > 0) {
        await testRepository.createQuestions(
          created.id,
          input.questions.map((q, index) => ({
            testId: created.id,
            questionText: q.questionText,
            options: q.options,
            correctAnswer: q.correctAnswer,
            marks: q.marks,
            order: index,
          })),
          tx
        );
      }

      await auditLogService.record(
        { userId: ctx.userId, userRole: ctx.role, module: 'tests', action: 'CREATE', entityId: created.id, after: created, meta: ctx.meta },
        tx
      );

      return testRepository.findById(created.id, tx);
    });
  },

  async update(id: string, input: UpdateTestInput, ctx: ControllerContext) {
    const existing = await testRepository.findById(id);
    if (!existing) throw new NotFoundError('Test not found');

    return withTransaction(async (tx) => {
      const result = await testRepository.update(id, input, tx);
      await auditLogService.record(
        { userId: ctx.userId, userRole: ctx.role, module: 'tests', action: 'UPDATE', entityId: id, before: existing, after: result, meta: ctx.meta },
        tx
      );
      return result;
    });
  },

  async publish(id: string, ctx: ControllerContext) {
    const existing = await testRepository.findById(id);
    if (!existing) throw new NotFoundError('Test not found');

    return withTransaction(async (tx) => {
      const result = await testRepository.update(id, { status: 'PUBLISHED' }, tx);
      await auditLogService.record(
        { userId: ctx.userId, userRole: ctx.role, module: 'tests', action: 'PUBLISH', entityId: id, before: { status: existing.status }, after: { status: 'PUBLISHED' }, meta: ctx.meta },
        tx
      );
      return result;
    });
  },

  async unpublish(id: string, ctx: ControllerContext) {
    const existing = await testRepository.findById(id);
    if (!existing) throw new NotFoundError('Test not found');

    return withTransaction(async (tx) => {
      const result = await testRepository.update(id, { status: 'DRAFT' }, tx);
      await auditLogService.record(
        { userId: ctx.userId, userRole: ctx.role, module: 'tests', action: 'UPDATE', entityId: id, before: { status: existing.status }, after: { status: 'DRAFT' }, meta: ctx.meta },
        tx
      );
      return result;
    });
  },

  async softDelete(id: string, ctx: ControllerContext) {
    const existing = await testRepository.findById(id);
    if (!existing) throw new NotFoundError('Test not found');

    await withTransaction(async (tx) => {
      await testRepository.softDelete(id, tx);
      await auditLogService.record(
        { userId: ctx.userId, userRole: ctx.role, module: 'tests', action: 'DELETE', entityId: id, before: existing, meta: ctx.meta },
        tx
      );
    });
  },
};
