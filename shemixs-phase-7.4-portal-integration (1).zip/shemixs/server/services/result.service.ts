/**
 * Result Service
 *
 * Rank is computed, not entered — `recomputeRanks` runs after every
 * marks entry (single or bulk) and orders by `marksObtained` descending,
 * assigning 1, 2, 3, ... Students with null marks (not yet graded) are
 * excluded from ranking so they don't distort the ordering.
 */
import { withTransaction } from '../db/transaction';
import { resultRepository, type ResultListFilters } from '../repositories/result.repository';
import { auditLogService } from './audit-log.service';
import { notificationService } from './notification.service';
import { NotFoundError } from '../lib/errors';
import type { CreateResultInput, UpdateResultInput, BulkCreateResultsInput } from '../validators/result.validators';
import type { ControllerContext } from '../controllers/base.controller';
import type { TransactionClient } from '../db/transaction';

async function recomputeRanks(testId: string, tx: TransactionClient) {
  const results = await resultRepository.findAllForTest(testId, tx);
  const graded = results.filter((r) => r.marksObtained !== null);
  // Already sorted desc by marksObtained via findAllForTest's orderBy.
  await Promise.all(graded.map((r, index) => resultRepository.setRank(r.id, index + 1, tx)));
}

export const resultService = {
  async list(filters: ResultListFilters) {
    return resultRepository.findMany(filters);
  },

  async getById(id: string) {
    const result = await resultRepository.findById(id);
    if (!result) throw new NotFoundError('Result not found');
    return result;
  },

  async create(input: CreateResultInput, ctx: ControllerContext) {
    return withTransaction(async (tx) => {
      const created = await resultRepository.upsert(input.testId, input.studentId, input.marksObtained, input.grade, tx);
      await recomputeRanks(input.testId, tx);
      await auditLogService.record(
        { userId: ctx.userId, userRole: ctx.role, module: 'results', action: 'CREATE', entityId: created.id, after: created, meta: ctx.meta },
        tx
      );
      return resultRepository.findById(created.id, tx);
    });
  },

  async bulkCreate(input: BulkCreateResultsInput, ctx: ControllerContext) {
    return withTransaction(async (tx) => {
      for (const entry of input.entries) {
        await resultRepository.upsert(input.testId, entry.studentId, entry.marksObtained, entry.grade, tx);
      }
      await recomputeRanks(input.testId, tx);
      await auditLogService.record(
        {
          userId: ctx.userId,
          userRole: ctx.role,
          module: 'results',
          action: 'CREATE',
          entityId: input.testId,
          after: { testId: input.testId, count: input.entries.length },
          meta: ctx.meta,
        },
        tx
      );
      return resultRepository.findMany({ testId: input.testId }, tx);
    });
  },

  async update(id: string, input: UpdateResultInput, ctx: ControllerContext) {
    const existing = await resultRepository.findById(id);
    if (!existing) throw new NotFoundError('Result not found');

    return withTransaction(async (tx) => {
      const result = await resultRepository.update(id, input, tx);
      await recomputeRanks(existing.testId, tx);
      await auditLogService.record(
        { userId: ctx.userId, userRole: ctx.role, module: 'results', action: 'UPDATE', entityId: id, before: existing, after: result, meta: ctx.meta },
        tx
      );
      return resultRepository.findById(id, tx);
    });
  },

  async publishForTest(testId: string, ctx: ControllerContext) {
    const results = await withTransaction(async (tx) => {
      await resultRepository.publishAllForTest(testId, tx);
      await auditLogService.record(
        { userId: ctx.userId, userRole: ctx.role, module: 'results', action: 'PUBLISH', entityId: testId, meta: ctx.meta },
        tx
      );
      return resultRepository.findMany({ testId }, tx);
    });

    // Notify outside the transaction — one student's notification
    // failure should never roll back the (already-committed) publish
    // for everyone else. Best-effort, in-app only by default (email
    // is available via notificationService.notify's `channels` option
    // if a school wants both).
    await Promise.all(
      results.map((result) =>
        notificationService.notify({
          userId: result.student.userId,
          title: 'Results published',
          body: `Your results for "${result.test.title}" have been published.`,
          data: { type: 'result', resultId: result.id, testId },
          channels: ['IN_APP'],
        })
      )
    );

    return results;
  },

  async studentHistory(studentId: string) {
    return resultRepository.studentHistory(studentId);
  },
};
