/**
 * Auth Service
 *
 * Owns all authentication business logic. Route handlers stay thin —
 * they parse/validate the request, call one method here, and shape
 * the HTTP response. Nothing in this file knows about NextResponse
 * or cookies; that keeps the service testable and reusable (e.g. from
 * a future mobile API) independent of the cookie-based web flow.
 */
import { randomUUID } from 'crypto';
import { prisma } from '../db/client';
import { userRepository } from '../repositories/user.repository';
import { sessionRepository } from '../repositories/session.repository';
import { hashPassword, verifyPassword, generateVerificationToken, hashVerificationToken } from '../auth/password';
import { signAccessToken, signRefreshToken, verifyRefreshToken } from '../auth/jwt';
import { getEnv } from '../lib/env';
import { parseDurationToMs, parseDurationToSeconds } from '../lib/duration';
import { logger } from '../lib/logger';
import { emailService } from '../email/email.service';
import { emailTemplates } from '../email/templates';
import {
  UnauthorizedError,
  ForbiddenError,
  ConflictError,
  NotFoundError,
} from '../lib/errors';
import type { AuthenticatedUser, RequestMeta, TokenPair } from '../types/auth.types';
import type { User, Role } from '@prisma/client';

type UserWithRole = User & { role: Role };

function toAuthenticatedUser(user: UserWithRole): AuthenticatedUser {
  return {
    id: user.id,
    fullName: user.fullName,
    email: user.email,
    avatar: user.avatar,
    status: user.status,
    role: user.role.name,
    emailVerified: user.emailVerified,
  };
}

async function issueTokenPair(user: UserWithRole, meta: RequestMeta): Promise<TokenPair> {
  const env = getEnv();

  const accessToken = await signAccessToken({
    sub: user.id,
    role: user.role.name,
    email: user.email,
  });

  // Generate the session id up front (rather than letting Prisma's
  // @default(uuid()) assign one on create) so the refresh JWT can
  // embed it, and the session row can be created with its real,
  // final refresh token in a single write. Avoids a transient
  // placeholder value that would collide with Session.refreshToken's
  // @unique constraint under concurrent logins.
  const sessionId = randomUUID();
  const refreshTokenExpiresAt = new Date(Date.now() + parseDurationToMs(env.JWT_REFRESH_EXPIRES_IN));
  const refreshToken = await signRefreshToken({ sub: user.id, sessionId });

  await prisma.session.create({
    data: {
      id: sessionId,
      userId: user.id,
      refreshToken,
      device: meta.device,
      browser: meta.browser,
      ipAddress: meta.ipAddress,
      expiresAt: refreshTokenExpiresAt,
    },
  });

  return {
    accessToken,
    refreshToken,
    accessTokenExpiresInSeconds: parseDurationToSeconds(env.JWT_ACCESS_EXPIRES_IN),
    refreshTokenExpiresInSeconds: parseDurationToSeconds(env.JWT_REFRESH_EXPIRES_IN),
  };
}

export const authService = {
  async login(email: string, password: string, meta: RequestMeta) {
    const user = (await userRepository.findByEmail(email)) as UserWithRole | null;

    if (!user) {
      throw new UnauthorizedError('Invalid email or password');
    }

    if (user.status === 'SUSPENDED') {
      throw new ForbiddenError('This account has been suspended. Contact your administrator.');
    }

    if (user.status === 'INACTIVE') {
      throw new ForbiddenError('This account is inactive. Contact your administrator.');
    }

    const passwordValid = await verifyPassword(password, user.passwordHash);
    if (!passwordValid) {
      throw new UnauthorizedError('Invalid email or password');
    }

    const tokens = await issueTokenPair(user, meta);
    logger.info('User logged in', { userId: user.id });

    return { user: toAuthenticatedUser(user), tokens };
  },

  async logout(refreshToken: string | undefined) {
    if (!refreshToken) return;
    await sessionRepository.revokeByRefreshToken(refreshToken);
  },

  async refresh(refreshToken: string | undefined, meta: RequestMeta) {
    if (!refreshToken) {
      throw new UnauthorizedError('No refresh token provided');
    }

    let payload;
    try {
      payload = await verifyRefreshToken(refreshToken);
    } catch {
      throw new UnauthorizedError('Invalid or expired refresh token');
    }

    const session = await sessionRepository.findByRefreshToken(refreshToken);
    if (!session || session.revoked || session.expiresAt < new Date()) {
      throw new UnauthorizedError('Session is no longer valid, please log in again');
    }

    const user = (await userRepository.findById(payload.sub)) as UserWithRole | null;
    if (!user || user.status !== 'ACTIVE') {
      throw new UnauthorizedError('Account is no longer active');
    }

    // Refresh token rotation: revoke the old session/token, issue a new pair.
    await sessionRepository.revoke(session.id);
    const tokens = await issueTokenPair(user, meta);

    return { user: toAuthenticatedUser(user), tokens };
  },

  async getCurrentUser(userId: string) {
    const user = (await userRepository.findById(userId)) as UserWithRole | null;
    if (!user) throw new NotFoundError('User not found');
    return toAuthenticatedUser(user);
  },

  async forgotPassword(email: string) {
    const user = await userRepository.findByEmail(email);

    // Intentionally do not reveal whether the email exists — always
    // behave the same way so this endpoint can't be used to enumerate
    // registered accounts.
    if (!user) {
      logger.info('Password reset requested for unknown email', { email });
      return;
    }

    const { raw, hash } = generateVerificationToken();
    const expiresAt = new Date(Date.now() + 60 * 60 * 1000); // 1 hour

    await prisma.passwordResetToken.create({
      data: { userId: user.id, tokenHash: hash, expiresAt },
    });

    // Phase 7.1 logged this token instead of emailing it, since email
    // delivery didn't exist yet. Phase 7.3B implements the email
    // module — wire it in here.
    const env = getEnv();
    const resetUrl = `${env.APP_URL}/reset-password?token=${raw}`;
    const { subject, html } = emailTemplates.passwordReset(resetUrl);
    const result = await emailService.send({ to: user.email, subject, html });

    if (!result.success) {
      // Never let email delivery failure surface to the caller (would
      // leak account existence via a different error path) — log it
      // server-side and let the generic "if an account exists" response
      // still return normally.
      logger.error('Password reset email failed to send', { userId: user.id, error: result.error });
    }

    return { token: raw };
  },

  async resetPassword(rawToken: string, newPassword: string) {
    const tokenHash = hashVerificationToken(rawToken);

    const resetToken = await prisma.passwordResetToken.findUnique({ where: { tokenHash } });

    if (!resetToken || resetToken.usedAt || resetToken.expiresAt < new Date()) {
      throw new UnauthorizedError('This reset link is invalid or has expired');
    }

    const passwordHash = await hashPassword(newPassword);

    await prisma.$transaction([
      prisma.user.update({ where: { id: resetToken.userId }, data: { passwordHash } }),
      prisma.passwordResetToken.update({ where: { id: resetToken.id }, data: { usedAt: new Date() } }),
      prisma.session.updateMany({
        where: { userId: resetToken.userId, revoked: false },
        data: { revoked: true, revokedAt: new Date() },
      }),
    ]);

    logger.info('Password reset completed', { userId: resetToken.userId });
  },

  async changePassword(userId: string, currentPassword: string, newPassword: string) {
    const user = await userRepository.findById(userId);
    if (!user) throw new NotFoundError('User not found');

    const valid = await verifyPassword(currentPassword, user.passwordHash);
    if (!valid) throw new UnauthorizedError('Current password is incorrect');

    const passwordHash = await hashPassword(newPassword);
    await userRepository.updatePassword(userId, passwordHash);
    await sessionRepository.revokeAllForUser(userId);

    logger.info('Password changed', { userId });
  },

  async verifyEmail(rawToken: string) {
    const tokenHash = hashVerificationToken(rawToken);

    const verificationToken = await prisma.emailVerificationToken.findUnique({ where: { tokenHash } });

    if (!verificationToken || verificationToken.usedAt || verificationToken.expiresAt < new Date()) {
      throw new UnauthorizedError('This verification link is invalid or has expired');
    }

    await prisma.$transaction([
      prisma.user.update({
        where: { id: verificationToken.userId },
        data: { emailVerified: true, status: 'ACTIVE' },
      }),
      prisma.emailVerificationToken.update({
        where: { id: verificationToken.id },
        data: { usedAt: new Date() },
      }),
    ]);

    logger.info('Email verified', { userId: verificationToken.userId });
  },
};
