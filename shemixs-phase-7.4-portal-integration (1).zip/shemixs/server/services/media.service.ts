import { mediaRepository, type MediaListFilters } from '../repositories/media.repository';
import { NotFoundError } from '../lib/errors';

export const mediaService = {
  async list(filters: MediaListFilters) {
    const { items, totalItems } = await mediaRepository.findMany(filters);
    const totalPages = Math.max(1, Math.ceil(totalItems / filters.pageSize));
    return {
      items,
      pagination: {
        page: filters.page,
        pageSize: filters.pageSize,
        totalItems,
        totalPages,
        hasNextPage: filters.page < totalPages,
        hasPreviousPage: filters.page > 1,
      },
    };
  },

  async getById(id: string) {
    const media = await mediaRepository.findById(id);
    if (!media) throw new NotFoundError('Media not found');
    return media;
  },
};
