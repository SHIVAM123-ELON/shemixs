import { withTransaction } from '../db/transaction';
import { parentRepository } from '../repositories/parent.repository';
import { studentRepository } from '../repositories/student.repository';
import { roleRepository } from '../repositories/role.repository';
import { auditLogService } from './audit-log.service';
import { hashPassword } from '../auth/password';
import { buildPaginationMeta, type ListQuery } from '../lib/query';
import { ConflictError, NotFoundError, ValidationError } from '../lib/errors';
import type { CreateParentInput, UpdateParentInput, LinkStudentInput, UnlinkStudentInput } from '../validators/parent.validators';
import type { ControllerContext } from '../controllers/base.controller';
import { randomBytes } from 'crypto';

export const parentService = {
  async list(filters: ListQuery) {
    const { items, totalItems } = await parentRepository.findMany(filters);
    return { items, pagination: buildPaginationMeta(filters, totalItems) };
  },

  async getById(id: string) {
    const parent = await parentRepository.findById(id);
    if (!parent) throw new NotFoundError('Parent not found');
    return parent;
  },

  async create(input: CreateParentInput, ctx: ControllerContext) {
    const parentRole = await roleRepository.findByName('PARENT');
    if (!parentRole) throw new ValidationError('PARENT role is not seeded — run the database seed first');

    return withTransaction(async (tx) => {
      const tempPassword = randomBytes(16).toString('hex');
      const passwordHash = await hashPassword(tempPassword);

      const user = await tx.user.create({
        data: {
          fullName: input.fullName,
          email: input.email.toLowerCase(),
          phone: input.phone,
          passwordHash,
          roleId: parentRole.id,
          status: 'PENDING',
        },
      });

      const created = await parentRepository.create(
        { userId: user.id, occupation: input.occupation, address: input.address },
        tx
      );

      await auditLogService.record(
        { userId: ctx.userId, userRole: ctx.role, module: 'parents', action: 'CREATE', entityId: created.id, after: created, meta: ctx.meta },
        tx
      );

      return created;
    });
  },

  async update(id: string, input: UpdateParentInput, ctx: ControllerContext) {
    const existing = await parentRepository.findById(id);
    if (!existing) throw new NotFoundError('Parent not found');

    return withTransaction(async (tx) => {
      const result = await parentRepository.update(id, input, tx);
      await auditLogService.record(
        { userId: ctx.userId, userRole: ctx.role, module: 'parents', action: 'UPDATE', entityId: id, before: existing, after: result, meta: ctx.meta },
        tx
      );
      return result;
    });
  },

  async linkStudent(id: string, input: LinkStudentInput, ctx: ControllerContext) {
    const parent = await parentRepository.findById(id);
    if (!parent) throw new NotFoundError('Parent not found');

    const student = await studentRepository.findById(input.studentId);
    if (!student) throw new NotFoundError('Student not found');

    const existingLink = await parentRepository.findLink(id, input.studentId);
    if (existingLink) throw new ConflictError('This parent is already linked to this student');

    return withTransaction(async (tx) => {
      await parentRepository.linkStudent(id, input.studentId, input.relationship, tx);
      await auditLogService.record(
        {
          userId: ctx.userId,
          userRole: ctx.role,
          module: 'parents',
          action: 'ASSIGN',
          entityId: id,
          after: { studentId: input.studentId, relationship: input.relationship },
          meta: ctx.meta,
        },
        tx
      );
      return parentRepository.findById(id, tx);
    });
  },

  async unlinkStudent(id: string, input: UnlinkStudentInput, ctx: ControllerContext) {
    const parent = await parentRepository.findById(id);
    if (!parent) throw new NotFoundError('Parent not found');

    const existingLink = await parentRepository.findLink(id, input.studentId);
    if (!existingLink) throw new NotFoundError('This parent is not linked to this student');

    return withTransaction(async (tx) => {
      await parentRepository.unlinkStudent(id, input.studentId, tx);
      await auditLogService.record(
        {
          userId: ctx.userId,
          userRole: ctx.role,
          module: 'parents',
          action: 'UPDATE',
          entityId: id,
          before: { studentId: input.studentId },
          meta: ctx.meta,
        },
        tx
      );
      return parentRepository.findById(id, tx);
    });
  },

  async softDelete(id: string, ctx: ControllerContext) {
    const existing = await parentRepository.findById(id);
    if (!existing) throw new NotFoundError('Parent not found');

    await withTransaction(async (tx) => {
      await parentRepository.softDelete(id, tx);
      await auditLogService.record(
        { userId: ctx.userId, userRole: ctx.role, module: 'parents', action: 'DELETE', entityId: id, before: existing, meta: ctx.meta },
        tx
      );
    });
  },
};
