import { withTransaction } from '../db/transaction';
import { batchRepository, type BatchListFilters } from '../repositories/batch.repository';
import { auditLogService } from './audit-log.service';
import { buildPaginationMeta } from '../lib/query';
import { NotFoundError, ValidationError } from '../lib/errors';
import type { CreateBatchInput, UpdateBatchInput, UpdateBatchStatusInput } from '../validators/batch.validators';
import type { ControllerContext } from '../controllers/base.controller';

export const batchService = {
  async list(filters: BatchListFilters) {
    const { items, totalItems } = await batchRepository.findMany(filters);
    return { items, pagination: buildPaginationMeta(filters, totalItems) };
  },

  async getById(id: string) {
    const batch = await batchRepository.findById(id);
    if (!batch) throw new NotFoundError('Batch not found');
    return batch;
  },

  async create(input: CreateBatchInput, ctx: ControllerContext) {
    return withTransaction(async (tx) => {
      const created = await batchRepository.create({ name: input.name, capacity: input.capacity, status: 'UPCOMING' }, tx);
      await auditLogService.record(
        { userId: ctx.userId, userRole: ctx.role, module: 'batches', action: 'CREATE', entityId: created.id, after: created, meta: ctx.meta },
        tx
      );
      return created;
    });
  },

  async update(id: string, input: UpdateBatchInput, ctx: ControllerContext) {
    const existing = await batchRepository.findById(id);
    if (!existing) throw new NotFoundError('Batch not found');

    return withTransaction(async (tx) => {
      const result = await batchRepository.update(id, input, tx);
      await auditLogService.record(
        { userId: ctx.userId, userRole: ctx.role, module: 'batches', action: 'UPDATE', entityId: id, before: existing, after: result, meta: ctx.meta },
        tx
      );
      return result;
    });
  },

  async updateStatus(id: string, input: UpdateBatchStatusInput, ctx: ControllerContext) {
    const existing = await batchRepository.findById(id);
    if (!existing) throw new NotFoundError('Batch not found');

    return withTransaction(async (tx) => {
      const result = await batchRepository.update(id, { status: input.status }, tx);
      await auditLogService.record(
        { userId: ctx.userId, userRole: ctx.role, module: 'batches', action: 'UPDATE', entityId: id, before: { status: existing.status }, after: { status: input.status }, meta: ctx.meta },
        tx
      );
      return result;
    });
  },

  async assignStudents(id: string, studentIds: string[], ctx: ControllerContext) {
    const batch = await batchRepository.findById(id);
    if (!batch) throw new NotFoundError('Batch not found');

    if (batch.capacity) {
      const currentCount = await batchRepository.studentCount(id);
      if (currentCount + studentIds.length > batch.capacity) {
        throw new ValidationError(
          `Assigning ${studentIds.length} student(s) would exceed batch capacity (${batch.capacity}); currently at ${currentCount}`
        );
      }
    }

    return withTransaction(async (tx) => {
      const result = await batchRepository.assignStudents(id, studentIds, tx);
      await auditLogService.record(
        { userId: ctx.userId, userRole: ctx.role, module: 'batches', action: 'ASSIGN', entityId: id, after: { studentIds }, meta: ctx.meta },
        tx
      );
      return result;
    });
  },

  async assignTeachers(id: string, teacherIds: string[], ctx: ControllerContext) {
    const existing = await batchRepository.findById(id);
    if (!existing) throw new NotFoundError('Batch not found');

    return withTransaction(async (tx) => {
      const result = await batchRepository.replaceTeachers(id, teacherIds, tx);
      await auditLogService.record(
        {
          userId: ctx.userId,
          userRole: ctx.role,
          module: 'batches',
          action: 'ASSIGN',
          entityId: id,
          before: { teacherIds: existing.teachers.map((t) => t.teacherId) },
          after: { teacherIds },
          meta: ctx.meta,
        },
        tx
      );
      return result;
    });
  },

  async softDelete(id: string, ctx: ControllerContext) {
    const existing = await batchRepository.findById(id);
    if (!existing) throw new NotFoundError('Batch not found');

    await withTransaction(async (tx) => {
      await batchRepository.softDelete(id, tx);
      await auditLogService.record(
        { userId: ctx.userId, userRole: ctx.role, module: 'batches', action: 'DELETE', entityId: id, before: existing, meta: ctx.meta },
        tx
      );
    });
  },
};
