/**
 * Audit Log Service
 *
 * Every module service calls `auditLogService.record(...)` after a
 * mutating operation succeeds (inside the same transaction where
 * possible, so the audit entry and the data change are atomic — if
 * one fails, both roll back). Kept as a single generic service
 * (rather than one per module) since the `AuditLog` table is
 * intentionally module-agnostic (see schema comment).
 */
import { auditLogRepository } from '../repositories/audit-log.repository';
import type { TransactionClient } from '../db/transaction';
import type { AuditAction } from '@prisma/client';
import type { RequestMeta } from '../types/auth.types';

interface RecordAuditInput {
  userId?: string;
  userRole?: string;
  module: string;
  action: AuditAction;
  entityId?: string;
  before?: unknown;
  after?: unknown;
  meta?: RequestMeta;
}

export const auditLogService = {
  async record(input: RecordAuditInput, tx?: TransactionClient) {
    await auditLogRepository.create(
      {
        userId: input.userId,
        userRole: input.userRole,
        module: input.module,
        action: input.action,
        entityId: input.entityId,
        before: input.before,
        after: input.after,
        ipAddress: input.meta?.ipAddress,
        userAgent: input.meta?.browser,
      },
      tx
    );
  },

  async history(module: string, entityId: string) {
    return auditLogRepository.listForEntity(module, entityId);
  },
};
