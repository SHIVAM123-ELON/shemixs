import { withTransaction } from '../db/transaction';
import { courseRepository, type CourseListFilters } from '../repositories/course.repository';
import { auditLogService } from './audit-log.service';
import { buildPaginationMeta } from '../lib/query';
import { ConflictError, NotFoundError } from '../lib/errors';
import { slugify } from '../validators/course.validators';
import type { CreateCourseInput, UpdateCourseInput, UpdateCourseStatusInput } from '../validators/course.validators';
import type { ControllerContext } from '../controllers/base.controller';

async function uniqueSlug(base: string): Promise<string> {
  let slug = slugify(base);
  let suffix = 1;
  // Small bounded loop — course titles rarely collide more than once or twice.
  while (await courseRepository.findBySlug(slug)) {
    slug = `${slugify(base)}-${suffix++}`;
  }
  return slug;
}

export const courseService = {
  async list(filters: CourseListFilters) {
    const { items, totalItems } = await courseRepository.findMany(filters);
    return { items, pagination: buildPaginationMeta(filters, totalItems) };
  },

  async getById(id: string) {
    const course = await courseRepository.findById(id);
    if (!course) throw new NotFoundError('Course not found');
    return course;
  },

  async create(input: CreateCourseInput, ctx: ControllerContext) {
    const slug = input.slug ? slugify(input.slug) : await uniqueSlug(input.title);
    if (input.slug) {
      const existing = await courseRepository.findBySlug(slug);
      if (existing) throw new ConflictError('A course with this slug already exists');
    }

    return withTransaction(async (tx) => {
      const created = await courseRepository.create(
        { title: input.title, slug, description: input.description, category: input.category, status: 'DRAFT' },
        tx
      );
      await auditLogService.record(
        { userId: ctx.userId, userRole: ctx.role, module: 'courses', action: 'CREATE', entityId: created.id, after: created, meta: ctx.meta },
        tx
      );
      return created;
    });
  },

  async update(id: string, input: UpdateCourseInput, ctx: ControllerContext) {
    const existing = await courseRepository.findById(id);
    if (!existing) throw new NotFoundError('Course not found');

    return withTransaction(async (tx) => {
      const result = await courseRepository.update(id, input, tx);
      await auditLogService.record(
        { userId: ctx.userId, userRole: ctx.role, module: 'courses', action: 'UPDATE', entityId: id, before: existing, after: result, meta: ctx.meta },
        tx
      );
      return result;
    });
  },

  async updateStatus(id: string, input: UpdateCourseStatusInput, ctx: ControllerContext) {
    const existing = await courseRepository.findById(id);
    if (!existing) throw new NotFoundError('Course not found');

    return withTransaction(async (tx) => {
      const result = await courseRepository.update(id, { status: input.status }, tx);
      await auditLogService.record(
        {
          userId: ctx.userId,
          userRole: ctx.role,
          module: 'courses',
          action: input.status === 'PUBLISHED' ? 'PUBLISH' : 'UPDATE',
          entityId: id,
          before: { status: existing.status },
          after: { status: input.status },
          meta: ctx.meta,
        },
        tx
      );
      return result;
    });
  },

  async assignInstructors(id: string, teacherIds: string[], ctx: ControllerContext) {
    const existing = await courseRepository.findById(id);
    if (!existing) throw new NotFoundError('Course not found');

    return withTransaction(async (tx) => {
      const result = await courseRepository.replaceInstructors(id, teacherIds, tx);
      await auditLogService.record(
        {
          userId: ctx.userId,
          userRole: ctx.role,
          module: 'courses',
          action: 'ASSIGN',
          entityId: id,
          before: { instructorIds: existing.instructors.map((i) => i.teacherId) },
          after: { instructorIds: teacherIds },
          meta: ctx.meta,
        },
        tx
      );
      return result;
    });
  },

  async softDelete(id: string, ctx: ControllerContext) {
    const existing = await courseRepository.findById(id);
    if (!existing) throw new NotFoundError('Course not found');

    await withTransaction(async (tx) => {
      await courseRepository.softDelete(id, tx);
      await auditLogService.record(
        { userId: ctx.userId, userRole: ctx.role, module: 'courses', action: 'DELETE', entityId: id, before: existing, meta: ctx.meta },
        tx
      );
    });
  },
};
