import { withTransaction } from '../db/transaction';
import { timetableRepository, type TimetableFilters } from '../repositories/timetable.repository';
import { auditLogService } from './audit-log.service';
import { ConflictError, NotFoundError } from '../lib/errors';
import type { CreateTimetableEntryInput, UpdateTimetableEntryInput } from '../validators/timetable.validators';
import type { ControllerContext } from '../controllers/base.controller';

export const timetableService = {
  /** Generic list — also serves as "Weekly Timetable" when no day filter is passed. */
  async list(filters: TimetableFilters) {
    return timetableRepository.findMany(filters);
  },

  /** "Teacher Schedule" is just the generic list filtered to one teacher. */
  async teacherSchedule(teacherId: string) {
    return timetableRepository.findMany({ teacherId });
  },

  /** "Student Schedule" resolves through the student's section. */
  async studentSchedule(sectionId: string) {
    return timetableRepository.findMany({ sectionId });
  },

  /** "Class Timetable" — batch-level view. */
  async classTimetable(batchId: string) {
    return timetableRepository.findMany({ batchId });
  },

  async getById(id: string) {
    const entry = await timetableRepository.findById(id);
    if (!entry) throw new NotFoundError('Timetable entry not found');
    return entry;
  },

  async create(input: CreateTimetableEntryInput, ctx: ControllerContext) {
    const conflicts = await timetableRepository.findConflicts(input);
    if (conflicts.length > 0) {
      throw new ConflictError('This time slot conflicts with an existing timetable entry for the same teacher or section');
    }

    return withTransaction(async (tx) => {
      const created = await timetableRepository.create(input, tx);
      await auditLogService.record(
        { userId: ctx.userId, userRole: ctx.role, module: 'timetable', action: 'CREATE', entityId: created.id, after: created, meta: ctx.meta },
        tx
      );
      return created;
    });
  },

  async update(id: string, input: UpdateTimetableEntryInput, ctx: ControllerContext) {
    const existing = await timetableRepository.findById(id);
    if (!existing) throw new NotFoundError('Timetable entry not found');

    const merged = {
      teacherId: input.teacherId === undefined ? existing.teacherId ?? undefined : input.teacherId ?? undefined,
      sectionId: input.sectionId === undefined ? existing.sectionId ?? undefined : input.sectionId ?? undefined,
      dayOfWeek: input.dayOfWeek ?? existing.dayOfWeek,
      startTime: input.startTime ?? existing.startTime,
      endTime: input.endTime ?? existing.endTime,
    };

    const conflicts = await timetableRepository.findConflicts(merged, id);
    if (conflicts.length > 0) {
      throw new ConflictError('This time slot conflicts with an existing timetable entry for the same teacher or section');
    }

    return withTransaction(async (tx) => {
      const result = await timetableRepository.update(id, input, tx);
      await auditLogService.record(
        { userId: ctx.userId, userRole: ctx.role, module: 'timetable', action: 'UPDATE', entityId: id, before: existing, after: result, meta: ctx.meta },
        tx
      );
      return result;
    });
  },

  async softDelete(id: string, ctx: ControllerContext) {
    const existing = await timetableRepository.findById(id);
    if (!existing) throw new NotFoundError('Timetable entry not found');

    await withTransaction(async (tx) => {
      await timetableRepository.softDelete(id, tx);
      await auditLogService.record(
        { userId: ctx.userId, userRole: ctx.role, module: 'timetable', action: 'DELETE', entityId: id, before: existing, meta: ctx.meta },
        tx
      );
    });
  },
};
