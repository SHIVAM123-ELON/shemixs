import { withTransaction } from '../db/transaction';
import { homeworkRepository, type HomeworkListFilters } from '../repositories/homework.repository';
import { auditLogService } from './audit-log.service';
import { buildPaginationMeta } from '../lib/query';
import { NotFoundError } from '../lib/errors';
import type { CreateHomeworkInput, UpdateHomeworkInput } from '../validators/homework.validators';
import type { ControllerContext } from '../controllers/base.controller';

export const homeworkService = {
  async list(filters: HomeworkListFilters) {
    const { items, totalItems } = await homeworkRepository.findMany(filters);
    return { items, pagination: buildPaginationMeta(filters, totalItems) };
  },

  async getById(id: string) {
    const homework = await homeworkRepository.findById(id);
    if (!homework) throw new NotFoundError('Homework not found');
    return homework;
  },

  async create(input: CreateHomeworkInput, ctx: ControllerContext) {
    return withTransaction(async (tx) => {
      const created = await homeworkRepository.create(
        {
          title: input.title,
          description: input.description,
          subjectId: input.subjectId,
          batchId: input.batchId,
          sectionId: input.sectionId,
          teacherId: input.teacherId ?? ctx.userId, // defaults to the creating teacher if not specified
          dueDate: input.dueDate,
          attachmentUrls: input.attachmentUrls,
          status: 'DRAFT',
        },
        tx
      );
      await auditLogService.record(
        { userId: ctx.userId, userRole: ctx.role, module: 'homework', action: 'CREATE', entityId: created.id, after: created, meta: ctx.meta },
        tx
      );
      return created;
    });
  },

  async update(id: string, input: UpdateHomeworkInput, ctx: ControllerContext) {
    const existing = await homeworkRepository.findById(id);
    if (!existing) throw new NotFoundError('Homework not found');

    return withTransaction(async (tx) => {
      const result = await homeworkRepository.update(id, input, tx);
      await auditLogService.record(
        { userId: ctx.userId, userRole: ctx.role, module: 'homework', action: 'UPDATE', entityId: id, before: existing, after: result, meta: ctx.meta },
        tx
      );
      return result;
    });
  },

  async publish(id: string, ctx: ControllerContext) {
    const existing = await homeworkRepository.findById(id);
    if (!existing) throw new NotFoundError('Homework not found');

    return withTransaction(async (tx) => {
      const result = await homeworkRepository.update(id, { status: 'PUBLISHED' }, tx);
      await auditLogService.record(
        { userId: ctx.userId, userRole: ctx.role, module: 'homework', action: 'PUBLISH', entityId: id, before: { status: existing.status }, after: { status: 'PUBLISHED' }, meta: ctx.meta },
        tx
      );
      return result;
    });
  },

  async unpublish(id: string, ctx: ControllerContext) {
    const existing = await homeworkRepository.findById(id);
    if (!existing) throw new NotFoundError('Homework not found');

    return withTransaction(async (tx) => {
      const result = await homeworkRepository.update(id, { status: 'DRAFT' }, tx);
      await auditLogService.record(
        { userId: ctx.userId, userRole: ctx.role, module: 'homework', action: 'UPDATE', entityId: id, before: { status: existing.status }, after: { status: 'DRAFT' }, meta: ctx.meta },
        tx
      );
      return result;
    });
  },

  async softDelete(id: string, ctx: ControllerContext) {
    const existing = await homeworkRepository.findById(id);
    if (!existing) throw new NotFoundError('Homework not found');

    await withTransaction(async (tx) => {
      await homeworkRepository.softDelete(id, tx);
      await auditLogService.record(
        { userId: ctx.userId, userRole: ctx.role, module: 'homework', action: 'DELETE', entityId: id, before: existing, meta: ctx.meta },
        tx
      );
    });
  },
};
