import { withTransaction } from '../db/transaction';
import { teacherRepository, type TeacherListFilters } from '../repositories/teacher.repository';
import { roleRepository } from '../repositories/role.repository';
import { auditLogService } from './audit-log.service';
import { hashPassword } from '../auth/password';
import { buildPaginationMeta } from '../lib/query';
import { ConflictError, NotFoundError, ValidationError } from '../lib/errors';
import type {
  CreateTeacherInput,
  UpdateTeacherInput,
  UpdateTeacherStatusInput,
  AssignTeacherSubjectsInput,
} from '../validators/teacher.validators';
import type { ControllerContext } from '../controllers/base.controller';
import { randomBytes } from 'crypto';

export const teacherService = {
  async list(filters: TeacherListFilters) {
    const { items, totalItems } = await teacherRepository.findMany(filters);
    return { items, pagination: buildPaginationMeta(filters, totalItems) };
  },

  async getById(id: string) {
    const teacher = await teacherRepository.findById(id);
    if (!teacher) throw new NotFoundError('Teacher not found');
    return teacher;
  },

  async create(input: CreateTeacherInput, ctx: ControllerContext) {
    if (input.employeeCode) {
      const existing = await teacherRepository.findByEmployeeCode(input.employeeCode);
      if (existing) throw new ConflictError('A teacher with this employee code already exists');
    }

    const teacherRole = await roleRepository.findByName('TEACHER');
    if (!teacherRole) throw new ValidationError('TEACHER role is not seeded — run the database seed first');

    return withTransaction(async (tx) => {
      const tempPassword = randomBytes(16).toString('hex');
      const passwordHash = await hashPassword(tempPassword);

      const user = await tx.user.create({
        data: {
          fullName: input.fullName,
          email: input.email.toLowerCase(),
          phone: input.phone,
          passwordHash,
          roleId: teacherRole.id,
          status: 'PENDING',
        },
      });

      const created = await teacherRepository.create(
        {
          userId: user.id,
          employeeCode: input.employeeCode,
          designation: input.designation,
          department: input.department,
        },
        tx
      );

      if (input.subjectIds.length > 0) {
        await teacherRepository.replaceSubjects(created.id, input.subjectIds, tx);
      }

      await auditLogService.record(
        { userId: ctx.userId, userRole: ctx.role, module: 'teachers', action: 'CREATE', entityId: created.id, after: created, meta: ctx.meta },
        tx
      );

      return created;
    });
  },

  async update(id: string, input: UpdateTeacherInput, ctx: ControllerContext) {
    const existing = await teacherRepository.findById(id);
    if (!existing) throw new NotFoundError('Teacher not found');

    if (input.employeeCode && input.employeeCode !== existing.employeeCode) {
      const conflict = await teacherRepository.findByEmployeeCode(input.employeeCode);
      if (conflict) throw new ConflictError('A teacher with this employee code already exists');
    }

    return withTransaction(async (tx) => {
      const result = await teacherRepository.update(id, input, tx);
      await auditLogService.record(
        { userId: ctx.userId, userRole: ctx.role, module: 'teachers', action: 'UPDATE', entityId: id, before: existing, after: result, meta: ctx.meta },
        tx
      );
      return result;
    });
  },

  async updateStatus(id: string, input: UpdateTeacherStatusInput, ctx: ControllerContext) {
    const existing = await teacherRepository.findById(id);
    if (!existing) throw new NotFoundError('Teacher not found');

    return withTransaction(async (tx) => {
      const result = await teacherRepository.update(id, { status: input.status }, tx);
      await auditLogService.record(
        {
          userId: ctx.userId,
          userRole: ctx.role,
          module: 'teachers',
          action: 'UPDATE',
          entityId: id,
          before: { status: existing.status },
          after: { status: input.status, reason: input.reason },
          meta: ctx.meta,
        },
        tx
      );
      return result;
    });
  },

  async assignSubjects(id: string, input: AssignTeacherSubjectsInput, ctx: ControllerContext) {
    const existing = await teacherRepository.findById(id);
    if (!existing) throw new NotFoundError('Teacher not found');

    return withTransaction(async (tx) => {
      const result = await teacherRepository.replaceSubjects(id, input.subjectIds, tx);
      await auditLogService.record(
        {
          userId: ctx.userId,
          userRole: ctx.role,
          module: 'teachers',
          action: 'ASSIGN',
          entityId: id,
          before: { subjectIds: existing.subjects.map((s) => s.subjectId) },
          after: { subjectIds: input.subjectIds },
          meta: ctx.meta,
        },
        tx
      );
      return result;
    });
  },

  async softDelete(id: string, ctx: ControllerContext) {
    const existing = await teacherRepository.findById(id);
    if (!existing) throw new NotFoundError('Teacher not found');

    await withTransaction(async (tx) => {
      await teacherRepository.softDelete(id, tx);
      await auditLogService.record(
        { userId: ctx.userId, userRole: ctx.role, module: 'teachers', action: 'DELETE', entityId: id, before: existing, meta: ctx.meta },
        tx
      );
    });
  },
};
