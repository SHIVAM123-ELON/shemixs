import { withTransaction } from '../db/transaction';
import { assignmentRepository, type AssignmentListFilters } from '../repositories/assignment.repository';
import { auditLogService } from './audit-log.service';
import { buildPaginationMeta } from '../lib/query';
import { NotFoundError } from '../lib/errors';
import type {
  CreateAssignmentInput,
  UpdateAssignmentInput,
  SubmitAssignmentInput,
  EvaluateAssignmentInput,
} from '../validators/assignment.validators';
import type { ControllerContext } from '../controllers/base.controller';

export const assignmentService = {
  async list(filters: AssignmentListFilters) {
    const { items, totalItems } = await assignmentRepository.findMany(filters);
    return { items, pagination: buildPaginationMeta(filters, totalItems) };
  },

  async getById(id: string) {
    const assignment = await assignmentRepository.findById(id);
    if (!assignment) throw new NotFoundError('Assignment not found');
    return assignment;
  },

  async create(input: CreateAssignmentInput, ctx: ControllerContext) {
    return withTransaction(async (tx) => {
      const created = await assignmentRepository.create(
        {
          title: input.title,
          description: input.description,
          subjectId: input.subjectId,
          batchId: input.batchId,
          teacherId: input.teacherId ?? ctx.userId,
          dueDate: input.dueDate,
          maxMarks: input.maxMarks,
          status: 'DRAFT',
        },
        tx
      );
      await auditLogService.record(
        { userId: ctx.userId, userRole: ctx.role, module: 'assignments', action: 'CREATE', entityId: created.id, after: created, meta: ctx.meta },
        tx
      );
      return created;
    });
  },

  async update(id: string, input: UpdateAssignmentInput, ctx: ControllerContext) {
    const existing = await assignmentRepository.findById(id);
    if (!existing) throw new NotFoundError('Assignment not found');

    return withTransaction(async (tx) => {
      const result = await assignmentRepository.update(id, input, tx);
      await auditLogService.record(
        { userId: ctx.userId, userRole: ctx.role, module: 'assignments', action: 'UPDATE', entityId: id, before: existing, after: result, meta: ctx.meta },
        tx
      );
      return result;
    });
  },

  async publish(id: string, ctx: ControllerContext) {
    const existing = await assignmentRepository.findById(id);
    if (!existing) throw new NotFoundError('Assignment not found');

    return withTransaction(async (tx) => {
      const result = await assignmentRepository.update(id, { status: 'PUBLISHED' }, tx);
      await auditLogService.record(
        { userId: ctx.userId, userRole: ctx.role, module: 'assignments', action: 'PUBLISH', entityId: id, before: { status: existing.status }, after: { status: 'PUBLISHED' }, meta: ctx.meta },
        tx
      );
      return result;
    });
  },

  async listSubmissions(assignmentId: string) {
    const assignment = await assignmentRepository.findById(assignmentId);
    if (!assignment) throw new NotFoundError('Assignment not found');
    return assignmentRepository.listSubmissions(assignmentId);
  },

  async submit(assignmentId: string, input: SubmitAssignmentInput, ctx: ControllerContext) {
    const assignment = await assignmentRepository.findById(assignmentId);
    if (!assignment) throw new NotFoundError('Assignment not found');

    const isLate = new Date() > assignment.dueDate;

    return withTransaction(async (tx) => {
      const result = await assignmentRepository.upsertSubmission(assignmentId, input.studentId, input.contentUrl, isLate, tx);
      await auditLogService.record(
        {
          userId: ctx.userId,
          userRole: ctx.role,
          module: 'assignments',
          action: 'UPDATE',
          entityId: assignmentId,
          after: { studentId: input.studentId, status: result.status },
          meta: ctx.meta,
        },
        tx
      );
      return result;
    });
  },

  async evaluate(assignmentId: string, studentId: string, input: EvaluateAssignmentInput, ctx: ControllerContext) {
    const submission = await assignmentRepository.findSubmission(assignmentId, studentId);
    if (!submission) throw new NotFoundError('Submission not found for this student');

    return withTransaction(async (tx) => {
      const result = await assignmentRepository.evaluateSubmission(submission.id, input.marks, input.feedback, tx);
      await auditLogService.record(
        {
          userId: ctx.userId,
          userRole: ctx.role,
          module: 'assignments',
          action: 'UPDATE',
          entityId: assignmentId,
          before: { marks: submission.marks, status: submission.status },
          after: { marks: input.marks, status: 'EVALUATED' },
          meta: ctx.meta,
        },
        tx
      );
      return result;
    });
  },

  async softDelete(id: string, ctx: ControllerContext) {
    const existing = await assignmentRepository.findById(id);
    if (!existing) throw new NotFoundError('Assignment not found');

    await withTransaction(async (tx) => {
      await assignmentRepository.softDelete(id, tx);
      await auditLogService.record(
        { userId: ctx.userId, userRole: ctx.role, module: 'assignments', action: 'DELETE', entityId: id, before: existing, meta: ctx.meta },
        tx
      );
    });
  },
};
