/**
 * Admission Service
 *
 * The interesting piece here is `approve`: approving an admission
 * converts it into a real Student (+ User) in the same transaction as
 * the status change + timeline event, so an approval can never
 * "half-succeed" (admission marked APPROVED but no student created,
 * or vice versa).
 */
import { withTransaction } from '../db/transaction';
import { admissionRepository, type AdmissionListFilters } from '../repositories/admission.repository';
import { studentRepository } from '../repositories/student.repository';
import { roleRepository } from '../repositories/role.repository';
import { auditLogService } from './audit-log.service';
import { hashPassword } from '../auth/password';
import { buildPaginationMeta } from '../lib/query';
import { ConflictError, NotFoundError, ValidationError } from '../lib/errors';
import type {
  CreateAdmissionInput,
  UpdateAdmissionInput,
  VerifyAdmissionInput,
  ApproveAdmissionInput,
  RejectAdmissionInput,
} from '../validators/admission.validators';
import type { ControllerContext } from '../controllers/base.controller';
import { randomBytes } from 'crypto';

function assertTransition(current: string, allowedFrom: string[], action: string) {
  if (!allowedFrom.includes(current)) {
    throw new ConflictError(`Cannot ${action} an admission with status ${current}`);
  }
}

export const admissionService = {
  async list(filters: AdmissionListFilters) {
    const { items, totalItems } = await admissionRepository.findMany(filters);
    return { items, pagination: buildPaginationMeta(filters, totalItems) };
  },

  async getById(id: string) {
    const admission = await admissionRepository.findById(id);
    if (!admission) throw new NotFoundError('Admission not found');
    return admission;
  },

  /** Alias for getById — the "Admission Timeline" is just the admission's `events`, already included. */
  async timeline(id: string) {
    return this.getById(id);
  },

  async create(input: CreateAdmissionInput, ctx: ControllerContext) {
    return withTransaction(async (tx) => {
      const created = await admissionRepository.create(
        {
          applicantName: input.applicantName,
          email: input.email.toLowerCase(),
          phone: input.phone,
          dateOfBirth: input.dateOfBirth,
          guardianName: input.guardianName,
          address: input.address,
          desiredBatchId: input.desiredBatchId,
          status: 'PENDING',
        },
        tx
      );

      await admissionRepository.addEvent(created.id, 'PENDING', 'Application submitted', ctx.userId, tx);

      await auditLogService.record(
        { userId: ctx.userId, userRole: ctx.role, module: 'admissions', action: 'CREATE', entityId: created.id, after: created, meta: ctx.meta },
        tx
      );

      return created;
    });
  },

  async update(id: string, input: UpdateAdmissionInput, ctx: ControllerContext) {
    const existing = await admissionRepository.findById(id);
    if (!existing) throw new NotFoundError('Admission not found');
    assertTransition(existing.status, ['PENDING', 'VERIFIED'], 'edit');

    return withTransaction(async (tx) => {
      const result = await admissionRepository.update(id, input, tx);
      await auditLogService.record(
        { userId: ctx.userId, userRole: ctx.role, module: 'admissions', action: 'UPDATE', entityId: id, before: existing, after: result, meta: ctx.meta },
        tx
      );
      return result;
    });
  },

  async verify(id: string, input: VerifyAdmissionInput, ctx: ControllerContext) {
    const existing = await admissionRepository.findById(id);
    if (!existing) throw new NotFoundError('Admission not found');
    assertTransition(existing.status, ['PENDING'], 'verify');

    return withTransaction(async (tx) => {
      const result = await admissionRepository.update(id, { status: 'VERIFIED' }, tx);
      await admissionRepository.addEvent(id, 'VERIFIED', input.note, ctx.userId, tx);
      await auditLogService.record(
        { userId: ctx.userId, userRole: ctx.role, module: 'admissions', action: 'APPROVE', entityId: id, before: { status: existing.status }, after: { status: 'VERIFIED' }, meta: ctx.meta },
        tx
      );
      return result;
    });
  },

  async approve(id: string, input: ApproveAdmissionInput, ctx: ControllerContext) {
    const existing = await admissionRepository.findById(id);
    if (!existing) throw new NotFoundError('Admission not found');
    assertTransition(existing.status, ['VERIFIED', 'PENDING'], 'approve');

    const studentRole = await roleRepository.findByName('STUDENT');
    if (!studentRole) throw new ValidationError('STUDENT role is not seeded — run the database seed first');

    return withTransaction(async (tx) => {
      const tempPassword = randomBytes(16).toString('hex');
      const passwordHash = await hashPassword(tempPassword);

      const user = await tx.user.create({
        data: {
          fullName: existing.applicantName,
          email: existing.email,
          phone: existing.phone,
          passwordHash,
          roleId: studentRole.id,
          status: 'PENDING',
        },
      });

      const targetBatchId = input.batchId ?? existing.desiredBatchId ?? undefined;

      const student = await studentRepository.create(
        {
          userId: user.id,
          dateOfBirth: existing.dateOfBirth,
          address: existing.address,
          batchId: targetBatchId,
          sectionId: input.sectionId,
          status: targetBatchId ? 'ACTIVE' : 'ENROLLMENT_PENDING',
        },
        tx
      );

      const result = await admissionRepository.update(
        id,
        { status: 'APPROVED', convertedStudentId: student.id },
        tx
      );

      await admissionRepository.addEvent(id, 'APPROVED', input.note, ctx.userId, tx);

      await auditLogService.record(
        {
          userId: ctx.userId,
          userRole: ctx.role,
          module: 'admissions',
          action: 'APPROVE',
          entityId: id,
          before: { status: existing.status },
          after: { status: 'APPROVED', studentId: student.id },
          meta: ctx.meta,
        },
        tx
      );

      return { admission: result, student };
    });
  },

  async reject(id: string, input: RejectAdmissionInput, ctx: ControllerContext) {
    const existing = await admissionRepository.findById(id);
    if (!existing) throw new NotFoundError('Admission not found');
    assertTransition(existing.status, ['PENDING', 'VERIFIED'], 'reject');

    return withTransaction(async (tx) => {
      const result = await admissionRepository.update(id, { status: 'REJECTED', rejectionReason: input.reason }, tx);
      await admissionRepository.addEvent(id, 'REJECTED', input.reason, ctx.userId, tx);
      await auditLogService.record(
        { userId: ctx.userId, userRole: ctx.role, module: 'admissions', action: 'REJECT', entityId: id, before: { status: existing.status }, after: { status: 'REJECTED', reason: input.reason }, meta: ctx.meta },
        tx
      );
      return result;
    });
  },
};
