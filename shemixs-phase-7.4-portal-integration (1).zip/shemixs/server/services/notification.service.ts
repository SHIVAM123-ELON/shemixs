/**
 * Notification Service
 *
 * The single entry point every other module calls to notify a user —
 * `notify(userId, { title, body, channels })`. Callers never touch
 * `emailService`/`whatsappService` directly; this is what keeps
 * "send an email" and "send a WhatsApp message" from being duplicated
 * across every module that wants to notify someone (admissions,
 * results, payments, certificates, ...).
 *
 * One `Notification` row is created per requested channel so
 * IN_APP/EMAIL/WHATSAPP delivery status is tracked independently —
 * an email bounce doesn't affect the in-app bell icon.
 */
import { notificationRepository } from '../repositories/notification.repository';
import { userRepository } from '../repositories/user.repository';
import { emailService } from '../email/email.service';
import { whatsappService } from '../whatsapp/whatsapp.service';
import { logger } from '../lib/logger';
import type { NotificationChannel } from '@prisma/client';

export interface NotifyInput {
  userId: string;
  title: string;
  body: string;
  /** Optional deep-link payload for the frontend, e.g. { type: "result", resultId }. */
  data?: Record<string, unknown>;
  channels: NotificationChannel[];
  /** Pre-rendered HTML for the EMAIL channel — if omitted, `body` is used as plain text. */
  emailHtml?: string;
}

export const notificationService = {
  async notify(input: NotifyInput) {
    const user = await userRepository.findById(input.userId);
    if (!user) {
      logger.warn('notify() called for unknown user', { userId: input.userId });
      return [];
    }

    const results = await Promise.all(
      input.channels.map(async (channel) => {
        const notification = await notificationRepository.create({
          userId: input.userId,
          channel,
          title: input.title,
          body: input.body,
          data: input.data,
          status: channel === 'IN_APP' ? 'SENT' : 'QUEUED',
          sentAt: channel === 'IN_APP' ? new Date() : undefined,
        });

        if (channel === 'EMAIL') {
          const result = await emailService.send({
            to: user.email,
            subject: input.title,
            html: input.emailHtml ?? `<p>${input.body}</p>`,
          });
          await notificationRepository.update(notification.id, {
            status: result.success ? 'SENT' : 'FAILED',
            sentAt: result.success ? new Date() : undefined,
            failureReason: result.error,
          });
        }

        if (channel === 'WHATSAPP') {
          if (!user.phone) {
            await notificationRepository.update(notification.id, { status: 'FAILED', failureReason: 'User has no phone number on file' });
          } else {
            const result = await whatsappService.send({ to: user.phone, body: `${input.title}\n\n${input.body}` });
            await notificationRepository.update(notification.id, {
              status: result.success ? 'SENT' : 'FAILED',
              sentAt: result.success ? new Date() : undefined,
              failureReason: result.error,
            });
          }
        }

        return notification;
      })
    );

    return results;
  },

  async list(filters: Parameters<typeof notificationRepository.findMany>[0]) {
    const { items, totalItems, unreadCount } = await notificationRepository.findMany(filters);
    const totalPages = Math.max(1, Math.ceil(totalItems / filters.pageSize));
    return {
      items,
      unreadCount,
      pagination: {
        page: filters.page,
        pageSize: filters.pageSize,
        totalItems,
        totalPages,
        hasNextPage: filters.page < totalPages,
        hasPreviousPage: filters.page > 1,
      },
    };
  },

  async markRead(id: string) {
    return notificationRepository.markRead(id);
  },

  async markAllRead(userId: string) {
    await notificationRepository.markAllRead(userId);
  },
};
