import { randomBytes } from 'crypto';
import { withTransaction } from '../db/transaction';
import { certificateRepository, type CertificateListFilters } from '../repositories/certificate.repository';
import { studentRepository } from '../repositories/student.repository';
import { auditLogService } from './audit-log.service';
import { buildPaginationMeta } from '../lib/query';
import { NotFoundError, ConflictError } from '../lib/errors';
import type { IssueCertificateInput } from '../validators/certificate.validators';
import type { ControllerContext } from '../controllers/base.controller';

function generateVerificationCode(): string {
  // Short, human-typeable code (e.g. printed under a QR code) —
  // uppercase base32-ish alphabet, grouped for readability.
  const raw = randomBytes(6).toString('hex').toUpperCase();
  return `SHX-${raw.slice(0, 4)}-${raw.slice(4, 8)}-${raw.slice(8, 12)}`;
}

export const certificateService = {
  async list(filters: CertificateListFilters) {
    const { items, totalItems } = await certificateRepository.findMany(filters);
    return { items, pagination: buildPaginationMeta(filters, totalItems) };
  },

  async getById(id: string) {
    const certificate = await certificateRepository.findById(id);
    if (!certificate) throw new NotFoundError('Certificate not found');
    return certificate;
  },

  /** "Verify Placeholder" — public-facing lookup by code, no auth/RBAC (called from an unauthenticated verify page). */
  async verify(code: string) {
    const certificate = await certificateRepository.findByVerificationCode(code);
    if (!certificate) throw new NotFoundError('No certificate found for this verification code');
    return {
      valid: certificate.status === 'ISSUED',
      status: certificate.status,
      title: certificate.title,
      type: certificate.type,
      issuedAt: certificate.issuedAt,
      studentName: certificate.student.user.fullName,
    };
  },

  async issue(input: IssueCertificateInput, ctx: ControllerContext) {
    const student = await studentRepository.findById(input.studentId);
    if (!student) throw new NotFoundError('Student not found');

    return withTransaction(async (tx) => {
      let code = generateVerificationCode();
      // Extremely unlikely to collide, but guard against it since the
      // column is unique — regenerate once if it somehow does.
      if (await certificateRepository.findByVerificationCode(code, tx)) {
        code = generateVerificationCode();
      }

      const created = await certificateRepository.create(
        {
          studentId: input.studentId,
          type: input.type,
          title: input.title,
          verificationCode: code,
          metadata: input.metadata as object | undefined,
          issuedBy: ctx.userId,
        },
        tx
      );

      await auditLogService.record(
        { userId: ctx.userId, userRole: ctx.role, module: 'certificates', action: 'CREATE', entityId: created.id, after: created, meta: ctx.meta },
        tx
      );

      return created;
    });
  },

  async revoke(id: string, ctx: ControllerContext) {
    const existing = await certificateRepository.findById(id);
    if (!existing) throw new NotFoundError('Certificate not found');
    if (existing.status === 'REVOKED') throw new ConflictError('Certificate is already revoked');

    return withTransaction(async (tx) => {
      const result = await certificateRepository.revoke(id, tx);
      await auditLogService.record(
        { userId: ctx.userId, userRole: ctx.role, module: 'certificates', action: 'UPDATE', entityId: id, before: { status: existing.status }, after: { status: 'REVOKED' }, meta: ctx.meta },
        tx
      );
      return result;
    });
  },

  async studentHistory(studentId: string) {
    return certificateRepository.studentHistory(studentId);
  },
};
