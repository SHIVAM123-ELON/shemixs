import { getWhatsappConfig, WHATSAPP_API_BASE } from './whatsapp.config';
import { logger } from '../lib/logger';

export interface SendWhatsappInput {
  /** E.164 format, e.g. "+919876543210" */
  to: string;
  body: string;
}

export const whatsappService = {
  /**
   * Sends a free-text WhatsApp message. NOTE: Meta's Cloud API only
   * allows free-text business-initiated messages within a 24-hour
   * customer service window (i.e. after the user has messaged first).
   * Proactive notifications outside that window (e.g. "your result is
   * out") must use a pre-approved message *template* instead — see
   * the docs' Future Integration Points for wiring template support.
   */
  async send(input: SendWhatsappInput): Promise<{ success: boolean; error?: string }> {
    try {
      const config = getWhatsappConfig();

      const response = await fetch(`${WHATSAPP_API_BASE}/${config.WHATSAPP_PHONE_NUMBER_ID}/messages`, {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${config.WHATSAPP_ACCESS_TOKEN}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          messaging_product: 'whatsapp',
          to: input.to,
          type: 'text',
          text: { body: input.body },
        }),
      });

      if (!response.ok) {
        const errorBody = await response.text();
        logger.error('WhatsApp send failed', { status: response.status, errorBody, to: input.to });
        return { success: false, error: `WhatsApp API error ${response.status}` };
      }

      return { success: true };
    } catch (error) {
      logger.error('WhatsApp send threw', { error, to: input.to });
      return { success: false, error: error instanceof Error ? error.message : 'Unknown WhatsApp error' };
    }
  },
};
