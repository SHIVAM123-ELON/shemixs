/**
 * WhatsApp (Meta Cloud API) Config
 *
 * No SDK dependency — the WhatsApp Business Cloud API is a plain REST
 * API, so `whatsapp.service.ts` calls it with `fetch` directly rather
 * than pulling in a wrapper package for two env vars and one endpoint.
 */
import { z } from 'zod';

const whatsappEnvSchema = z.object({
  WHATSAPP_ACCESS_TOKEN: z.string().min(1, 'WHATSAPP_ACCESS_TOKEN is required'),
  WHATSAPP_PHONE_NUMBER_ID: z.string().min(1, 'WHATSAPP_PHONE_NUMBER_ID is required'),
});

export function getWhatsappConfig() {
  const parsed = whatsappEnvSchema.safeParse(process.env);
  if (!parsed.success) {
    const issues = parsed.error.issues.map((i) => `  - ${i.path.join('.')}: ${i.message}`).join('\n');
    throw new Error(`Invalid WhatsApp configuration:\n${issues}`);
  }
  return parsed.data;
}

export const WHATSAPP_API_BASE = 'https://graph.facebook.com/v20.0';
