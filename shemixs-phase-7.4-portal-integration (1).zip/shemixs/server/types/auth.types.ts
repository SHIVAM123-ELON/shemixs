import type { RoleName, UserStatus } from '@prisma/client';

export interface AuthenticatedUser {
  id: string;
  fullName: string;
  email: string;
  avatar: string | null;
  status: UserStatus;
  role: RoleName;
  emailVerified: boolean;
}

export interface TokenPair {
  accessToken: string;
  refreshToken: string;
  accessTokenExpiresInSeconds: number;
  refreshTokenExpiresInSeconds: number;
}

export interface RequestMeta {
  device?: string;
  browser?: string;
  ipAddress?: string;
}
