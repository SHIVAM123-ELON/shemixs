/**
 * Auth Guard
 *
 * Route handlers that require an authenticated user call
 * `requireUser(req)` to get the verified token payload, or let the
 * thrown UnauthorizedError propagate to `handleApiError`. This is the
 * Node-runtime counterpart to the Edge Runtime checks in
 * /middleware.ts — middleware handles coarse page-level redirects,
 * this handles API-level authorization.
 */
import type { NextRequest } from 'next/server';
import { verifyAccessToken } from './jwt';
import { ACCESS_TOKEN_COOKIE } from './cookies';
import { UnauthorizedError, ForbiddenError } from '../lib/errors';
import type { AccessTokenPayload } from './jwt';
import type { RoleName } from '@prisma/client';

export async function requireUser(req: NextRequest): Promise<AccessTokenPayload> {
  const token = req.cookies.get(ACCESS_TOKEN_COOKIE)?.value;
  if (!token) throw new UnauthorizedError();

  try {
    return await verifyAccessToken(token);
  } catch {
    throw new UnauthorizedError('Session expired, please log in again');
  }
}

export async function requireRole(req: NextRequest, allowed: RoleName[]): Promise<AccessTokenPayload> {
  const payload = await requireUser(req);
  if (!allowed.includes(payload.role as RoleName)) {
    throw new ForbiddenError();
  }
  return payload;
}
