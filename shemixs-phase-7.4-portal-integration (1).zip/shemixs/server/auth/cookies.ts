/**
 * Cookie Helper
 *
 * Centralizes cookie names and options so every route sets/clears
 * auth cookies identically. All auth cookies are HTTP-only (no
 * client-side JS access), Secure in production, and SameSite=Lax
 * (protects against CSRF on cross-site requests while allowing
 * normal top-level navigation).
 */
import type { NextResponse } from 'next/server';

export const ACCESS_TOKEN_COOKIE = 'shemixs_access_token';
export const REFRESH_TOKEN_COOKIE = 'shemixs_refresh_token';

const isProd = process.env.NODE_ENV === 'production';

const baseCookieOptions = {
  httpOnly: true,
  secure: isProd,
  sameSite: 'lax' as const,
  path: '/',
};

export function setAccessTokenCookie(res: NextResponse, token: string, maxAgeSeconds: number) {
  res.cookies.set(ACCESS_TOKEN_COOKIE, token, {
    ...baseCookieOptions,
    maxAge: maxAgeSeconds,
  });
}

export function setRefreshTokenCookie(res: NextResponse, token: string, maxAgeSeconds: number, rememberMe: boolean) {
  res.cookies.set(REFRESH_TOKEN_COOKIE, token, {
    ...baseCookieOptions,
    // If "remember me" is off, omit maxAge so the cookie is a session
    // cookie that disappears when the browser closes.
    ...(rememberMe ? { maxAge: maxAgeSeconds } : {}),
  });
}

export function clearAuthCookies(res: NextResponse) {
  res.cookies.set(ACCESS_TOKEN_COOKIE, '', { ...baseCookieOptions, maxAge: 0 });
  res.cookies.set(REFRESH_TOKEN_COOKIE, '', { ...baseCookieOptions, maxAge: 0 });
}
