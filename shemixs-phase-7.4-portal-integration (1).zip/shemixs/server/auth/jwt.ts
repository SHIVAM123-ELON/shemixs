/**
 * JWT Helper
 *
 * Uses `jose` rather than `jsonwebtoken`. Reasoning: route middleware
 * (server/auth/verify at the edge, see /middleware.ts) runs on the Next.js
 * Edge Runtime, which does not have Node's `crypto` module that
 * `jsonwebtoken` depends on. `jose` works identically in both the Edge
 * Runtime and the Node runtime, so the same helper verifies tokens
 * everywhere without a second implementation.
 */
import { SignJWT, jwtVerify, type JWTPayload } from 'jose';
import { getEnv } from '../lib/env';

export interface AccessTokenPayload extends JWTPayload {
  sub: string; // userId
  role: string;
  email: string;
}

export interface RefreshTokenPayload extends JWTPayload {
  sub: string; // userId
  sessionId: string;
}

function toSecretKey(secret: string) {
  return new TextEncoder().encode(secret);
}

export async function signAccessToken(payload: Omit<AccessTokenPayload, keyof JWTPayload>): Promise<string> {
  const env = getEnv();
  return new SignJWT(payload)
    .setProtectedHeader({ alg: 'HS256' })
    .setIssuedAt()
    .setExpirationTime(env.JWT_ACCESS_EXPIRES_IN)
    .sign(toSecretKey(env.JWT_SECRET));
}

export async function signRefreshToken(payload: Omit<RefreshTokenPayload, keyof JWTPayload>): Promise<string> {
  const env = getEnv();
  return new SignJWT(payload)
    .setProtectedHeader({ alg: 'HS256' })
    .setIssuedAt()
    .setExpirationTime(env.JWT_REFRESH_EXPIRES_IN)
    .sign(toSecretKey(env.JWT_REFRESH_SECRET));
}

export async function verifyAccessToken(token: string): Promise<AccessTokenPayload> {
  const env = getEnv();
  const { payload } = await jwtVerify(token, toSecretKey(env.JWT_SECRET));
  return payload as AccessTokenPayload;
}

export async function verifyRefreshToken(token: string): Promise<RefreshTokenPayload> {
  const env = getEnv();
  const { payload } = await jwtVerify(token, toSecretKey(env.JWT_REFRESH_SECRET));
  return payload as RefreshTokenPayload;
}
