/**
 * Password Helper
 *
 * Uses `bcryptjs` instead of native `bcrypt`. Reasoning: native `bcrypt`
 * ships a compiled C++ binding that must match the exact deployment
 * runtime (problematic on serverless targets like Netlify Functions,
 * which frequently rebuild/relocate the function bundle). `bcryptjs` is
 * a pure-JS, API-compatible drop-in with no native build step, at a
 * small CPU cost that's irrelevant for auth-frequency operations.
 */
import bcrypt from 'bcryptjs';
import { randomBytes, createHash } from 'crypto';

const SALT_ROUNDS = 12;

export async function hashPassword(plain: string): Promise<string> {
  return bcrypt.hash(plain, SALT_ROUNDS);
}

export async function verifyPassword(plain: string, hash: string): Promise<boolean> {
  return bcrypt.compare(plain, hash);
}

/**
 * Generates a random token for password reset / email verification
 * flows. Returns both the raw token (sent to the user, single-use)
 * and its hash (stored in the DB, looked up on redemption).
 *
 * Deliberately NOT bcrypt here: reset/verification tokens must be
 * looked up by exact hash match in the DB (`findUnique({ tokenHash })`),
 * which requires a deterministic digest. bcrypt salts every hash
 * differently, so it can't support that lookup — SHA-256 can, and the
 * token itself is a high-entropy random value rather than a
 * human-chosen secret, so SHA-256 (no per-hash salt) is appropriate.
 */
export function generateVerificationToken(): { raw: string; hash: string } {
  const raw = randomBytes(32).toString('hex');
  const hash = createHash('sha256').update(raw).digest('hex');
  return { raw, hash };
}

export function hashVerificationToken(raw: string): string {
  return createHash('sha256').update(raw).digest('hex');
}
