import { z } from 'zod';
import { listQuerySchema } from '../lib/query';

export const batchStatusEnum = z.enum(['ACTIVE', 'CLOSED', 'UPCOMING']);

export const createBatchSchema = z.object({
  name: z.string().min(2, 'Name is required'),
  capacity: z.coerce.number().int().positive().optional(),
});

export const updateBatchSchema = z.object({
  name: z.string().min(2).optional(),
  capacity: z.coerce.number().int().positive().nullable().optional(),
});

export const updateBatchStatusSchema = z.object({
  status: batchStatusEnum,
});

export const assignBatchStudentsSchema = z.object({
  studentIds: z.array(z.string().uuid()).min(1, 'At least one student is required'),
});

export const assignBatchTeachersSchema = z.object({
  teacherIds: z.array(z.string().uuid()).min(1, 'At least one teacher is required'),
});

export const batchListQuerySchema = listQuerySchema.extend({
  status: batchStatusEnum.optional(),
});

export type CreateBatchInput = z.infer<typeof createBatchSchema>;
export type UpdateBatchInput = z.infer<typeof updateBatchSchema>;
export type UpdateBatchStatusInput = z.infer<typeof updateBatchStatusSchema>;
export type AssignBatchStudentsInput = z.infer<typeof assignBatchStudentsSchema>;
export type AssignBatchTeachersInput = z.infer<typeof assignBatchTeachersSchema>;
