import { z } from 'zod';

/** Every /api/<module>/[id] route validates the route param with this. */
export const idParamSchema = z.object({
  id: z.string().uuid('Invalid id'),
});

export type IdParam = z.infer<typeof idParamSchema>;
