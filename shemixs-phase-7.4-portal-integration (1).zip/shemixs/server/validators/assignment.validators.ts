import { z } from 'zod';
import { listQuerySchema } from '../lib/query';

export const assignmentStatusEnum = z.enum(['DRAFT', 'PUBLISHED']);
export const submissionStatusEnum = z.enum(['NOT_SUBMITTED', 'SUBMITTED', 'LATE', 'EVALUATED']);

export const createAssignmentSchema = z.object({
  title: z.string().min(2, 'Title is required'),
  description: z.string().optional(),
  subjectId: z.string().uuid().optional(),
  batchId: z.string().uuid().optional(),
  teacherId: z.string().uuid().optional(),
  dueDate: z.coerce.date(),
  maxMarks: z.coerce.number().int().positive().optional(),
});

export const updateAssignmentSchema = z.object({
  title: z.string().min(2).optional(),
  description: z.string().optional(),
  subjectId: z.string().uuid().nullable().optional(),
  batchId: z.string().uuid().nullable().optional(),
  dueDate: z.coerce.date().optional(),
  maxMarks: z.coerce.number().int().positive().nullable().optional(),
});

export const submitAssignmentSchema = z.object({
  studentId: z.string().uuid(),
  contentUrl: z.string().url().optional(),
});

export const evaluateAssignmentSchema = z.object({
  marks: z.coerce.number().int().min(0),
  feedback: z.string().optional(),
});

export const assignmentListQuerySchema = listQuerySchema.extend({
  status: assignmentStatusEnum.optional(),
  subjectId: z.string().uuid().optional(),
  batchId: z.string().uuid().optional(),
});

export type CreateAssignmentInput = z.infer<typeof createAssignmentSchema>;
export type UpdateAssignmentInput = z.infer<typeof updateAssignmentSchema>;
export type SubmitAssignmentInput = z.infer<typeof submitAssignmentSchema>;
export type EvaluateAssignmentInput = z.infer<typeof evaluateAssignmentSchema>;
