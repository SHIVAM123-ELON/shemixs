import { z } from 'zod';
import { listQuerySchema } from '../lib/query';

export const studentStatusEnum = z.enum(['ACTIVE', 'INACTIVE', 'ALUMNI', 'SUSPENDED', 'ENROLLMENT_PENDING']);

export const createStudentSchema = z.object({
  fullName: z.string().min(2, 'Full name is required'),
  email: z.string().email('Enter a valid email address'),
  phone: z.string().optional(),
  admissionNo: z.string().optional(),
  dateOfBirth: z.coerce.date().optional(),
  gender: z.string().optional(),
  address: z.string().optional(),
  batchId: z.string().uuid().optional(),
  sectionId: z.string().uuid().optional(),
});

export const updateStudentSchema = z.object({
  fullName: z.string().min(2).optional(),
  phone: z.string().optional(),
  admissionNo: z.string().optional(),
  dateOfBirth: z.coerce.date().optional(),
  gender: z.string().optional(),
  address: z.string().optional(),
  batchId: z.string().uuid().nullable().optional(),
  sectionId: z.string().uuid().nullable().optional(),
});

export const updateStudentStatusSchema = z.object({
  status: studentStatusEnum,
  reason: z.string().optional(),
});

export const enrollStudentSchema = z.object({
  batchId: z.string().uuid('A valid batch is required'),
  sectionId: z.string().uuid().optional(),
});

export const studentListQuerySchema = listQuerySchema.extend({
  status: studentStatusEnum.optional(),
  batchId: z.string().uuid().optional(),
  sectionId: z.string().uuid().optional(),
});

export type CreateStudentInput = z.infer<typeof createStudentSchema>;
export type UpdateStudentInput = z.infer<typeof updateStudentSchema>;
export type UpdateStudentStatusInput = z.infer<typeof updateStudentStatusSchema>;
export type EnrollStudentInput = z.infer<typeof enrollStudentSchema>;
export type StudentListQuery = z.infer<typeof studentListQuerySchema>;
