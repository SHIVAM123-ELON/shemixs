import { z } from 'zod';

export const dayOfWeekEnum = z.enum(['MONDAY', 'TUESDAY', 'WEDNESDAY', 'THURSDAY', 'FRIDAY', 'SATURDAY', 'SUNDAY']);

const timeString = z.string().regex(/^([01]\d|2[0-3]):[0-5]\d$/, 'Time must be in HH:mm 24-hour format');

export const createTimetableEntrySchema = z
  .object({
    batchId: z.string().uuid().optional(),
    sectionId: z.string().uuid().optional(),
    subjectId: z.string().uuid().optional(),
    teacherId: z.string().uuid().optional(),
    dayOfWeek: dayOfWeekEnum,
    startTime: timeString,
    endTime: timeString,
    room: z.string().optional(),
  })
  .refine((data) => data.startTime < data.endTime, {
    message: 'startTime must be before endTime',
    path: ['endTime'],
  });

export const updateTimetableEntrySchema = z.object({
  batchId: z.string().uuid().nullable().optional(),
  sectionId: z.string().uuid().nullable().optional(),
  subjectId: z.string().uuid().nullable().optional(),
  teacherId: z.string().uuid().nullable().optional(),
  dayOfWeek: dayOfWeekEnum.optional(),
  startTime: timeString.optional(),
  endTime: timeString.optional(),
  room: z.string().optional(),
});

export const timetableListQuerySchema = z.object({
  batchId: z.string().uuid().optional(),
  sectionId: z.string().uuid().optional(),
  teacherId: z.string().uuid().optional(),
  dayOfWeek: dayOfWeekEnum.optional(),
});

export type CreateTimetableEntryInput = z.infer<typeof createTimetableEntrySchema>;
export type UpdateTimetableEntryInput = z.infer<typeof updateTimetableEntrySchema>;
export type TimetableListQuery = z.infer<typeof timetableListQuerySchema>;
