import { z } from 'zod';
import { listQuerySchema } from '../lib/query';

export const certificateStatusEnum = z.enum(['ISSUED', 'REVOKED']);

export const issueCertificateSchema = z.object({
  studentId: z.string().uuid(),
  type: z.string().min(1, 'Certificate type is required'),
  title: z.string().min(1, 'Title is required'),
  metadata: z.record(z.unknown()).optional(),
});

export const revokeCertificateSchema = z.object({
  reason: z.string().optional(),
});

export const certificateListQuerySchema = listQuerySchema.extend({
  status: certificateStatusEnum.optional(),
  studentId: z.string().uuid().optional(),
  type: z.string().optional(),
});

export type IssueCertificateInput = z.infer<typeof issueCertificateSchema>;
export type RevokeCertificateInput = z.infer<typeof revokeCertificateSchema>;
