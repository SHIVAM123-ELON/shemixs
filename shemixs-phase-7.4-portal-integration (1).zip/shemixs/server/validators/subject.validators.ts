import { z } from 'zod';
import { listQuerySchema } from '../lib/query';

export const createSubjectSchema = z.object({
  name: z.string().min(2, 'Name is required'),
  code: z.string().min(1, 'Code is required'),
  courseId: z.string().uuid().optional(),
});

export const updateSubjectSchema = z.object({
  name: z.string().min(2).optional(),
  code: z.string().min(1).optional(),
});

export const assignSubjectCourseSchema = z.object({
  courseId: z.string().uuid().nullable(),
});

export const assignSubjectTeachersSchema = z.object({
  teacherIds: z.array(z.string().uuid()).min(1, 'At least one teacher is required'),
});

export const subjectListQuerySchema = listQuerySchema.extend({
  courseId: z.string().uuid().optional(),
});

export type CreateSubjectInput = z.infer<typeof createSubjectSchema>;
export type UpdateSubjectInput = z.infer<typeof updateSubjectSchema>;
export type AssignSubjectCourseInput = z.infer<typeof assignSubjectCourseSchema>;
export type AssignSubjectTeachersInput = z.infer<typeof assignSubjectTeachersSchema>;
