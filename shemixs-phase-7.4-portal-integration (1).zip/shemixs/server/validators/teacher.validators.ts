import { z } from 'zod';
import { listQuerySchema } from '../lib/query';

export const teacherStatusEnum = z.enum(['ACTIVE', 'INACTIVE', 'ON_LEAVE']);

export const createTeacherSchema = z.object({
  fullName: z.string().min(2, 'Full name is required'),
  email: z.string().email('Enter a valid email address'),
  phone: z.string().optional(),
  employeeCode: z.string().optional(),
  designation: z.string().optional(),
  department: z.string().optional(),
  subjectIds: z.array(z.string().uuid()).optional().default([]),
});

export const updateTeacherSchema = z.object({
  fullName: z.string().min(2).optional(),
  phone: z.string().optional(),
  employeeCode: z.string().optional(),
  designation: z.string().optional(),
  department: z.string().optional(),
});

export const updateTeacherStatusSchema = z.object({
  status: teacherStatusEnum,
  reason: z.string().optional(),
});

export const assignTeacherSubjectsSchema = z.object({
  subjectIds: z.array(z.string().uuid()).min(1, 'At least one subject is required'),
});

export const teacherListQuerySchema = listQuerySchema.extend({
  status: teacherStatusEnum.optional(),
  department: z.string().optional(),
});

export type CreateTeacherInput = z.infer<typeof createTeacherSchema>;
export type UpdateTeacherInput = z.infer<typeof updateTeacherSchema>;
export type UpdateTeacherStatusInput = z.infer<typeof updateTeacherStatusSchema>;
export type AssignTeacherSubjectsInput = z.infer<typeof assignTeacherSubjectsSchema>;
export type TeacherListQuery = z.infer<typeof teacherListQuerySchema>;
