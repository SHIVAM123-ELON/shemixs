import { z } from 'zod';

export const attendanceStatusEnum = z.enum(['PRESENT', 'ABSENT', 'LATE', 'HALF_DAY', 'EXCUSED']);

export const markStudentAttendanceSchema = z.object({
  studentId: z.string().uuid(),
  date: z.coerce.date(),
  status: attendanceStatusEnum,
  remarks: z.string().optional(),
});

/** Mark attendance for many students at once — the common classroom workflow. */
export const markBulkStudentAttendanceSchema = z.object({
  date: z.coerce.date(),
  entries: z
    .array(z.object({ studentId: z.string().uuid(), status: attendanceStatusEnum, remarks: z.string().optional() }))
    .min(1, 'At least one attendance entry is required'),
});

export const markTeacherAttendanceSchema = z.object({
  teacherId: z.string().uuid(),
  date: z.coerce.date(),
  status: attendanceStatusEnum,
  remarks: z.string().optional(),
});

export const updateAttendanceSchema = z.object({
  status: attendanceStatusEnum,
  remarks: z.string().optional(),
});

export const attendanceHistoryQuerySchema = z.object({
  dateFrom: z.coerce.date().optional(),
  dateTo: z.coerce.date().optional(),
  status: attendanceStatusEnum.optional(),
});

export type MarkStudentAttendanceInput = z.infer<typeof markStudentAttendanceSchema>;
export type MarkBulkStudentAttendanceInput = z.infer<typeof markBulkStudentAttendanceSchema>;
export type MarkTeacherAttendanceInput = z.infer<typeof markTeacherAttendanceSchema>;
export type UpdateAttendanceInput = z.infer<typeof updateAttendanceSchema>;
export type AttendanceHistoryQuery = z.infer<typeof attendanceHistoryQuerySchema>;
