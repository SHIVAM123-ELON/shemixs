import { z } from 'zod';
import { listQuerySchema } from '../lib/query';

export const homeworkStatusEnum = z.enum(['DRAFT', 'PUBLISHED']);

export const createHomeworkSchema = z.object({
  title: z.string().min(2, 'Title is required'),
  description: z.string().optional(),
  subjectId: z.string().uuid().optional(),
  batchId: z.string().uuid().optional(),
  sectionId: z.string().uuid().optional(),
  teacherId: z.string().uuid().optional(),
  dueDate: z.coerce.date(),
  attachmentUrls: z.array(z.string().url()).optional().default([]),
});

export const updateHomeworkSchema = z.object({
  title: z.string().min(2).optional(),
  description: z.string().optional(),
  subjectId: z.string().uuid().nullable().optional(),
  batchId: z.string().uuid().nullable().optional(),
  sectionId: z.string().uuid().nullable().optional(),
  dueDate: z.coerce.date().optional(),
  attachmentUrls: z.array(z.string().url()).optional(),
});

export const homeworkListQuerySchema = listQuerySchema.extend({
  status: homeworkStatusEnum.optional(),
  subjectId: z.string().uuid().optional(),
  batchId: z.string().uuid().optional(),
  teacherId: z.string().uuid().optional(),
});

export type CreateHomeworkInput = z.infer<typeof createHomeworkSchema>;
export type UpdateHomeworkInput = z.infer<typeof updateHomeworkSchema>;
