import { z } from 'zod';
import { listQuerySchema } from '../lib/query';

export const testTypeEnum = z.enum(['MCQ', 'SUBJECTIVE', 'PRACTICE', 'MOCK']);
export const testModeEnum = z.enum(['ONLINE', 'OFFLINE']);
export const testStatusEnum = z.enum(['DRAFT', 'PUBLISHED']);

export const testQuestionInputSchema = z.object({
  questionText: z.string().min(1, 'Question text is required'),
  options: z.array(z.string()).optional(),
  correctAnswer: z.string().optional(),
  marks: z.coerce.number().int().positive().default(1),
});

export const createTestSchema = z.object({
  title: z.string().min(2, 'Title is required'),
  description: z.string().optional(),
  subjectId: z.string().uuid().optional(),
  batchId: z.string().uuid().optional(),
  teacherId: z.string().uuid().optional(),
  type: testTypeEnum,
  mode: testModeEnum.default('OFFLINE'),
  maxMarks: z.coerce.number().int().positive().default(100),
  durationMinutes: z.coerce.number().int().positive().optional(),
  scheduledAt: z.coerce.date().optional(),
  questions: z.array(testQuestionInputSchema).optional().default([]),
});

export const updateTestSchema = z.object({
  title: z.string().min(2).optional(),
  description: z.string().optional(),
  subjectId: z.string().uuid().nullable().optional(),
  batchId: z.string().uuid().nullable().optional(),
  mode: testModeEnum.optional(),
  maxMarks: z.coerce.number().int().positive().optional(),
  durationMinutes: z.coerce.number().int().positive().nullable().optional(),
  scheduledAt: z.coerce.date().nullable().optional(),
});

export const testListQuerySchema = listQuerySchema.extend({
  status: testStatusEnum.optional(),
  type: testTypeEnum.optional(),
  mode: testModeEnum.optional(),
  subjectId: z.string().uuid().optional(),
  batchId: z.string().uuid().optional(),
});

export type CreateTestInput = z.infer<typeof createTestSchema>;
export type UpdateTestInput = z.infer<typeof updateTestSchema>;
export type TestQuestionInput = z.infer<typeof testQuestionInputSchema>;
