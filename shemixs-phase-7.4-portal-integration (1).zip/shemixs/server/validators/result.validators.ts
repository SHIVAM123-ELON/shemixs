import { z } from 'zod';

export const createResultSchema = z.object({
  testId: z.string().uuid(),
  studentId: z.string().uuid(),
  marksObtained: z.coerce.number().int().min(0).optional(),
  grade: z.string().optional(),
});

export const updateResultSchema = z.object({
  marksObtained: z.coerce.number().int().min(0).optional(),
  grade: z.string().optional(),
});

/** Bulk entry — the common workflow: a teacher enters marks for a whole class at once. */
export const bulkCreateResultsSchema = z.object({
  testId: z.string().uuid(),
  entries: z
    .array(z.object({ studentId: z.string().uuid(), marksObtained: z.coerce.number().int().min(0), grade: z.string().optional() }))
    .min(1, 'At least one result entry is required'),
});

export const resultListQuerySchema = z.object({
  testId: z.string().uuid().optional(),
  studentId: z.string().uuid().optional(),
  status: z.enum(['DRAFT', 'PUBLISHED']).optional(),
});

export type CreateResultInput = z.infer<typeof createResultSchema>;
export type UpdateResultInput = z.infer<typeof updateResultSchema>;
export type BulkCreateResultsInput = z.infer<typeof bulkCreateResultsSchema>;
export type ResultListQuery = z.infer<typeof resultListQuerySchema>;
