import { z } from 'zod';
import { listQuerySchema } from '../lib/query';

export const admissionStatusEnum = z.enum(['PENDING', 'VERIFIED', 'APPROVED', 'REJECTED']);

export const createAdmissionSchema = z.object({
  applicantName: z.string().min(2, 'Applicant name is required'),
  email: z.string().email('Enter a valid email address'),
  phone: z.string().optional(),
  dateOfBirth: z.coerce.date().optional(),
  guardianName: z.string().optional(),
  address: z.string().optional(),
  desiredBatchId: z.string().uuid().optional(),
});

export const updateAdmissionSchema = z.object({
  applicantName: z.string().min(2).optional(),
  phone: z.string().optional(),
  dateOfBirth: z.coerce.date().optional(),
  guardianName: z.string().optional(),
  address: z.string().optional(),
  desiredBatchId: z.string().uuid().nullable().optional(),
});

export const verifyAdmissionSchema = z.object({
  note: z.string().optional(),
});

export const approveAdmissionSchema = z.object({
  note: z.string().optional(),
  // Batch/section to enroll the resulting student into.
  batchId: z.string().uuid().optional(),
  sectionId: z.string().uuid().optional(),
});

export const rejectAdmissionSchema = z.object({
  reason: z.string().min(1, 'A rejection reason is required'),
});

export const admissionListQuerySchema = listQuerySchema.extend({
  status: admissionStatusEnum.optional(),
});

export type CreateAdmissionInput = z.infer<typeof createAdmissionSchema>;
export type UpdateAdmissionInput = z.infer<typeof updateAdmissionSchema>;
export type VerifyAdmissionInput = z.infer<typeof verifyAdmissionSchema>;
export type ApproveAdmissionInput = z.infer<typeof approveAdmissionSchema>;
export type RejectAdmissionInput = z.infer<typeof rejectAdmissionSchema>;
