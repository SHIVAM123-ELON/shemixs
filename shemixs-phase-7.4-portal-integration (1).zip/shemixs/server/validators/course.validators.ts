import { z } from 'zod';
import { listQuerySchema } from '../lib/query';

export const courseStatusEnum = z.enum(['DRAFT', 'PUBLISHED', 'ARCHIVED']);

function slugify(input: string): string {
  return input
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/(^-|-$)/g, '');
}

export const createCourseSchema = z.object({
  title: z.string().min(2, 'Title is required'),
  slug: z.string().optional(),
  description: z.string().optional(),
  category: z.string().optional(),
});

export const updateCourseSchema = z.object({
  title: z.string().min(2).optional(),
  description: z.string().optional(),
  category: z.string().optional(),
});

export const updateCourseStatusSchema = z.object({
  status: courseStatusEnum,
});

export const courseListQuerySchema = listQuerySchema.extend({
  status: courseStatusEnum.optional(),
  category: z.string().optional(),
});

export { slugify };
export type CreateCourseInput = z.infer<typeof createCourseSchema>;
export type UpdateCourseInput = z.infer<typeof updateCourseSchema>;
export type UpdateCourseStatusInput = z.infer<typeof updateCourseStatusSchema>;
