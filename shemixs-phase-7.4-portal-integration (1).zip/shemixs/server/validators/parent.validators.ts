import { z } from 'zod';
import { listQuerySchema } from '../lib/query';

export const createParentSchema = z.object({
  fullName: z.string().min(2, 'Full name is required'),
  email: z.string().email('Enter a valid email address'),
  phone: z.string().optional(),
  occupation: z.string().optional(),
  address: z.string().optional(),
});

export const updateParentSchema = z.object({
  fullName: z.string().min(2).optional(),
  phone: z.string().optional(),
  occupation: z.string().optional(),
  address: z.string().optional(),
});

export const linkStudentSchema = z.object({
  studentId: z.string().uuid('A valid student is required'),
  relationship: z.string().optional(),
});

export const unlinkStudentSchema = z.object({
  studentId: z.string().uuid('A valid student is required'),
});

export const parentListQuerySchema = listQuerySchema;

export type CreateParentInput = z.infer<typeof createParentSchema>;
export type UpdateParentInput = z.infer<typeof updateParentSchema>;
export type LinkStudentInput = z.infer<typeof linkStudentSchema>;
export type UnlinkStudentInput = z.infer<typeof unlinkStudentSchema>;
