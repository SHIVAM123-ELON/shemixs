import { z } from 'zod';
import { listQuerySchema } from '../lib/query';

export const createSectionSchema = z.object({
  name: z.string().min(1, 'Name is required'),
  batchId: z.string().uuid().optional(),
});

export const updateSectionSchema = z.object({
  name: z.string().min(1).optional(),
});

export const assignSectionBatchSchema = z.object({
  batchId: z.string().uuid().nullable(),
});

export const assignSectionStudentsSchema = z.object({
  studentIds: z.array(z.string().uuid()).min(1, 'At least one student is required'),
});

export const sectionListQuerySchema = listQuerySchema.extend({
  batchId: z.string().uuid().optional(),
});

export type CreateSectionInput = z.infer<typeof createSectionSchema>;
export type UpdateSectionInput = z.infer<typeof updateSectionSchema>;
export type AssignSectionBatchInput = z.infer<typeof assignSectionBatchSchema>;
export type AssignSectionStudentsInput = z.infer<typeof assignSectionStudentsSchema>;
