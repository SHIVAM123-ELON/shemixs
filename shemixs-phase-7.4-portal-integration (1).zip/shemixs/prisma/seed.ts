/**
 * Prisma Seed — Roles & Permissions
 *
 * Seeds the system roles required by RBAC and a baseline permission matrix.
 * Idempotent: safe to re-run (uses upsert throughout).
 *
 * Run with: npx prisma db seed
 */
import { PrismaClient, RoleName, PermissionAction } from '@prisma/client';
import bcrypt from 'bcryptjs';

const prisma = new PrismaClient();

const ROLES: { name: RoleName; label: string; description: string }[] = [
  { name: 'SUPER_ADMIN', label: 'Super Admin', description: 'Full unrestricted system access.' },
  { name: 'ADMIN', label: 'Admin', description: 'School-level administrative access.' },
  { name: 'PRINCIPAL', label: 'Principal', description: 'Oversight of academics and staff.' },
  { name: 'COORDINATOR', label: 'Coordinator', description: 'Manages academic coordination.' },
  { name: 'TEACHER', label: 'Teacher', description: 'Manages classes, tests, and students.' },
  { name: 'STUDENT', label: 'Student', description: 'Access to own academic records.' },
  { name: 'PARENT', label: 'Parent', description: "Access to ward's academic records." },
  { name: 'ACCOUNTANT', label: 'Accountant', description: 'Manages fees and payments.' },
  { name: 'RECEPTIONIST', label: 'Receptionist', description: 'Front-desk and admissions support.' },
];

// Resources map to future business modules; kept minimal for this phase.
const RESOURCES = [
  'users',
  'roles',
  'students',
  'teachers',
  'parents',
  'admissions',
  'attendance',
  'results',
  'fees',
  'timetable',
  'reports',
] as const;

const ALL_ACTIONS: PermissionAction[] = [
  'CREATE',
  'READ',
  'UPDATE',
  'DELETE',
  'EXPORT',
  'IMPORT',
  'PUBLISH',
  'APPROVE',
  'ASSIGN',
  'MANAGE',
];

async function seedRoles() {
  const roles = await Promise.all(
    ROLES.map((r) =>
      prisma.role.upsert({
        where: { name: r.name },
        update: { label: r.label, description: r.description },
        create: r,
      })
    )
  );
  return roles;
}

async function seedPermissions() {
  const permissions = [];
  for (const resource of RESOURCES) {
    for (const action of ALL_ACTIONS) {
      const permission = await prisma.permission.upsert({
        where: { action_resource: { action, resource } },
        update: {},
        create: { action, resource },
      });
      permissions.push(permission);
    }
  }
  return permissions;
}

async function assignSuperAdminPermissions(
  roles: Awaited<ReturnType<typeof seedRoles>>,
  permissions: Awaited<ReturnType<typeof seedPermissions>>
) {
  const superAdmin = roles.find((r) => r.name === 'SUPER_ADMIN');
  if (!superAdmin) return;

  await Promise.all(
    permissions.map((p) =>
      prisma.rolePermission.upsert({
        where: { roleId_permissionId: { roleId: superAdmin.id, permissionId: p.id } },
        update: {},
        create: { roleId: superAdmin.id, permissionId: p.id },
      })
    )
  );
}

async function seedSuperAdminUser(roles: Awaited<ReturnType<typeof seedRoles>>) {
  const superAdminRole = roles.find((r) => r.name === 'SUPER_ADMIN');
  if (!superAdminRole) return;

  const email = process.env.SEED_SUPER_ADMIN_EMAIL ?? 'superadmin@shemixs.com';
  const password = process.env.SEED_SUPER_ADMIN_PASSWORD ?? 'ChangeMe123!';
  const passwordHash = await bcrypt.hash(password, 12);

  await prisma.user.upsert({
    where: { email },
    update: {},
    create: {
      fullName: 'Shemixs Super Admin',
      email,
      passwordHash,
      status: 'ACTIVE',
      emailVerified: true,
      roleId: superAdminRole.id,
    },
  });

  console.log(`Seeded super admin user: ${email} (password set from SEED_SUPER_ADMIN_PASSWORD env or default — change immediately).`);
}

async function main() {
  console.log('Seeding roles...');
  const roles = await seedRoles();

  console.log('Seeding permissions...');
  const permissions = await seedPermissions();

  console.log('Assigning permissions to Super Admin...');
  await assignSuperAdminPermissions(roles, permissions);

  console.log('Seeding bootstrap super admin user...');
  await seedSuperAdminUser(roles);

  console.log('Seed complete.');
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
