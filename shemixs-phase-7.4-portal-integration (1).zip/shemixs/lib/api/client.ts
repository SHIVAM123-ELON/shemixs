/**
 * API Client
 *
 * The one place that calls `fetch` against our own `/api/**` routes.
 * Handles: credentials (cookies), the `{ success, data, error }`
 * envelope every backend route returns (Phase 7.1–7.3), 401 → one
 * automatic silent refresh-and-retry, and throwing a typed `ApiError`
 * on failure so callers can branch on `.status`/`.code` instead of
 * parsing response bodies themselves.
 *
 * Nothing in the app should call `fetch('/api/...')` directly —
 * always go through `apiClient.get/post/put/patch/delete`.
 */
import { ApiError } from './error';

interface ApiEnvelopeSuccess<T> {
  success: true;
  data: T;
  message?: string;
  meta?: Record<string, unknown>;
}

interface ApiEnvelopeError {
  success: false;
  error: { message: string; code: string; details?: unknown };
}

type ApiEnvelope<T> = ApiEnvelopeSuccess<T> | ApiEnvelopeError;

export interface ApiResult<T> {
  data: T;
  meta?: Record<string, unknown>;
  message?: string;
}

let refreshInFlight: Promise<boolean> | null = null;

/** Calls /api/auth/refresh once, de-duped across concurrent 401s so a burst of failing requests doesn't fire N refresh calls. */
async function refreshSession(): Promise<boolean> {
  if (!refreshInFlight) {
    refreshInFlight = fetch('/api/auth/refresh', { method: 'POST', credentials: 'include' })
      .then((res) => res.ok)
      .finally(() => {
        refreshInFlight = null;
      });
  }
  return refreshInFlight;
}

async function request<T>(path: string, options: RequestInit, isRetry = false): Promise<ApiResult<T>> {
  const res = await fetch(path, {
    ...options,
    credentials: 'include',
    headers: {
      ...(options.body && !(options.body instanceof FormData) ? { 'Content-Type': 'application/json' } : {}),
      ...options.headers,
    },
  });

  // Refresh-and-retry exactly once — avoids an infinite loop if the
  // refresh token itself has expired (that retry will also 401 and
  // fall through to throwing below, which callers treat as "logged out").
  if (res.status === 401 && !isRetry && path !== '/api/auth/refresh') {
    const refreshed = await refreshSession();
    if (refreshed) return request<T>(path, options, true);
  }

  let body: ApiEnvelope<T>;
  try {
    body = await res.json();
  } catch {
    throw new ApiError('Unexpected server response', res.status, 'INVALID_RESPONSE');
  }

  if (!body.success) {
    throw new ApiError(body.error.message, res.status, body.error.code, body.error.details);
  }

  return { data: body.data, meta: body.meta, message: body.message };
}

function buildQueryString(params?: Record<string, unknown>): string {
  if (!params) return '';
  const search = new URLSearchParams();
  for (const [key, value] of Object.entries(params)) {
    if (value === undefined || value === null || value === '') continue;
    search.set(key, String(value));
  }
  const qs = search.toString();
  return qs ? `?${qs}` : '';
}

export const apiClient = {
  get<T>(path: string, params?: Record<string, unknown>) {
    return request<T>(`${path}${buildQueryString(params)}`, { method: 'GET' });
  },
  post<T>(path: string, body?: unknown) {
    return request<T>(path, { method: 'POST', body: body instanceof FormData ? body : JSON.stringify(body ?? {}) });
  },
  put<T>(path: string, body?: unknown) {
    return request<T>(path, { method: 'PUT', body: body instanceof FormData ? body : JSON.stringify(body ?? {}) });
  },
  patch<T>(path: string, body?: unknown) {
    return request<T>(path, { method: 'PATCH', body: body instanceof FormData ? body : JSON.stringify(body ?? {}) });
  },
  delete<T>(path: string, body?: unknown) {
    return request<T>(path, { method: 'DELETE', ...(body ? { body: JSON.stringify(body) } : {}) });
  },
};
