'use client';

import { useApiQuery } from './use-api-query';

export interface FeeDto {
  id: string;
  title: string;
  description: string | null;
  amount: number; // paise
  dueDate: string | null;
  status: 'PENDING' | 'PARTIALLY_PAID' | 'PAID' | 'OVERDUE' | 'WAIVED';
  createdAt: string;
}

/** A student's own fees — GET /api/students/[id]/fees. Pass `null` for studentId to skip until it's known (e.g. resolved from useAuth). */
export function useStudentFees(studentId: string | null) {
  return useApiQuery<FeeDto[]>(studentId ? `/api/students/${studentId}/fees` : null);
}
