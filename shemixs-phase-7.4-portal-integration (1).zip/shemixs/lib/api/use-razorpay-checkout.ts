'use client';

/**
 * useRazorpayCheckout
 *
 * Wraps the full pay flow: POST /api/payments/create-order → open
 * Razorpay's checkout.js widget → on success, POST /api/payments/verify
 * (server-side signature check — the client's "success" callback is
 * NEVER trusted as payment confirmation on its own, per the backend's
 * verify flow). The widget script is loaded once, lazily, on first use.
 */
import { useCallback, useState } from 'react';
import { apiClient } from './client';
import { getErrorMessage } from './error';

declare global {
  interface Window {
    Razorpay: new (options: Record<string, unknown>) => { open: () => void };
  }
}

let scriptLoadPromise: Promise<void> | null = null;

function loadRazorpayScript(): Promise<void> {
  if (window.Razorpay) return Promise.resolve();
  if (!scriptLoadPromise) {
    scriptLoadPromise = new Promise((resolve, reject) => {
      const script = document.createElement('script');
      script.src = 'https://checkout.razorpay.com/v1/checkout.js';
      script.onload = () => resolve();
      script.onerror = () => reject(new Error('Failed to load Razorpay checkout script'));
      document.body.appendChild(script);
    });
  }
  return scriptLoadPromise;
}

interface CreateOrderResponse {
  razorpayOrderId: string;
  razorpayKeyId: string;
  amount: number;
  currency: string;
}

interface UseRazorpayCheckoutOptions {
  studentName: string;
  studentEmail: string;
  onSuccess?: () => void;
}

export function useRazorpayCheckout({ studentName, studentEmail, onSuccess }: UseRazorpayCheckoutOptions) {
  const [isProcessing, setIsProcessing] = useState(false);
  const [error, setError] = useState<string>();

  const payFee = useCallback(
    async (feeId: string) => {
      setIsProcessing(true);
      setError(undefined);
      try {
        await loadRazorpayScript();

        const order = await apiClient.post<CreateOrderResponse>('/api/payments/create-order', { feeId });

        await new Promise<void>((resolve, reject) => {
          const razorpay = new window.Razorpay({
            key: order.data.razorpayKeyId,
            amount: order.data.amount,
            currency: order.data.currency,
            order_id: order.data.razorpayOrderId,
            name: 'Shemixs',
            description: 'Fee Payment',
            prefill: { name: studentName, email: studentEmail },
            handler: async (response: { razorpay_order_id: string; razorpay_payment_id: string; razorpay_signature: string }) => {
              try {
                await apiClient.post('/api/payments/verify', {
                  razorpayOrderId: response.razorpay_order_id,
                  razorpayPaymentId: response.razorpay_payment_id,
                  razorpaySignature: response.razorpay_signature,
                });
                resolve();
              } catch (err) {
                reject(err);
              }
            },
            modal: { ondismiss: () => reject(new Error('Payment cancelled')) },
          });
          razorpay.open();
        });

        onSuccess?.();
      } catch (err) {
        setError(getErrorMessage(err));
      } finally {
        setIsProcessing(false);
      }
    },
    [studentName, studentEmail, onSuccess]
  );

  return { payFee, isProcessing, error };
}
