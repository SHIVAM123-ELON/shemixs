'use client';

/**
 * Generic Query Hook
 *
 * No react-query/SWR dependency exists in this project yet, and
 * pulling one in for this phase would be exactly the "unnecessary
 * dependency" the spec warns against — this is a minimal, dependency-
 * free stand-in covering what every portal page actually needs:
 * loading/error/data/refetch. Every `use<Resource>()` hook
 * (`useStudents`, `useFees`, ...) is a thin wrapper around this.
 */
import { useCallback, useEffect, useRef, useState } from 'react';
import { apiClient, type ApiResult } from './client';
import { getErrorMessage } from './error';

export type QueryState<T> =
  | { status: 'loading'; data?: undefined; error?: undefined }
  | { status: 'error'; data?: undefined; error: string }
  | { status: 'success'; data: T; error?: undefined };

export interface UseApiQueryResult<T> {
  data: T | undefined;
  meta: Record<string, unknown> | undefined;
  status: 'loading' | 'error' | 'success';
  error: string | undefined;
  refetch: () => void;
}

/**
 * `path` may be `null` to conditionally skip fetching (e.g. waiting
 * on an id from a parent query) — mirrors the common
 * react-query "enabled" pattern without needing that option name.
 */
export function useApiQuery<T>(path: string | null, params?: Record<string, unknown>): UseApiQueryResult<T> {
  const [state, setState] = useState<QueryState<T>>({ status: 'loading' });
  const [meta, setMeta] = useState<Record<string, unknown>>();
  const [refetchToken, setRefetchToken] = useState(0);
  const paramsKey = params ? JSON.stringify(params) : '';

  const requestIdRef = useRef(0);

  useEffect(() => {
    if (!path) return;

    const requestId = ++requestIdRef.current;
    setState((prev) => (prev.status === 'success' ? prev : { status: 'loading' }));

    apiClient
      .get<T>(path, params)
      .then((result: ApiResult<T>) => {
        if (requestIdRef.current !== requestId) return; // a newer request superseded this one
        setState({ status: 'success', data: result.data });
        setMeta(result.meta);
      })
      .catch((err) => {
        if (requestIdRef.current !== requestId) return;
        setState({ status: 'error', error: getErrorMessage(err) });
      });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [path, paramsKey, refetchToken]);

  const refetch = useCallback(() => setRefetchToken((t) => t + 1), []);

  return { data: state.data, meta, status: path ? state.status : 'loading', error: state.error, refetch };
}
