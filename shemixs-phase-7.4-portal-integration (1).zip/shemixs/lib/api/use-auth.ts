'use client';

/**
 * useAuth
 *
 * The single hook every portal header/sidebar/profile page uses for
 * "who is logged in". Wraps GET /api/auth/me (Phase 7.1) — cookie-based,
 * so no token is ever handled in JS. `logout()` calls the real
 * /api/auth/logout route (revokes the session server-side) and only
 * then navigates, so a stale session can never be reused by hitting back.
 */
import { useCallback, useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { apiClient } from './client';

export interface AuthUser {
  id: string;
  fullName: string;
  email: string;
  avatar: string | null;
  status: string;
  role: string;
  emailVerified: boolean;
}

interface UseAuthResult {
  user: AuthUser | undefined;
  status: 'loading' | 'authenticated' | 'unauthenticated';
  logout: () => Promise<void>;
  refetch: () => void;
}

export function useAuth(): UseAuthResult {
  const router = useRouter();
  const [user, setUser] = useState<AuthUser>();
  const [status, setStatus] = useState<'loading' | 'authenticated' | 'unauthenticated'>('loading');
  const [token, setToken] = useState(0);

  useEffect(() => {
    let cancelled = false;
    setStatus('loading');

    apiClient
      .get<{ user: AuthUser }>('/api/auth/me')
      .then((res) => {
        if (cancelled) return;
        setUser(res.data.user);
        setStatus('authenticated');
      })
      .catch(() => {
        if (cancelled) return;
        setUser(undefined);
        setStatus('unauthenticated');
      });

    return () => {
      cancelled = true;
    };
  }, [token]);

  const logout = useCallback(async () => {
    await apiClient.post('/api/auth/logout').catch(() => {
      // Even if the server call fails, proceed with client-side
      // redirect — cookies will have expired eventually regardless,
      // and we don't want a network blip to trap the user on the page.
    });
    setUser(undefined);
    setStatus('unauthenticated');
    router.push('/login');
  }, [router]);

  const refetch = useCallback(() => setToken((t) => t + 1), []);

  return { user, status, logout, refetch };
}

/** Maps a role to its portal home — same logic as middleware.ts's PORTAL_ROLE_MAP, kept in sync manually since one is Edge-runtime-only and the other is a client hook. */
export function portalHomeForRole(role: string): string {
  if (['SUPER_ADMIN', 'ADMIN', 'PRINCIPAL', 'COORDINATOR'].includes(role)) return '/portal/admin';
  if (role === 'TEACHER') return '/portal/teacher';
  if (role === 'STUDENT') return '/portal/student';
  if (role === 'PARENT') return '/portal/parent';
  return '/login';
}
