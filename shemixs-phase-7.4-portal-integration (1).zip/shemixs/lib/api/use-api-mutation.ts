'use client';

/** Generic mutation hook — the write-side counterpart to useApiQuery. */
import { useCallback, useState } from 'react';
import { apiClient } from './client';
import { getErrorMessage } from './error';

type Method = 'post' | 'put' | 'patch' | 'delete';

export interface UseApiMutationResult<TInput, TOutput> {
  mutate: (input: TInput) => Promise<TOutput | undefined>;
  isLoading: boolean;
  error: string | undefined;
}

export function useApiMutation<TInput = unknown, TOutput = unknown>(
  method: Method,
  path: string | ((input: TInput) => string)
): UseApiMutationResult<TInput, TOutput> {
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string>();

  const mutate = useCallback(
    async (input: TInput) => {
      setIsLoading(true);
      setError(undefined);
      const resolvedPath = typeof path === 'function' ? path(input) : path;
      try {
        const result = await apiClient[method]<TOutput>(resolvedPath, input);
        return result.data;
      } catch (err) {
        setError(getErrorMessage(err));
        return undefined;
      } finally {
        setIsLoading(false);
      }
    },
    [method, path]
  );

  return { mutate, isLoading, error };
}
