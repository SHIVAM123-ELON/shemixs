'use client';

import { useApiQuery } from './use-api-query';

export interface BatchDto {
  id: string;
  name: string;
  status: string;
}

export function useBatches() {
  return useApiQuery<BatchDto[]>('/api/batches', { pageSize: 100 });
}

export interface StudentInBatchDto {
  id: string;
  user: { fullName: string; avatar: string | null };
}

export function useStudentsInBatch(batchId: string | null) {
  return useApiQuery<StudentInBatchDto[]>(batchId ? '/api/students' : null, { batchId: batchId ?? undefined, pageSize: 100 });
}
