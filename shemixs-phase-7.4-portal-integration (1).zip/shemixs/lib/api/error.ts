export class ApiError extends Error {
  readonly status: number;
  readonly code: string;
  readonly details?: unknown;

  constructor(message: string, status: number, code: string, details?: unknown) {
    super(message);
    this.name = 'ApiError';
    this.status = status;
    this.code = code;
    this.details = details;
  }
}

/**
 * Converts any thrown error into a short, user-safe message — never
 * surfaces stack traces, raw fetch errors, or backend internals (the
 * backend's own `handleApiError` already sanitizes 500s, but this is
 * the frontend's last line of defense for network-level failures
 * that never reached a JSON envelope at all).
 */
export function getErrorMessage(error: unknown): string {
  if (error instanceof ApiError) {
    if (error.status === 401) return 'Your session has expired. Please log in again.';
    if (error.status === 403) return "You don't have permission to do that.";
    if (error.status === 404) return 'Not found.';
    if (error.status === 429) return 'Too many requests — please wait a moment and try again.';
    return error.message || 'Something went wrong.';
  }
  if (error instanceof TypeError) {
    return 'Network error — check your connection and try again.';
  }
  return 'Something went wrong. Please try again.';
}
