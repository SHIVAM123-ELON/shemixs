'use client';

import { useApiQuery } from './use-api-query';

export interface StudentListItemDto {
  id: string;
  admissionNo: string | null;
  status: 'ACTIVE' | 'INACTIVE' | 'ALUMNI' | 'SUSPENDED' | 'ENROLLMENT_PENDING';
  user: { id: string; fullName: string; email: string; avatar: string | null };
  batch: { id: string; name: string } | null;
  section: { id: string; name: string } | null;
}

export interface PaginationMeta {
  page: number;
  pageSize: number;
  totalItems: number;
  totalPages: number;
  hasNextPage: boolean;
  hasPreviousPage: boolean;
}

export interface StudentsQuery {
  search?: string;
  status?: string;
  page?: number;
  pageSize?: number;
}

export function useStudents(query: StudentsQuery) {
  const result = useApiQuery<StudentListItemDto[]>('/api/students', {
    search: query.search || undefined,
    status: query.status && query.status !== 'all' ? query.status : undefined,
    page: query.page ?? 1,
    pageSize: query.pageSize ?? 8,
  });

  return { ...result, pagination: result.meta?.pagination as PaginationMeta | undefined };
}
