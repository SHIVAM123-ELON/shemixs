/**
 * Route Middleware — Authentication & RBAC
 *
 * Runs on the Edge Runtime for every request matched below. Protects
 * /portal/** routes: unauthenticated visitors are redirected to
 * /login, and authenticated users whose role doesn't match the portal
 * they're trying to reach are redirected to their own portal home.
 *
 * This is coarse, route-level protection only. Per-action authorization
 * (can this teacher publish results?) is enforced separately at the
 * API layer via permissions, not here.
 */
import { NextResponse, type NextRequest } from 'next/server';
import { verifyAccessToken } from '@/server/auth/jwt';
import { ACCESS_TOKEN_COOKIE } from '@/server/auth/cookies';
import { PORTAL_ROLE_MAP } from '@/server/constants/roles';

function portalHomeForRole(role: string): string {
  const segment = Object.entries(PORTAL_ROLE_MAP).find(([, roles]) => roles.includes(role as never))?.[0];
  return segment ? `/portal/${segment}` : '/login';
}

export async function middleware(req: NextRequest) {
  const { pathname } = req.nextUrl;

  const portalMatch = pathname.match(/^\/portal\/([^/]+)/);
  if (!portalMatch) return NextResponse.next();

  const portalSegment = portalMatch[1];
  const token = req.cookies.get(ACCESS_TOKEN_COOKIE)?.value;

  if (!token) {
    const loginUrl = new URL('/login', req.url);
    loginUrl.searchParams.set('redirect', pathname);
    return NextResponse.redirect(loginUrl);
  }

  try {
    const payload = await verifyAccessToken(token);
    const allowedRoles = PORTAL_ROLE_MAP[portalSegment];

    if (allowedRoles && !allowedRoles.includes(payload.role as never)) {
      return NextResponse.redirect(new URL(portalHomeForRole(payload.role), req.url));
    }

    return NextResponse.next();
  } catch {
    const loginUrl = new URL('/login', req.url);
    loginUrl.searchParams.set('redirect', pathname);
    const res = NextResponse.redirect(loginUrl);
    res.cookies.set(ACCESS_TOKEN_COOKIE, '', { maxAge: 0, path: '/' });
    return res;
  }
}

export const config = {
  matcher: ['/portal/:path*'],
};
