'use client';

import * as Icons from 'lucide-react';
import { PageHeader } from '@/components/portal/shared/page-header';
import { StatCard } from '@/components/portal/shared/stat-card';
import { StatusBadge } from '@/components/portal/shared/status-badge';
import { SkeletonCard } from '@/components/portal/shared/skeletons';
import { EmptyState } from '@/components/portal/shared/empty-state';
import { ErrorState } from '@/components/portal/shared/error-state';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import { useAuth } from '@/lib/api/use-auth';
import { useApiQuery } from '@/lib/api/use-api-query';
import { useStudentFees, type FeeDto } from '@/lib/api/use-fees';
import { useRazorpayCheckout } from '@/lib/api/use-razorpay-checkout';

interface StudentSelfDto {
  id: string;
}

const statusVariant = {
  PAID: 'success',
  PENDING: 'warning',
  PARTIALLY_PAID: 'warning',
  OVERDUE: 'destructive',
  WAIVED: 'muted',
} as const;

function formatCurrency(paise: number) {
  return new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 }).format(paise / 100);
}

function formatDate(dateStr: string | null) {
  if (!dateStr) return '—';
  return new Date(dateStr).toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
}

export default function FeesPage() {
  const { user } = useAuth();
  // Fee/Payment rows are keyed by Student.id, not User.id — resolve
  // the logged-in student's own Student row first (see /api/students/me).
  const { data: self } = useApiQuery<StudentSelfDto>(user ? '/api/students/me' : null);
  const { data: fees, status, error, refetch } = useStudentFees(self?.id ?? null);

  const { payFee, isProcessing } = useRazorpayCheckout({
    studentName: user?.fullName ?? '',
    studentEmail: user?.email ?? '',
    onSuccess: refetch,
  });

  const totalPaid = (fees ?? []).filter((f) => f.status === 'PAID').reduce((sum, f) => sum + f.amount, 0);
  const totalPending = (fees ?? []).filter((f) => f.status === 'PENDING' || f.status === 'PARTIALLY_PAID').reduce((sum, f) => sum + f.amount, 0);
  const totalOverdue = (fees ?? []).filter((f) => f.status === 'OVERDUE').reduce((sum, f) => sum + f.amount, 0);
  const nextDue = (fees ?? [])
    .filter((f) => f.status !== 'PAID' && f.status !== 'WAIVED' && f.dueDate)
    .sort((a, b) => new Date(a.dueDate as string).getTime() - new Date(b.dueDate as string).getTime())[0];

  return (
    <>
      <PageHeader title="Fee Status" description="View and manage your fee payments." />

      {status === 'loading' && (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {Array.from({ length: 4 }).map((_, i) => <SkeletonCard key={i} />)}
        </div>
      )}

      {status === 'error' && <ErrorState description={error} onRetry={refetch} />}

      {status === 'success' && (
        <>
          <div className="mb-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            <StatCard label="Total Paid" value={formatCurrency(totalPaid)} icon="CheckCircle2" accent="success" />
            <StatCard label="Pending" value={formatCurrency(totalPending)} icon="Clock" accent="warning" />
            <StatCard label="Overdue" value={formatCurrency(totalOverdue)} icon="AlertCircle" accent="destructive" />
            <StatCard label="Next Due Date" value={nextDue ? formatDate(nextDue.dueDate) : '—'} icon="CalendarDays" accent="primary" />
          </div>

          {!fees || fees.length === 0 ? (
            <EmptyState icon="Receipt" title="No fees on record" description="You don't have any fee line items yet." />
          ) : (
            <div className="space-y-4">
              {fees.map((fee: FeeDto) => (
                <div key={fee.id} className="overflow-hidden rounded-xl border border-border bg-card">
                  <div className="flex flex-col gap-4 p-4 sm:flex-row sm:items-center sm:justify-between">
                    <div className="flex items-center gap-4">
                      <div
                        className={cn(
                          'flex h-12 w-12 shrink-0 items-center justify-center rounded-lg',
                          fee.status === 'PAID' ? 'bg-success/10 text-success' : fee.status === 'OVERDUE' ? 'bg-destructive/10 text-destructive' : 'bg-warning/10 text-warning'
                        )}
                      >
                        <Icons.CreditCard className="h-6 w-6" />
                      </div>
                      <div>
                        <h3 className="text-sm font-semibold text-foreground">{fee.title}</h3>
                        {fee.description && <p className="mt-0.5 text-xs text-muted-foreground">{fee.description}</p>}
                        <div className="mt-1 flex items-center gap-3 text-xs">
                          <span className="text-lg font-bold text-foreground">{formatCurrency(fee.amount)}</span>
                          <span className="text-muted-foreground">Due {formatDate(fee.dueDate)}</span>
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <StatusBadge status={fee.status.replace('_', ' ').toLowerCase()} variant={statusVariant[fee.status]} />
                      {fee.status === 'PAID' ? (
                        <Button size="sm" variant="outline" disabled>
                          <Icons.Download className="mr-2 h-3.5 w-3.5" />
                          Receipt
                        </Button>
                      ) : (
                        <Button size="sm" disabled={isProcessing} onClick={() => payFee(fee.id)}>
                          <Icons.CreditCard className="mr-2 h-3.5 w-3.5" />
                          {isProcessing ? 'Processing…' : 'Pay Now'}
                        </Button>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </>
      )}
    </>
  );
}
