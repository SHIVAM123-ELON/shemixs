'use client';

import { useEffect, useState } from 'react';
import * as Icons from 'lucide-react';
import { PageHeader } from '@/components/portal/shared/page-header';
import { StatCard } from '@/components/portal/shared/stat-card';
import { StatusBadge } from '@/components/portal/shared/status-badge';
import { EmptyState } from '@/components/portal/shared/empty-state';
import { ErrorState } from '@/components/portal/shared/error-state';
import { SkeletonRow } from '@/components/portal/shared/skeletons';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useStudents } from '@/lib/api/use-students';

const statusVariant = {
  ACTIVE: 'success',
  INACTIVE: 'muted',
  ALUMNI: 'info',
  SUSPENDED: 'destructive',
  ENROLLMENT_PENDING: 'warning',
} as const;

const filters = ['all', 'ACTIVE', 'INACTIVE', 'SUSPENDED', 'ENROLLMENT_PENDING'] as const;
const PAGE_SIZE = 8;

function initials(name: string) {
  return name.split(' ').map((n) => n[0]).join('').slice(0, 2).toUpperCase();
}

export default function AdminStudentsPage() {
  const [searchInput, setSearchInput] = useState('');
  const [search, setSearch] = useState(''); // debounced value actually sent to the API
  const [filter, setFilter] = useState<(typeof filters)[number]>('all');
  const [page, setPage] = useState(1);

  // Debounce search — server-side filtering means every keystroke
  // would otherwise fire a request; 350ms matches typical typing pauses.
  useEffect(() => {
    const timer = setTimeout(() => {
      setSearch(searchInput);
      setPage(1);
    }, 350);
    return () => clearTimeout(timer);
  }, [searchInput]);

  const { data: students, status, error, refetch, pagination } = useStudents({ search, status: filter, page, pageSize: PAGE_SIZE });

  return (
    <>
      <PageHeader title="Student Management" description="Manage all students across the institution.">
        <Button size="sm" variant="outline">
          <Icons.Download className="mr-2 h-4 w-4" />
          Export
        </Button>
        <Button size="sm">
          <Icons.UserPlus className="mr-2 h-4 w-4" />
          Add Student
        </Button>
      </PageHeader>

      <div className="mb-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard label="Total (this page)" value={pagination?.totalItems ?? '—'} icon="GraduationCap" accent="primary" />
        <StatCard label="Page" value={pagination ? `${pagination.page} / ${pagination.totalPages}` : '—'} icon="ListOrdered" accent="secondary" />
        <StatCard label="Showing" value={students?.length ?? 0} icon="Rows3" accent="accent" />
        <StatCard label="Filter" value={filter === 'all' ? 'All statuses' : filter.replace('_', ' ')} icon="Filter" accent="warning" />
      </div>

      <div className="mb-6 flex flex-col gap-3 sm:flex-row sm:items-center">
        <div className="relative flex-1 sm:max-w-xs">
          <Icons.Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            type="search"
            placeholder="Search by name, email, or admission no..."
            value={searchInput}
            onChange={(e) => setSearchInput(e.target.value)}
            className="pl-9"
            aria-label="Search students"
          />
        </div>
        <Select value={filter} onValueChange={(v) => { setFilter(v as typeof filter); setPage(1); }}>
          <SelectTrigger className="sm:w-52"><SelectValue placeholder="Filter by status" /></SelectTrigger>
          <SelectContent>
            {filters.map((f) => (
              <SelectItem key={f} value={f} className="capitalize">
                {f === 'all' ? 'All Students' : f.replace('_', ' ')}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {status === 'error' && <ErrorState description={error} onRetry={refetch} />}

      {status !== 'error' && (
        <div className="overflow-x-auto rounded-xl border border-border">
          <table className="w-full text-sm">
            <thead className="border-b border-border bg-muted/30">
              <tr>
                <th className="px-4 py-3 text-left font-semibold text-muted-foreground">Student</th>
                <th className="hidden px-4 py-3 text-left font-semibold text-muted-foreground sm:table-cell">Batch</th>
                <th className="hidden px-4 py-3 text-left font-semibold text-muted-foreground lg:table-cell">Section</th>
                <th className="hidden px-4 py-3 text-left font-semibold text-muted-foreground md:table-cell">Admission No.</th>
                <th className="px-4 py-3 text-center font-semibold text-muted-foreground">Status</th>
                <th className="px-4 py-3 text-right font-semibold text-muted-foreground">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {status === 'loading' &&
                Array.from({ length: PAGE_SIZE }).map((_, i) => (
                  <tr key={i}><td colSpan={6}><SkeletonRow className="px-4" /></td></tr>
                ))}

              {status === 'success' && students?.length === 0 && (
                <tr>
                  <td colSpan={6}>
                    <EmptyState icon="GraduationCap" title="No students found" description="No students match your search or filter." />
                  </td>
                </tr>
              )}

              {status === 'success' &&
                students?.map((student) => (
                  <tr key={student.id} className="transition-colors hover:bg-muted/20">
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-3">
                        <Avatar className="h-9 w-9 shrink-0">
                          <AvatarImage src={student.user.avatar ?? undefined} alt={student.user.fullName} />
                          <AvatarFallback>{initials(student.user.fullName)}</AvatarFallback>
                        </Avatar>
                        <div className="min-w-0">
                          <p className="truncate font-medium text-foreground">{student.user.fullName}</p>
                          <p className="text-xs text-muted-foreground">{student.user.email}</p>
                        </div>
                      </div>
                    </td>
                    <td className="hidden px-4 py-3 sm:table-cell text-foreground">{student.batch?.name ?? '—'}</td>
                    <td className="hidden px-4 py-3 lg:table-cell text-muted-foreground">{student.section?.name ?? '—'}</td>
                    <td className="hidden px-4 py-3 md:table-cell text-muted-foreground">{student.admissionNo ?? '—'}</td>
                    <td className="px-4 py-3 text-center">
                      <StatusBadge status={student.status.replace('_', ' ').toLowerCase()} variant={statusVariant[student.status]} />
                    </td>
                    <td className="px-4 py-3 text-right">
                      <Button size="sm" variant="ghost">
                        <Icons.Eye className="h-4 w-4" />
                      </Button>
                    </td>
                  </tr>
                ))}
            </tbody>
          </table>
        </div>
      )}

      {pagination && pagination.totalPages > 1 && (
        <div className="mt-6 flex items-center justify-center gap-2">
          <Button variant="outline" size="sm" onClick={() => setPage((p) => Math.max(1, p - 1))} disabled={!pagination.hasPreviousPage}>
            <Icons.ChevronLeft className="h-4 w-4" /> Previous
          </Button>
          <span className="text-sm text-muted-foreground">Page {pagination.page} of {pagination.totalPages}</span>
          <Button variant="outline" size="sm" onClick={() => setPage((p) => p + 1)} disabled={!pagination.hasNextPage}>
            Next <Icons.ChevronRight className="h-4 w-4" />
          </Button>
        </div>
      )}
    </>
  );
}
