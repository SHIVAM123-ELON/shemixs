'use client';

import * as Icons from 'lucide-react';
import { PageHeader } from '@/components/portal/shared/page-header';
import { StatCard } from '@/components/portal/shared/stat-card';
import { StatusBadge } from '@/components/portal/shared/status-badge';
import { SkeletonCard } from '@/components/portal/shared/skeletons';
import { EmptyState } from '@/components/portal/shared/empty-state';
import { ErrorState } from '@/components/portal/shared/error-state';
import { cn } from '@/lib/utils';
import { useApiQuery } from '@/lib/api/use-api-query';
import { useStudentFees, type FeeDto } from '@/lib/api/use-fees';

interface ParentSelfDto {
  id: string;
  studentLinks: { student: { id: string; user: { fullName: string } } }[];
}

const statusVariant = {
  PAID: 'success',
  PENDING: 'warning',
  PARTIALLY_PAID: 'warning',
  OVERDUE: 'destructive',
  WAIVED: 'muted',
} as const;

function formatCurrency(paise: number) {
  return new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 }).format(paise / 100);
}

function formatDate(dateStr: string | null) {
  if (!dateStr) return '—';
  return new Date(dateStr).toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
}

export default function ParentFeesPage() {
  const { data: self, status: selfStatus, error: selfError, refetch: refetchSelf } = useApiQuery<ParentSelfDto>('/api/parents/me');
  // A parent portal always has exactly one linked child in this
  // dataset's scope — a multi-child selector is a natural frontend
  // addition once a school has that scenario, but the backend
  // (/api/parents/me → studentLinks[]) already returns all of them.
  const child = self?.studentLinks[0]?.student;

  const { data: fees, status, error, refetch } = useStudentFees(child?.id ?? null);

  if (selfStatus === 'error') return <ErrorState description={selfError} onRetry={refetchSelf} />;

  const totalPaid = (fees ?? []).filter((f) => f.status === 'PAID').reduce((sum, f) => sum + f.amount, 0);
  const totalPending = (fees ?? []).filter((f) => f.status === 'PENDING' || f.status === 'PARTIALLY_PAID').reduce((sum, f) => sum + f.amount, 0);
  const totalOverdue = (fees ?? []).filter((f) => f.status === 'OVERDUE').reduce((sum, f) => sum + f.amount, 0);
  const total = totalPaid + totalPending + totalOverdue;

  return (
    <>
      <PageHeader
        title="Fee Status"
        description={child ? `Viewing fees for ${child.user.fullName}.` : "View and manage your child's fee payments."}
      />

      {(selfStatus === 'loading' || status === 'loading') && (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {Array.from({ length: 4 }).map((_, i) => <SkeletonCard key={i} />)}
        </div>
      )}

      {selfStatus === 'success' && !child && (
        <EmptyState icon="UserX" title="No child linked" description="Your account isn't linked to a student yet. Contact the school office." />
      )}

      {status === 'error' && <ErrorState description={error} onRetry={refetch} />}

      {status === 'success' && (
        <>
          <div className="mb-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            <StatCard label="Total Fees" value={formatCurrency(total)} icon="Receipt" accent="secondary" />
            <StatCard label="Total Paid" value={formatCurrency(totalPaid)} icon="CheckCircle2" accent="success" />
            <StatCard label="Pending" value={formatCurrency(totalPending)} icon="Clock" accent="warning" />
            <StatCard label="Overdue" value={formatCurrency(totalOverdue)} icon="AlertCircle" accent="destructive" />
          </div>

          {!fees || fees.length === 0 ? (
            <EmptyState icon="Receipt" title="No fees on record" />
          ) : (
            <div className="space-y-4">
              {fees.map((fee: FeeDto) => (
                <div key={fee.id} className="overflow-hidden rounded-xl border border-border bg-card">
                  <div className="flex flex-col gap-4 p-4 sm:flex-row sm:items-center sm:justify-between">
                    <div className="flex items-center gap-4">
                      <div
                        className={cn(
                          'flex h-12 w-12 shrink-0 items-center justify-center rounded-lg',
                          fee.status === 'PAID' ? 'bg-success/10 text-success' : fee.status === 'OVERDUE' ? 'bg-destructive/10 text-destructive' : 'bg-warning/10 text-warning'
                        )}
                      >
                        <Icons.CreditCard className="h-6 w-6" />
                      </div>
                      <div>
                        <h3 className="text-sm font-semibold text-foreground">{fee.title}</h3>
                        <div className="mt-1 flex items-center gap-3 text-xs">
                          <span className="text-lg font-bold text-foreground">{formatCurrency(fee.amount)}</span>
                          <span className="text-muted-foreground">Due {formatDate(fee.dueDate)}</span>
                        </div>
                      </div>
                    </div>
                    <StatusBadge status={fee.status.replace('_', ' ').toLowerCase()} variant={statusVariant[fee.status]} />
                  </div>
                </div>
              ))}
            </div>
          )}
        </>
      )}
    </>
  );
}
