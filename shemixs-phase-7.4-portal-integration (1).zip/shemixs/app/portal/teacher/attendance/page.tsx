'use client';

import { useState } from 'react';
import * as Icons from 'lucide-react';
import { PageHeader } from '@/components/portal/shared/page-header';
import { SectionCard } from '@/components/portal/shared/section-card';
import { StatCard } from '@/components/portal/shared/stat-card';
import { SkeletonRow } from '@/components/portal/shared/skeletons';
import { EmptyState } from '@/components/portal/shared/empty-state';
import { ErrorState } from '@/components/portal/shared/error-state';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { cn } from '@/lib/utils';
import { useToast } from '@/hooks/use-toast';
import { useBatches, useStudentsInBatch } from '@/lib/api/use-batches';
import { useApiMutation } from '@/lib/api/use-api-mutation';

type MarkStatus = 'PRESENT' | 'ABSENT' | 'LATE' | 'UNMARKED';

function initials(name: string) {
  return name.split(' ').map((n) => n[0]).join('').slice(0, 2).toUpperCase();
}

export default function TeacherAttendancePage() {
  const { toast } = useToast();
  const [batchId, setBatchId] = useState<string>('');
  const [attendance, setAttendance] = useState<Record<string, MarkStatus>>({});

  const { data: batches, status: batchesStatus } = useBatches();
  const { data: students, status: studentsStatus, error: studentsError, refetch: refetchStudents } = useStudentsInBatch(batchId || null);

  const bulkMark = useApiMutation<{ date: string; entries: { studentId: string; status: MarkStatus }[] }, unknown>(
    'post',
    '/api/attendance/students/bulk'
  );

  const markOne = (studentId: string, mark: MarkStatus) => setAttendance((prev) => ({ ...prev, [studentId]: mark }));

  const markAllPresent = () => {
    if (!students) return;
    const all: Record<string, MarkStatus> = {};
    students.forEach((s) => { all[s.id] = 'PRESENT'; });
    setAttendance(all);
  };

  const presentCount = Object.values(attendance).filter((s) => s === 'PRESENT').length;
  const absentCount = Object.values(attendance).filter((s) => s === 'ABSENT').length;
  const lateCount = Object.values(attendance).filter((s) => s === 'LATE').length;
  const markedCount = Object.values(attendance).filter((s) => s !== 'UNMARKED').length;

  async function handleSubmit() {
    const entries = Object.entries(attendance)
      .filter(([, status]) => status !== 'UNMARKED')
      .map(([studentId, status]) => ({ studentId, status: status as Exclude<MarkStatus, 'UNMARKED'> }));

    if (entries.length === 0) {
      toast({ title: 'Nothing to submit', description: 'Mark at least one student first.', variant: 'destructive' });
      return;
    }

    const result = await bulkMark.mutate({ date: new Date().toISOString().slice(0, 10), entries });
    if (result !== undefined) {
      toast({ title: 'Attendance submitted', description: `${entries.length} student(s) recorded.` });
      setAttendance({});
    } else if (bulkMark.error) {
      toast({ title: 'Failed to submit', description: bulkMark.error, variant: 'destructive' });
    }
  }

  const statusButton = (studentId: string, mark: Exclude<MarkStatus, 'UNMARKED'>, icon: React.ReactNode, label: string, activeClass: string) => {
    const current = attendance[studentId] ?? 'UNMARKED';
    const isActive = current === mark;
    return (
      <button
        type="button"
        onClick={() => markOne(studentId, mark)}
        className={cn(
          'flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-medium transition-colors',
          isActive ? activeClass : 'border border-border text-muted-foreground hover:bg-muted'
        )}
        aria-label={`Mark ${label}`}
      >
        {icon}
        {label}
      </button>
    );
  };

  return (
    <>
      <PageHeader title="Attendance" description="Mark and track student attendance for your classes.">
        <Button size="sm" onClick={markAllPresent} disabled={!students || students.length === 0}>
          <Icons.CheckCheck className="mr-2 h-4 w-4" />
          Mark All Present
        </Button>
      </PageHeader>

      <div className="mb-6 flex flex-col gap-3 sm:flex-row sm:items-center">
        <Select value={batchId} onValueChange={(v) => { setBatchId(v); setAttendance({}); }}>
          <SelectTrigger className="sm:w-56">
            <SelectValue placeholder={batchesStatus === 'loading' ? 'Loading batches…' : 'Select batch'} />
          </SelectTrigger>
          <SelectContent>
            {batches?.map((b) => (
              <SelectItem key={b.id} value={b.id}>{b.name}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div className="mb-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard label="Present" value={presentCount} icon="CheckCircle2" accent="success" />
        <StatCard label="Absent" value={absentCount} icon="XCircle" accent="destructive" />
        <StatCard label="Late" value={lateCount} icon="Clock" accent="warning" />
        <StatCard label="Marked" value={students ? `${markedCount}/${students.length}` : '—'} icon="ClipboardCheck" accent="primary" />
      </div>

      {!batchId ? (
        <EmptyState icon="Users" title="Select a batch" description="Choose a batch above to load its students." />
      ) : studentsStatus === 'error' ? (
        <ErrorState description={studentsError} onRetry={refetchStudents} />
      ) : (
        <SectionCard title="Students" icon={<Icons.Users className="h-4 w-4 text-primary" />}>
          <div className="divide-y divide-border">
            {studentsStatus === 'loading' && Array.from({ length: 6 }).map((_, i) => <SkeletonRow key={i} />)}

            {studentsStatus === 'success' && students?.length === 0 && (
              <EmptyState icon="Users" title="No students in this batch" />
            )}

            {studentsStatus === 'success' &&
              students?.map((student) => (
                <div key={student.id} className="flex items-center justify-between gap-4 py-3">
                  <div className="flex items-center gap-3">
                    <Avatar className="h-9 w-9 shrink-0">
                      <AvatarImage src={student.user.avatar ?? undefined} alt={student.user.fullName} />
                      <AvatarFallback>{initials(student.user.fullName)}</AvatarFallback>
                    </Avatar>
                    <p className="text-sm font-medium text-foreground">{student.user.fullName}</p>
                  </div>
                  <div className="flex gap-2">
                    {statusButton(student.id, 'PRESENT', <Icons.Check className="h-3.5 w-3.5" />, 'Present', 'bg-success text-success-foreground')}
                    {statusButton(student.id, 'ABSENT', <Icons.X className="h-3.5 w-3.5" />, 'Absent', 'bg-destructive text-destructive-foreground')}
                    {statusButton(student.id, 'LATE', <Icons.Clock className="h-3.5 w-3.5" />, 'Late', 'bg-warning text-warning-foreground')}
                  </div>
                </div>
              ))}
          </div>
        </SectionCard>
      )}

      {batchId && students && students.length > 0 && (
        <div className="mt-6 flex justify-end">
          <Button onClick={handleSubmit} disabled={bulkMark.isLoading || markedCount === 0}>
            {bulkMark.isLoading ? 'Submitting…' : `Submit Attendance (${markedCount})`}
          </Button>
        </div>
      )}
    </>
  );
}
