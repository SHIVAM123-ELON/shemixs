import { NextRequest } from 'next/server';
import { authService } from '@/server/services/auth.service';
import { loginSchema } from '@/server/validators/auth.validators';
import { apiSuccess } from '@/server/lib/api-response';
import { handleApiError } from '@/server/lib/errors';
import { setAccessTokenCookie, setRefreshTokenCookie } from '@/server/auth/cookies';
import { getRequestMeta } from '@/server/lib/request-meta';

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { email, password, rememberMe } = loginSchema.parse(body);

    const meta = getRequestMeta(req);
    const { user, tokens } = await authService.login(email, password, meta);

    const res = apiSuccess({ user }, { message: 'Logged in successfully' });
    setAccessTokenCookie(res, tokens.accessToken, tokens.accessTokenExpiresInSeconds);
    setRefreshTokenCookie(res, tokens.refreshToken, tokens.refreshTokenExpiresInSeconds, rememberMe);

    return res;
  } catch (error) {
    return handleApiError(error);
  }
}
