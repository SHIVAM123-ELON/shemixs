import { NextRequest } from 'next/server';
import { authService } from '@/server/services/auth.service';
import { apiSuccess } from '@/server/lib/api-response';
import { handleApiError } from '@/server/lib/errors';
import { setAccessTokenCookie, setRefreshTokenCookie, REFRESH_TOKEN_COOKIE } from '@/server/auth/cookies';
import { getRequestMeta } from '@/server/lib/request-meta';

export async function POST(req: NextRequest) {
  try {
    const refreshToken = req.cookies.get(REFRESH_TOKEN_COOKIE)?.value;
    const meta = getRequestMeta(req);

    const { user, tokens } = await authService.refresh(refreshToken, meta);

    const res = apiSuccess({ user }, { message: 'Session refreshed' });
    setAccessTokenCookie(res, tokens.accessToken, tokens.accessTokenExpiresInSeconds);
    // Rotation always re-issues a persistent refresh cookie; the
    // original "remember me" choice isn't re-askable here, so we
    // preserve session continuity by keeping it persistent.
    setRefreshTokenCookie(res, tokens.refreshToken, tokens.refreshTokenExpiresInSeconds, true);

    return res;
  } catch (error) {
    return handleApiError(error);
  }
}
