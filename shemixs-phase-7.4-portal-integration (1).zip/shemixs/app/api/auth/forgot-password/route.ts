import { NextRequest } from 'next/server';
import { authService } from '@/server/services/auth.service';
import { forgotPasswordSchema } from '@/server/validators/auth.validators';
import { apiSuccess } from '@/server/lib/api-response';
import { handleApiError } from '@/server/lib/errors';

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { email } = forgotPasswordSchema.parse(body);

    await authService.forgotPassword(email);

    // Same response regardless of whether the email exists — prevents
    // account enumeration via this endpoint.
    return apiSuccess(null, {
      message: 'If an account exists with that email, a password reset link has been sent.',
    });
  } catch (error) {
    return handleApiError(error);
  }
}
