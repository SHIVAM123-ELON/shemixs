import { NextRequest } from 'next/server';
import { authService } from '@/server/services/auth.service';
import { apiSuccess } from '@/server/lib/api-response';
import { handleApiError } from '@/server/lib/errors';
import { clearAuthCookies, REFRESH_TOKEN_COOKIE } from '@/server/auth/cookies';

export async function POST(req: NextRequest) {
  try {
    const refreshToken = req.cookies.get(REFRESH_TOKEN_COOKIE)?.value;
    await authService.logout(refreshToken);

    const res = apiSuccess(null, { message: 'Logged out successfully' });
    clearAuthCookies(res);
    return res;
  } catch (error) {
    return handleApiError(error);
  }
}
