import { NextRequest } from 'next/server';
import { authService } from '@/server/services/auth.service';
import { requireUser } from '@/server/auth/guard';
import { apiSuccess } from '@/server/lib/api-response';
import { handleApiError } from '@/server/lib/errors';

export async function GET(req: NextRequest) {
  try {
    const payload = await requireUser(req);
    const user = await authService.getCurrentUser(payload.sub);
    return apiSuccess({ user });
  } catch (error) {
    return handleApiError(error);
  }
}
