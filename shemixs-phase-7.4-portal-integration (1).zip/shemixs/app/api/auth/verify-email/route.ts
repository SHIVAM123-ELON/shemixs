import { NextRequest } from 'next/server';
import { authService } from '@/server/services/auth.service';
import { verifyEmailSchema } from '@/server/validators/auth.validators';
import { apiSuccess } from '@/server/lib/api-response';
import { handleApiError } from '@/server/lib/errors';

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { token } = verifyEmailSchema.parse(body);

    await authService.verifyEmail(token);

    return apiSuccess(null, { message: 'Email verified successfully' });
  } catch (error) {
    return handleApiError(error);
  }
}
