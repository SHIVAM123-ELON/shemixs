import { NextRequest } from 'next/server';
import { authService } from '@/server/services/auth.service';
import { resetPasswordSchema } from '@/server/validators/auth.validators';
import { apiSuccess } from '@/server/lib/api-response';
import { handleApiError } from '@/server/lib/errors';

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { token, password } = resetPasswordSchema.parse(body);

    await authService.resetPassword(token, password);

    return apiSuccess(null, { message: 'Password has been reset. Please log in with your new password.' });
  } catch (error) {
    return handleApiError(error);
  }
}
