import type { NextRequest } from 'next/server';
import { assignmentController } from '@/server/controllers/assignment.controller';
import { handleApiError } from '@/server/lib/errors';

export async function POST(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    return await assignmentController.publish(req, params);
  } catch (error) {
    return handleApiError(error);
  }
}
