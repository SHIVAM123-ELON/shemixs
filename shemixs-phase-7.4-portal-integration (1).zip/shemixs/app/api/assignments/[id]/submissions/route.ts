import type { NextRequest } from 'next/server';
import { assignmentController } from '@/server/controllers/assignment.controller';
import { handleApiError } from '@/server/lib/errors';

export async function GET(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    return await assignmentController.listSubmissions(req, params);
  } catch (error) {
    return handleApiError(error);
  }
}
