import type { NextRequest } from 'next/server';
import { assignmentController } from '@/server/controllers/assignment.controller';
import { handleApiError } from '@/server/lib/errors';

export async function PATCH(req: NextRequest, { params }: { params: { id: string; studentId: string } }) {
  try {
    return await assignmentController.evaluate(req, params);
  } catch (error) {
    return handleApiError(error);
  }
}
