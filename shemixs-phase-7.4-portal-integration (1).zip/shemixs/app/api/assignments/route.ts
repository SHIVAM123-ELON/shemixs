import type { NextRequest } from 'next/server';
import { assignmentController } from '@/server/controllers/assignment.controller';
import { handleApiError } from '@/server/lib/errors';

export async function GET(req: NextRequest) {
  try {
    return await assignmentController.list(req);
  } catch (error) {
    return handleApiError(error);
  }
}

export async function POST(req: NextRequest) {
  try {
    return await assignmentController.create(req);
  } catch (error) {
    return handleApiError(error);
  }
}
