import type { NextRequest } from 'next/server';
import { subjectController } from '@/server/controllers/subject.controller';
import { handleApiError } from '@/server/lib/errors';

export async function GET(req: NextRequest) {
  try {
    return await subjectController.list(req);
  } catch (error) {
    return handleApiError(error);
  }
}

export async function POST(req: NextRequest) {
  try {
    return await subjectController.create(req);
  } catch (error) {
    return handleApiError(error);
  }
}
