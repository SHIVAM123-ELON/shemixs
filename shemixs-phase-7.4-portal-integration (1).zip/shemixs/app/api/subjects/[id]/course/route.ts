import type { NextRequest } from 'next/server';
import { subjectController } from '@/server/controllers/subject.controller';
import { handleApiError } from '@/server/lib/errors';

export async function PUT(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    return await subjectController.assignCourse(req, params);
  } catch (error) {
    return handleApiError(error);
  }
}
