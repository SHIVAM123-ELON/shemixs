import type { NextRequest } from 'next/server';
import { subjectController } from '@/server/controllers/subject.controller';
import { handleApiError } from '@/server/lib/errors';

interface RouteParams {
  params: { id: string };
}

export async function GET(req: NextRequest, { params }: RouteParams) {
  try {
    return await subjectController.getById(req, params);
  } catch (error) {
    return handleApiError(error);
  }
}

export async function PUT(req: NextRequest, { params }: RouteParams) {
  try {
    return await subjectController.update(req, params);
  } catch (error) {
    return handleApiError(error);
  }
}

export async function PATCH(req: NextRequest, { params }: RouteParams) {
  try {
    return await subjectController.update(req, params);
  } catch (error) {
    return handleApiError(error);
  }
}

export async function DELETE(req: NextRequest, { params }: RouteParams) {
  try {
    return await subjectController.remove(req, params);
  } catch (error) {
    return handleApiError(error);
  }
}
