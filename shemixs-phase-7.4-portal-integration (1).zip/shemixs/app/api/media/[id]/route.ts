import type { NextRequest } from 'next/server';
import { mediaController } from '@/server/controllers/media.controller';
import { handleApiError } from '@/server/lib/errors';

export async function GET(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    return await mediaController.getById(req, params);
  } catch (error) {
    return handleApiError(error);
  }
}
