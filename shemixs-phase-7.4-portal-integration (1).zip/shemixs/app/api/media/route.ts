import type { NextRequest } from 'next/server';
import { mediaController } from '@/server/controllers/media.controller';
import { handleApiError } from '@/server/lib/errors';

export async function GET(req: NextRequest) {
  try {
    return await mediaController.list(req);
  } catch (error) {
    return handleApiError(error);
  }
}
