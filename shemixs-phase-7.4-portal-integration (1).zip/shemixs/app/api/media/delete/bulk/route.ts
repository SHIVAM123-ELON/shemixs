import type { NextRequest } from 'next/server';
import { mediaController } from '@/server/controllers/media.controller';
import { handleApiError } from '@/server/lib/errors';

export async function POST(req: NextRequest) {
  try {
    return await mediaController.bulkDelete(req);
  } catch (error) {
    return handleApiError(error);
  }
}
