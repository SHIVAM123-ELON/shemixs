import type { NextRequest } from 'next/server';
import { mediaController } from '@/server/controllers/media.controller';
import { handleApiError } from '@/server/lib/errors';

/** Per spec: `DELETE /api/media/delete` deletes a single media item (mediaId in the JSON body). */
export async function DELETE(req: NextRequest) {
  try {
    return await mediaController.delete(req);
  } catch (error) {
    return handleApiError(error);
  }
}
