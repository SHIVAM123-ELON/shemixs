import type { NextRequest } from 'next/server';
import { resultController } from '@/server/controllers/result.controller';
import { handleApiError } from '@/server/lib/errors';

export async function GET(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    return await resultController.studentHistory(req, params);
  } catch (error) {
    return handleApiError(error);
  }
}
