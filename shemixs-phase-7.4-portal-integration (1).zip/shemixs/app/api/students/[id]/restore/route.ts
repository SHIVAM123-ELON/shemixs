import type { NextRequest } from 'next/server';
import { studentController } from '@/server/controllers/student.controller';
import { handleApiError } from '@/server/lib/errors';

export async function POST(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    return await studentController.restore(req, params);
  } catch (error) {
    return handleApiError(error);
  }
}
