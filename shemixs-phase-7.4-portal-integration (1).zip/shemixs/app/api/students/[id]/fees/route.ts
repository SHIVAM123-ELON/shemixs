import type { NextRequest } from 'next/server';
import { feeController } from '@/server/controllers/fee.controller';
import { handleApiError } from '@/server/lib/errors';

export async function GET(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    return await feeController.studentFees(req, params);
  } catch (error) {
    return handleApiError(error);
  }
}
