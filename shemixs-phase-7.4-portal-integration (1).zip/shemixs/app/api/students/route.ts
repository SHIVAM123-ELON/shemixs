import type { NextRequest } from 'next/server';
import { studentController } from '@/server/controllers/student.controller';
import { handleApiError } from '@/server/lib/errors';

export async function GET(req: NextRequest) {
  try {
    return await studentController.list(req);
  } catch (error) {
    return handleApiError(error);
  }
}

export async function POST(req: NextRequest) {
  try {
    return await studentController.create(req);
  } catch (error) {
    return handleApiError(error);
  }
}
