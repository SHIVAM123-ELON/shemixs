import type { NextRequest } from 'next/server';
import { requireUser } from '@/server/auth/guard';
import { studentRepository } from '@/server/repositories/student.repository';
import { apiSuccess } from '@/server/lib/api-response';
import { handleApiError, NotFoundError } from '@/server/lib/errors';

/**
 * Every student-scoped resource (Fee, Payment, Result, Certificate,
 * Attendance, ...) is keyed by `Student.id`, not `User.id` — the JWT
 * only carries the latter. This route is the one place a logged-in
 * student resolves their own Student row, so the frontend never needs
 * a second lookup mechanism per feature.
 */
export async function GET(req: NextRequest) {
  try {
    const payload = await requireUser(req);
    const student = await studentRepository.findByUserId(payload.sub);
    if (!student) throw new NotFoundError('No student profile linked to this account');
    return apiSuccess(student);
  } catch (error) {
    return handleApiError(error);
  }
}
