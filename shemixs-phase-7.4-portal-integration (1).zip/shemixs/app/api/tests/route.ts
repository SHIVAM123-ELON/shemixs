import type { NextRequest } from 'next/server';
import { testController } from '@/server/controllers/test.controller';
import { handleApiError } from '@/server/lib/errors';

export async function GET(req: NextRequest) {
  try {
    return await testController.list(req);
  } catch (error) {
    return handleApiError(error);
  }
}

export async function POST(req: NextRequest) {
  try {
    return await testController.create(req);
  } catch (error) {
    return handleApiError(error);
  }
}
