import type { NextRequest } from 'next/server';
import { testController } from '@/server/controllers/test.controller';
import { handleApiError } from '@/server/lib/errors';

export async function POST(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    return await testController.publish(req, params);
  } catch (error) {
    return handleApiError(error);
  }
}
