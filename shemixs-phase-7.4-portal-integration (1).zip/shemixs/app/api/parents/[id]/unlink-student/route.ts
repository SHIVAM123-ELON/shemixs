import type { NextRequest } from 'next/server';
import { parentController } from '@/server/controllers/parent.controller';
import { handleApiError } from '@/server/lib/errors';

export async function POST(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    return await parentController.unlinkStudent(req, params);
  } catch (error) {
    return handleApiError(error);
  }
}
