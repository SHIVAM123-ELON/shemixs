import type { NextRequest } from 'next/server';
import { parentController } from '@/server/controllers/parent.controller';
import { handleApiError } from '@/server/lib/errors';

export async function GET(req: NextRequest) {
  try {
    return await parentController.list(req);
  } catch (error) {
    return handleApiError(error);
  }
}

export async function POST(req: NextRequest) {
  try {
    return await parentController.create(req);
  } catch (error) {
    return handleApiError(error);
  }
}
