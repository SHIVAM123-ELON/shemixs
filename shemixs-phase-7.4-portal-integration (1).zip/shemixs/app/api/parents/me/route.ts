import type { NextRequest } from 'next/server';
import { prisma } from '@/server/db/client';
import { requireUser } from '@/server/auth/guard';
import { apiSuccess } from '@/server/lib/api-response';
import { handleApiError, NotFoundError } from '@/server/lib/errors';

export async function GET(req: NextRequest) {
  try {
    const payload = await requireUser(req);
    const parent = await prisma.parent.findFirst({
      where: { userId: payload.sub, deletedAt: null },
      include: {
        studentLinks: {
          include: { student: { select: { id: true, admissionNo: true, user: { select: { fullName: true } } } } },
        },
      },
    });
    if (!parent) throw new NotFoundError('No parent profile linked to this account');
    return apiSuccess(parent);
  } catch (error) {
    return handleApiError(error);
  }
}
