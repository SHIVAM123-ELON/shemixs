import type { NextRequest } from 'next/server';
import { feeController } from '@/server/controllers/fee.controller';
import { handleApiError } from '@/server/lib/errors';

export async function GET(req: NextRequest) {
  try {
    return await feeController.list(req);
  } catch (error) {
    return handleApiError(error);
  }
}

export async function POST(req: NextRequest) {
  try {
    return await feeController.create(req);
  } catch (error) {
    return handleApiError(error);
  }
}
