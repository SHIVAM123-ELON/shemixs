import type { NextRequest } from 'next/server';
import { timetableController } from '@/server/controllers/timetable.controller';
import { handleApiError } from '@/server/lib/errors';

interface RouteParams {
  params: { id: string };
}

export async function GET(req: NextRequest, { params }: RouteParams) {
  try {
    return await timetableController.getById(req, params);
  } catch (error) {
    return handleApiError(error);
  }
}

export async function PUT(req: NextRequest, { params }: RouteParams) {
  try {
    return await timetableController.update(req, params);
  } catch (error) {
    return handleApiError(error);
  }
}

export async function PATCH(req: NextRequest, { params }: RouteParams) {
  try {
    return await timetableController.update(req, params);
  } catch (error) {
    return handleApiError(error);
  }
}

export async function DELETE(req: NextRequest, { params }: RouteParams) {
  try {
    return await timetableController.remove(req, params);
  } catch (error) {
    return handleApiError(error);
  }
}
