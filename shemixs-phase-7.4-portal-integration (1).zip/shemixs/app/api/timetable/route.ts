import type { NextRequest } from 'next/server';
import { timetableController } from '@/server/controllers/timetable.controller';
import { handleApiError } from '@/server/lib/errors';

export async function GET(req: NextRequest) {
  try {
    return await timetableController.list(req);
  } catch (error) {
    return handleApiError(error);
  }
}

export async function POST(req: NextRequest) {
  try {
    return await timetableController.create(req);
  } catch (error) {
    return handleApiError(error);
  }
}
