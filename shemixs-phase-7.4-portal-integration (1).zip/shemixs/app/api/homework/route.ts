import type { NextRequest } from 'next/server';
import { homeworkController } from '@/server/controllers/homework.controller';
import { handleApiError } from '@/server/lib/errors';

export async function GET(req: NextRequest) {
  try {
    return await homeworkController.list(req);
  } catch (error) {
    return handleApiError(error);
  }
}

export async function POST(req: NextRequest) {
  try {
    return await homeworkController.create(req);
  } catch (error) {
    return handleApiError(error);
  }
}
