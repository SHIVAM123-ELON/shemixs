import type { NextRequest } from 'next/server';
import { homeworkController } from '@/server/controllers/homework.controller';
import { handleApiError } from '@/server/lib/errors';

export async function POST(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    return await homeworkController.unpublish(req, params);
  } catch (error) {
    return handleApiError(error);
  }
}
