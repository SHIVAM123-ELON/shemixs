import type { NextRequest } from 'next/server';
import { homeworkController } from '@/server/controllers/homework.controller';
import { handleApiError } from '@/server/lib/errors';

interface RouteParams {
  params: { id: string };
}

export async function GET(req: NextRequest, { params }: RouteParams) {
  try {
    return await homeworkController.getById(req, params);
  } catch (error) {
    return handleApiError(error);
  }
}

export async function PUT(req: NextRequest, { params }: RouteParams) {
  try {
    return await homeworkController.update(req, params);
  } catch (error) {
    return handleApiError(error);
  }
}

export async function PATCH(req: NextRequest, { params }: RouteParams) {
  try {
    return await homeworkController.update(req, params);
  } catch (error) {
    return handleApiError(error);
  }
}

export async function DELETE(req: NextRequest, { params }: RouteParams) {
  try {
    return await homeworkController.remove(req, params);
  } catch (error) {
    return handleApiError(error);
  }
}
