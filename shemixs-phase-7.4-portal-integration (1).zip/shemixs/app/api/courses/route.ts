import type { NextRequest } from 'next/server';
import { courseController } from '@/server/controllers/course.controller';
import { handleApiError } from '@/server/lib/errors';

export async function GET(req: NextRequest) {
  try {
    return await courseController.list(req);
  } catch (error) {
    return handleApiError(error);
  }
}

export async function POST(req: NextRequest) {
  try {
    return await courseController.create(req);
  } catch (error) {
    return handleApiError(error);
  }
}
