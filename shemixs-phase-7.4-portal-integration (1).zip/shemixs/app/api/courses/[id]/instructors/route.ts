import type { NextRequest } from 'next/server';
import { courseController } from '@/server/controllers/course.controller';
import { handleApiError } from '@/server/lib/errors';

export async function PUT(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    return await courseController.assignInstructors(req, params);
  } catch (error) {
    return handleApiError(error);
  }
}
