import type { NextRequest } from 'next/server';
import { certificateController } from '@/server/controllers/certificate.controller';
import { handleApiError } from '@/server/lib/errors';

export async function GET(req: NextRequest) {
  try {
    return await certificateController.list(req);
  } catch (error) {
    return handleApiError(error);
  }
}

export async function POST(req: NextRequest) {
  try {
    return await certificateController.issue(req);
  } catch (error) {
    return handleApiError(error);
  }
}
