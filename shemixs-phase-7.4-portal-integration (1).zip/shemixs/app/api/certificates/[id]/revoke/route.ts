import type { NextRequest } from 'next/server';
import { certificateController } from '@/server/controllers/certificate.controller';
import { handleApiError } from '@/server/lib/errors';

export async function POST(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    return await certificateController.revoke(req, params);
  } catch (error) {
    return handleApiError(error);
  }
}
