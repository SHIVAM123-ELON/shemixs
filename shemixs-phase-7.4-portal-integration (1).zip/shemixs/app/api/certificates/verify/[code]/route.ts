import type { NextRequest } from 'next/server';
import { certificateController } from '@/server/controllers/certificate.controller';
import { handleApiError } from '@/server/lib/errors';

export async function GET(req: NextRequest, { params }: { params: { code: string } }) {
  try {
    return await certificateController.verify(req, params);
  } catch (error) {
    return handleApiError(error);
  }
}
