import type { NextRequest } from 'next/server';
import { notificationController } from '@/server/controllers/notification.controller';
import { handleApiError } from '@/server/lib/errors';

export async function GET(req: NextRequest) {
  try {
    return await notificationController.list(req);
  } catch (error) {
    return handleApiError(error);
  }
}
