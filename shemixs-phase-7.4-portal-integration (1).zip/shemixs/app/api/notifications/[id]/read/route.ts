import type { NextRequest } from 'next/server';
import { notificationController } from '@/server/controllers/notification.controller';
import { handleApiError } from '@/server/lib/errors';

export async function POST(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    return await notificationController.markRead(req, params);
  } catch (error) {
    return handleApiError(error);
  }
}
