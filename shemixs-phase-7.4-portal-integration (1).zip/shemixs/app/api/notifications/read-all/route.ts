import type { NextRequest } from 'next/server';
import { notificationController } from '@/server/controllers/notification.controller';
import { handleApiError } from '@/server/lib/errors';

export async function POST(req: NextRequest) {
  try {
    return await notificationController.markAllRead(req);
  } catch (error) {
    return handleApiError(error);
  }
}
