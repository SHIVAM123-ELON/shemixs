import type { NextRequest } from 'next/server';
import { admissionController } from '@/server/controllers/admission.controller';
import { handleApiError } from '@/server/lib/errors';

export async function GET(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    return await admissionController.timeline(req, params);
  } catch (error) {
    return handleApiError(error);
  }
}
