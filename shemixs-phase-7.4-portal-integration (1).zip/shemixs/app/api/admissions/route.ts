import type { NextRequest } from 'next/server';
import { admissionController } from '@/server/controllers/admission.controller';
import { handleApiError } from '@/server/lib/errors';

export async function GET(req: NextRequest) {
  try {
    return await admissionController.list(req);
  } catch (error) {
    return handleApiError(error);
  }
}

export async function POST(req: NextRequest) {
  try {
    return await admissionController.create(req);
  } catch (error) {
    return handleApiError(error);
  }
}
