import type { NextRequest } from 'next/server';
import { attendanceController } from '@/server/controllers/attendance.controller';
import { handleApiError } from '@/server/lib/errors';

export async function POST(req: NextRequest) {
  try {
    return await attendanceController.markTeacher(req);
  } catch (error) {
    return handleApiError(error);
  }
}
