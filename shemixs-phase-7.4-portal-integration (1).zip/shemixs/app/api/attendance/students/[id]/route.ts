import type { NextRequest } from 'next/server';
import { attendanceController } from '@/server/controllers/attendance.controller';
import { handleApiError } from '@/server/lib/errors';

export async function PATCH(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    return await attendanceController.updateStudent(req, params);
  } catch (error) {
    return handleApiError(error);
  }
}
