import type { NextRequest } from 'next/server';
import { batchController } from '@/server/controllers/batch.controller';
import { handleApiError } from '@/server/lib/errors';

export async function GET(req: NextRequest) {
  try {
    return await batchController.list(req);
  } catch (error) {
    return handleApiError(error);
  }
}

export async function POST(req: NextRequest) {
  try {
    return await batchController.create(req);
  } catch (error) {
    return handleApiError(error);
  }
}
