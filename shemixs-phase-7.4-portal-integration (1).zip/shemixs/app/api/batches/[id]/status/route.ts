import type { NextRequest } from 'next/server';
import { batchController } from '@/server/controllers/batch.controller';
import { handleApiError } from '@/server/lib/errors';

export async function PATCH(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    return await batchController.updateStatus(req, params);
  } catch (error) {
    return handleApiError(error);
  }
}
