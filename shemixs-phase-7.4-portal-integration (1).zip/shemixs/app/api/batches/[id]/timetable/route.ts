import type { NextRequest } from 'next/server';
import { timetableController } from '@/server/controllers/timetable.controller';
import { handleApiError } from '@/server/lib/errors';

export async function GET(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    return await timetableController.classTimetable(req, params);
  } catch (error) {
    return handleApiError(error);
  }
}
