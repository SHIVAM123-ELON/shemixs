import type { NextRequest } from 'next/server';
import { batchController } from '@/server/controllers/batch.controller';
import { handleApiError } from '@/server/lib/errors';

interface RouteParams {
  params: { id: string };
}

export async function GET(req: NextRequest, { params }: RouteParams) {
  try {
    return await batchController.getById(req, params);
  } catch (error) {
    return handleApiError(error);
  }
}

export async function PUT(req: NextRequest, { params }: RouteParams) {
  try {
    return await batchController.update(req, params);
  } catch (error) {
    return handleApiError(error);
  }
}

export async function PATCH(req: NextRequest, { params }: RouteParams) {
  try {
    return await batchController.update(req, params);
  } catch (error) {
    return handleApiError(error);
  }
}

export async function DELETE(req: NextRequest, { params }: RouteParams) {
  try {
    return await batchController.remove(req, params);
  } catch (error) {
    return handleApiError(error);
  }
}
