import type { NextRequest } from 'next/server';
import { sectionController } from '@/server/controllers/section.controller';
import { handleApiError } from '@/server/lib/errors';

export async function PUT(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    return await sectionController.assignStudents(req, params);
  } catch (error) {
    return handleApiError(error);
  }
}
