import type { NextRequest } from 'next/server';
import { sectionController } from '@/server/controllers/section.controller';
import { handleApiError } from '@/server/lib/errors';

export async function GET(req: NextRequest) {
  try {
    return await sectionController.list(req);
  } catch (error) {
    return handleApiError(error);
  }
}

export async function POST(req: NextRequest) {
  try {
    return await sectionController.create(req);
  } catch (error) {
    return handleApiError(error);
  }
}
