import type { NextRequest } from 'next/server';
import { teacherController } from '@/server/controllers/teacher.controller';
import { handleApiError } from '@/server/lib/errors';

export async function PATCH(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    return await teacherController.updateStatus(req, params);
  } catch (error) {
    return handleApiError(error);
  }
}
