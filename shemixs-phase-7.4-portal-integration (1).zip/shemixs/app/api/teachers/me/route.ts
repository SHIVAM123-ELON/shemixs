import type { NextRequest } from 'next/server';
import { prisma } from '@/server/db/client';
import { requireUser } from '@/server/auth/guard';
import { apiSuccess } from '@/server/lib/api-response';
import { handleApiError, NotFoundError } from '@/server/lib/errors';

export async function GET(req: NextRequest) {
  try {
    const payload = await requireUser(req);
    const teacher = await prisma.teacher.findFirst({ where: { userId: payload.sub, deletedAt: null } });
    if (!teacher) throw new NotFoundError('No teacher profile linked to this account');
    return apiSuccess(teacher);
  } catch (error) {
    return handleApiError(error);
  }
}
