import type { NextRequest } from 'next/server';
import { teacherController } from '@/server/controllers/teacher.controller';
import { handleApiError } from '@/server/lib/errors';

export async function GET(req: NextRequest) {
  try {
    return await teacherController.list(req);
  } catch (error) {
    return handleApiError(error);
  }
}

export async function POST(req: NextRequest) {
  try {
    return await teacherController.create(req);
  } catch (error) {
    return handleApiError(error);
  }
}
