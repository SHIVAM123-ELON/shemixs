import type { NextRequest } from 'next/server';
import { resultController } from '@/server/controllers/result.controller';
import { handleApiError } from '@/server/lib/errors';

export async function POST(req: NextRequest) {
  try {
    return await resultController.bulkCreate(req);
  } catch (error) {
    return handleApiError(error);
  }
}
