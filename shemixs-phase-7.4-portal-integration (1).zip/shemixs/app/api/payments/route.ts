import type { NextRequest } from 'next/server';
import { paymentController } from '@/server/controllers/payment.controller';
import { handleApiError } from '@/server/lib/errors';

export async function GET(req: NextRequest) {
  try {
    return await paymentController.list(req);
  } catch (error) {
    return handleApiError(error);
  }
}
