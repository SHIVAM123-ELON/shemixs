import type { NextRequest } from 'next/server';
import { paymentController } from '@/server/controllers/payment.controller';
import { handleApiError } from '@/server/lib/errors';

export async function GET(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    return await paymentController.receipt(req, params);
  } catch (error) {
    return handleApiError(error);
  }
}
