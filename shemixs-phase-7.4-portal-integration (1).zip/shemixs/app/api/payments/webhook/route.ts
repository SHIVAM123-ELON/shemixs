import type { NextRequest } from 'next/server';
import { webhookService } from '@/server/razorpay/webhook.service';
import { apiSuccess } from '@/server/lib/api-response';
import { handleApiError, UnauthorizedError } from '@/server/lib/errors';

/**
 * Razorpay calls this directly from their servers — there is no user
 * session, so authorization here is entirely the HMAC signature check
 * inside `webhookService.handle`, not `authorize()`. The raw body
 * (`req.text()`, not `req.json()`) is required because the signature
 * is computed over the exact bytes Razorpay sent.
 */
export async function POST(req: NextRequest) {
  try {
    const signature = req.headers.get('x-razorpay-signature');
    if (!signature) throw new UnauthorizedError('Missing webhook signature');

    const rawBody = await req.text();
    await webhookService.handle(rawBody, signature);

    return apiSuccess(null, { message: 'Webhook processed' });
  } catch (error) {
    return handleApiError(error);
  }
}
