# Phase 7.3A — Cloudinary Media Management: Architecture & Deliverables

## 1. Cloudinary Architecture

```
server/cloudinary/
├── cloudinary.config.ts   configures the SDK once, lazily, from env vars
├── cloudinary.service.ts  the ONLY file that calls the cloudinary package directly
├── categories.ts          folder + validation-rule registry (one entry per media type)
├── types.ts                shared TS types
├── validators.ts           Zod schemas + validateFile() (MIME/size check)
├── upload.service.ts       validate → upload → persist Media row
├── delete.service.ts       single + bulk delete (Cloudinary + DB)
└── replace.service.ts      upload-new → delete-old → update same Media row

server/repositories/media.repository.ts   Media table CRUD (Phase 7.2 repository pattern, reused)
server/services/media.service.ts          list/getById (read-only; write logic lives in cloudinary/*.service.ts)
server/controllers/media.controller.ts    the single controller all 8 media routes call into
```

Everything Cloudinary-specific is isolated under `server/cloudinary/` —
no other module's repository or service imports the `cloudinary`
package directly. A future provider swap (e.g. S3) would only touch
`cloudinary.service.ts`'s internals; every service above it
(`upload`/`delete`/`replace`) already deals in the provider-agnostic
`CloudinaryUploadResult` shape.

## 2. Folder Strategy

`server/cloudinary/categories.ts` is the single source of truth — one
`MediaCategoryKey` per media type from the spec, each mapped to a
Cloudinary folder, resource type, MIME allow-list, and max size:

```
profiles/students, profiles/parents, profiles/teachers, profiles/admins
courses/thumbnails, courses/videos, courses/videos/demo, courses/videos/live-classes
blog, gallery, cms, certificates
notes, homework, assignments, misc
```

Callers never specify a folder directly — they pass a `category` (e.g.
`"profile-student"`), and the folder/resource-type/validation rules
follow automatically. This is what prevents folder-structure drift: a
new upload call literally cannot write outside this registry's
folders.

## 3. Upload Flow

`POST /api/media/upload` (multipart form-data: `file` + `category` +
optional `entityType`/`entityId`):

1. **Auth** — `authorize()` verifies the JWT (any authenticated role;
   media is used across the whole app, so this is intentionally
   broader than a single-module RBAC list).
2. **Parse** — `req.formData()` (Next.js native, no extra dependency)
   extracts the `File` and fields; Zod validates `category` against
   the known category enum.
3. **Validate file** — `validateFile()` checks the file's MIME type
   against the category's allow-list and its size against the
   category's max, *before* any network call to Cloudinary.
4. **Upload** — `cloudinaryService.uploadBuffer()` streams the buffer
   to `cloudinary.uploader.upload_stream` with `quality: 'auto'` +
   `fetch_format: 'auto'` for images (automatic compression/format
   selection from the spec).
5. **Persist** — a `Media` row is created inside a transaction, then
   an audit log entry is recorded in the same transaction.

## 4. Delete Flow

`DELETE /api/media/delete` (single, `{ mediaId }`) and `POST
/api/media/delete/bulk` (`{ mediaIds: [...] }`, up to 100 at once):

- **Single**: Cloudinary delete happens first; only on success is the
  `Media` row soft-deleted (`deletedAt`) inside a transaction with the
  audit log entry. If Cloudinary delete throws, the DB row is left
  untouched — there's nothing to roll back and no orphaned "deleted in
  our DB but still live on Cloudinary" state.
- **Bulk**: best-effort per item — one failing Cloudinary delete
  doesn't block the rest. The response reports `{ deleted, failed }`
  so the caller knows which `publicId`s need manual cleanup.

Deletes are **soft** (matching every other Phase 7.2 module's
convention) — the `Media` row stays queryable via the historical
`entityId` link even after the file itself is gone from Cloudinary.

## 5. Replace Flow

`PATCH /api/media/replace` (multipart, `file` + `mediaId`):

1. Look up the existing `Media` row (its `category` determines
   validation rules for the new file).
2. Upload the **new** file first.
3. Only after the new upload succeeds, attempt to delete the **old**
   Cloudinary asset (best-effort — a failure here is logged but
   doesn't block the operation, since an orphaned old asset is a far
   cheaper problem than losing the new upload).
4. Update the same `Media` row's Cloudinary fields (`publicId`,
   `secureUrl`, etc.) — the row's `id` and its `entityType`/`entityId`
   link never change, so callers (e.g. "replace this student's profile
   photo") don't need to re-attach anything.

## 6. Security Strategy

- **Signed uploads**: `POST /api/media/signature` issues a
  Cloudinary-signed, time-boxed signature (`cloudinary.utils.
  api_sign_request`) for direct browser→Cloudinary uploads of very
  large files (e.g. live-class recordings) without routing the bytes
  through our server. The API secret never leaves the server; only the
  derived signature does.
- **Secure URLs**: `secure: true` is set globally in
  `cloudinary.config.ts` — every URL Cloudinary returns is `https://`.
- **RBAC**: every media route requires authentication via
  `authorize()`. Fine-grained "can this student delete this specific
  file" ownership checks are a natural addition once a module (e.g.
  Assignments) starts calling `uploadService.upload` with
  `entityType`/`entityId` set to that student's own submission — see
  Future Integration Points.
- **File validation**: MIME type and size are checked against the
  category's registry entry before any Cloudinary API call — an
  invalid upload is rejected as a 422 without spending any Cloudinary
  quota.
- **Environment validation**: `cloudinary.config.ts` validates
  `CLOUDINARY_CLOUD_NAME`/`_API_KEY`/`_API_SECRET` with Zod and throws
  a clear error if any are missing — but only when Cloudinary code
  actually runs, not at app startup, so the rest of the app (auth, the
  15 ERP modules) isn't hostage to Cloudinary being configured.
- **Logging**: Cloudinary upload/destroy failures are logged via the
  shared `logger` (Phase 7.1) with enough context to debug without
  leaking the API secret.
- **Max upload limits**: enforced per-category (5MB profile photos up
  to 1GB live-class recordings) — see `categories.ts`.

## 7. Environment Variables

Already present in `.env.example` from Phase 7.1 (comment updated to
reflect they're now implemented, not a future placeholder):

```
CLOUDINARY_CLOUD_NAME=
CLOUDINARY_API_KEY=
CLOUDINARY_API_SECRET=
```

## 8. Future Integration Points

- **Entity-level ownership checks**: currently any authenticated user
  can upload/replace/delete any media (module-level RBAC only). Once
  specific flows adopt this module (e.g. "a student uploads their own
  assignment submission"), the controller should additionally verify
  `ctx.userId` owns/may-modify the `entityId` being attached —
  straightforward to add without touching the upload/delete/replace
  services themselves.
- **Wiring into existing modules**: `Homework.attachmentUrls` (string
  array) and `AssignmentSubmission.contentUrl` (Phase 7.2) are
  currently plain URL fields. They can now be upgraded to reference
  `Media.id` rows uploaded via `category: "homework-document"` /
  `"assignment-document"`, giving them the same metadata (size,
  format, uploader, audit trail) as every other asset.
- **Signed uploads on the frontend**: the `/api/media/signature`
  endpoint exists but no frontend upload widget calls it yet — wiring
  a direct-to-Cloudinary upload flow for large video files (course
  videos, live-class recordings) is the natural next step, since
  routing multi-hundred-MB files through our own server is wasteful.
- **Responsive image helper**: `cloudinaryService.buildResponsiveUrl`
  is implemented but not yet exposed through an API route — a `GET
  /api/media/[id]/url?width=...` endpoint would let the frontend
  request a specific responsive size without duplicating Cloudinary's
  URL-transformation syntax client-side.

---

## Known limitations

- **Same sandbox limitation as Phases 7.1/7.2**: `npx prisma generate`
  could not be run (blocked `binaries.prisma.sh` access), so the new
  `Media` model and its relations were verified for schema syntax
  (brace balance, model count) but not against a live Prisma Client.
  `npm run lint`/`npm run build` likewise couldn't be run for the same
  reason. Run `npm install && npx prisma generate && npx prisma
  migrate dev`, then `npm run lint && npm run build` locally before
  merging.
- **`cloudinary` package was installed** (`npm install cloudinary`)
  and every new file passed an esbuild syntax sweep, but the actual
  Cloudinary API calls are untested against a live account — verify
  upload/delete/replace against a real Cloudinary sandbox account
  before production use.
- Video **duration** and image **width/height** are read from
  Cloudinary's upload response and stored as-is; no server-side
  transcoding, thumbnail generation, or virus scanning is implemented
  — those would be separate, explicit future phases if needed.
