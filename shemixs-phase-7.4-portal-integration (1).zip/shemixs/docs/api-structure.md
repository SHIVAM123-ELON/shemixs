# API Structure — Phase 7.1

## Response envelope

Every route returns one of two shapes via `server/lib/api-response.ts`:

```jsonc
// Success
{ "success": true, "data": { ... }, "message": "optional" }

// Error
{ "success": false, "error": { "message": "...", "code": "VALIDATION_ERROR", "details": { } } }
```

`code` is a stable machine-readable string (`UNAUTHORIZED`,
`FORBIDDEN`, `NOT_FOUND`, `CONFLICT`, `VALIDATION_ERROR`,
`TOO_MANY_REQUESTS`, `INTERNAL_ERROR`) so a frontend can branch on it
without parsing `message` text.

## Error handling

Every route wraps its body in `try { ... } catch (error) { return
handleApiError(error) }`. `handleApiError` (in `server/lib/errors.ts`):
- Recognizes `AppError` subclasses thrown deliberately by services
  (`UnauthorizedError` → 401, `ForbiddenError` → 403, `NotFoundError`
  → 404, `ConflictError` → 409, `ValidationError`/`ZodError` → 422,
  `TooManyRequestsError` → 429) and surfaces their message directly.
- Anything else (a genuine bug, a DB connection failure) is logged
  server-side with full detail via `logger.error`, but the client only
  ever sees a generic "Something went wrong" 500 — internal errors are
  never leaked to callers.

## Endpoints (this phase)

| Method | Path | Auth required | Body | Notes |
|---|---|---|---|---|
| POST | `/api/auth/login` | No | `{ email, password, rememberMe? }` | Sets access + refresh cookies |
| POST | `/api/auth/logout` | No (uses refresh cookie if present) | — | Clears cookies, revokes session |
| POST | `/api/auth/refresh` | No (uses refresh cookie) | — | Rotates tokens |
| GET | `/api/auth/me` | Yes | — | Returns current user from DB |
| POST | `/api/auth/forgot-password` | No | `{ email }` | Always same response (no enumeration) |
| POST | `/api/auth/reset-password` | No | `{ token, password }` | Revokes all sessions on success |
| POST | `/api/auth/verify-email` | No | `{ token }` | — |

All bodies are validated with Zod (`server/validators/auth.validators.ts`)
before touching the service layer — a malformed request never reaches
business logic.

## Validation → Service → Response, concretely

```ts
// app/api/auth/login/route.ts (abbreviated)
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { email, password, rememberMe } = loginSchema.parse(body); // throws ZodError → 422
    const { user, tokens } = await authService.login(email, password, meta); // throws AppError → mapped status
    const res = apiSuccess({ user });
    setAccessTokenCookie(res, tokens.accessToken, ...);
    return res;
  } catch (error) {
    return handleApiError(error);
  }
}
```

## Not yet built (future phases)

- `POST /api/auth/register` — deliberately omitted; user creation in
  this phase happens only via the seed script (bootstrap super admin).
  A registration/invite flow belongs with the Users business module.
- `POST /api/auth/change-password` — the service method exists
  (`authService.changePassword`) but isn't wired to a route yet since
  there's no settings-page consumer for it in this phase.
- Any endpoint under a resource other than `auth` (`/api/students`,
  `/api/attendance`, etc.) — out of scope per the phase brief.
