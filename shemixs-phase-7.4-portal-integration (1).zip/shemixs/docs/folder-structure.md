# Folder Structure — Phase 7.1

```
shemixs/
├── app/
│   ├── api/
│   │   └── auth/
│   │       ├── login/route.ts
│   │       ├── logout/route.ts
│   │       ├── refresh/route.ts
│   │       ├── forgot-password/route.ts
│   │       ├── reset-password/route.ts
│   │       ├── verify-email/route.ts
│   │       └── me/route.ts
│   ├── portal/            ← existing frontend, untouched
│   ├── layout.tsx         ← existing, untouched
│   └── page.tsx           ← existing, untouched
│
├── server/                ← ALL backend logic lives here, isolated from UI
│   ├── auth/
│   │   ├── jwt.ts         Sign/verify access & refresh tokens (jose)
│   │   ├── password.ts    Hash/verify passwords (bcryptjs), reset tokens
│   │   ├── cookies.ts     Cookie names + secure options
│   │   └── guard.ts       requireUser() / requireRole() for API routes
│   ├── db/
│   │   ├── client.ts      Prisma client singleton
│   │   └── transaction.ts withTransaction() helper
│   ├── repositories/
│   │   ├── base.repository.ts
│   │   ├── user.repository.ts
│   │   ├── role.repository.ts
│   │   └── session.repository.ts
│   ├── services/
│   │   └── auth.service.ts   All auth business logic
│   ├── lib/
│   │   ├── env.ts          Zod-validated process.env access
│   │   ├── api-response.ts apiSuccess() / apiError() envelopes
│   │   ├── errors.ts       AppError hierarchy + handleApiError()
│   │   ├── logger.ts       Structured JSON logger
│   │   ├── duration.ts     "15m" / "30d" → ms/seconds parsing
│   │   └── request-meta.ts Extract device/browser/IP from a request
│   ├── constants/
│   │   ├── roles.ts        ROLES, PORTAL_ROLE_MAP
│   │   └── permissions.ts  PERMISSION_ACTIONS, PERMISSION_RESOURCES
│   ├── types/
│   │   └── auth.types.ts   AuthenticatedUser, TokenPair, RequestMeta
│   └── validators/
│       └── auth.validators.ts  Zod schemas for every auth request body
│
├── middleware.ts           RBAC route protection (Edge Runtime)
│
├── prisma/
│   ├── schema.prisma
│   └── seed.ts
│
├── components/              ← existing frontend, untouched
├── lib/                     ← existing frontend utils, untouched
├── hooks/                   ← existing frontend hooks, untouched
│
├── .env.example
└── docs/                    ← this documentation set
```

## Why `server/` and not `lib/server/` or mixed into `lib/`

The existing `lib/` directory is frontend-oriented (`lib/site-config.ts`,
`lib/animations.ts`, `lib/portal/*` — UI nav configs and mock data
types consumed by client components). Backend code needed a home that
is unambiguously server-only, doesn't get accidentally imported into a
client component (which would either break the build or leak secrets
into the bundle), and mirrors the exact structure requested in the
spec. A top-level `server/` directory does that cleanly and matches
what was asked for.

## Import boundaries

- `app/api/**/route.ts` files are the *only* place that import from
  `server/services/*` — routes stay thin (parse → call service → shape
  response), all logic lives in the service layer.
- `server/services/*` import `server/repositories/*`, never Prisma
  directly — repositories are the only layer that talks to
  `@prisma/client`.
- `middleware.ts` imports only `server/auth/jwt.ts` and
  `server/constants/roles.ts` — kept minimal since it runs on the Edge
  Runtime, which has a smaller compatible API surface than Node.
- Nothing under `server/` is ever imported from a `'use client'`
  component.
