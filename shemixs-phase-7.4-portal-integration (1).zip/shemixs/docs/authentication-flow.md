# Authentication Flow — Phase 7.1

## Token model

Two JWTs, both HS256-signed, both stored as **HTTP-only cookies**
(never accessible to client-side JS, mitigating XSS token theft):

| Token | Cookie name | Lifetime | Purpose |
|---|---|---|---|
| Access token | `shemixs_access_token` | 15m (`JWT_ACCESS_EXPIRES_IN`) | Sent with every request; carries `sub` (user id), `role`, `email` |
| Refresh token | `shemixs_refresh_token` | 30d (`JWT_REFRESH_EXPIRES_IN`) | Redeemed at `/api/auth/refresh` to mint a new access token; carries `sub` and `sessionId` |

Every refresh token is also persisted in the `sessions` table
(hashed reference not needed — the signed JWT itself is the stored
value — but the row tracks device/browser/IP/expiry/revoked so a
session can be looked up, listed, and revoked independent of the
JWT's own expiry).

## Why two libraries, not the ones literally named in the spec

- **`jose` instead of `jsonwebtoken`** — `middleware.ts` (route
  protection) runs on the Next.js **Edge Runtime**, which does not
  provide Node's `crypto` module. `jsonwebtoken` requires it and would
  crash at the edge. `jose` is built for both runtimes, so the same
  `server/auth/jwt.ts` module verifies tokens identically in
  middleware and in Node API routes — one implementation, no drift.
- **`bcryptjs` instead of `bcrypt`** — native `bcrypt` ships a
  compiled binary that must match the exact OS/arch of wherever it
  runs. That's fragile on serverless targets (this project deploys to
  Netlify Functions per `netlify.toml`). `bcryptjs` is pure JS,
  functionally identical, no native build step.

## Flows

### Login — `POST /api/auth/login`
1. Validate `{ email, password, rememberMe }` with Zod.
2. Look up user by email (excluding soft-deleted); reject if missing,
   suspended, or inactive — same generic "Invalid email or password"
   message for missing-user and wrong-password to avoid leaking which
   emails are registered.
3. Verify password with `bcryptjs.compare`.
4. Create a `Session` row, sign an access + refresh JWT, set both as
   cookies. If `rememberMe` is false, the refresh cookie is a
   session cookie (no `maxAge`) so it disappears when the browser closes.

### Current user — `GET /api/auth/me`
Reads the access token cookie, verifies it, loads the user fresh from
the DB (not just trusting the JWT claims) so status/role changes take
effect without waiting for the token to expire.

### Refresh — `POST /api/auth/refresh`
1. Verify the refresh JWT signature *and* look up the matching
   `Session` row — both must agree (JWT valid, not expired, not
   revoked) or the request is rejected.
2. **Refresh token rotation**: the old session is revoked and a
   brand-new access+refresh pair (and session row) is issued on every
   refresh. If a stolen refresh token is ever replayed after the
   legitimate client has already rotated it, the old session is
   already revoked and the attacker's request fails — this is the
   standard mitigation for refresh-token theft.

### Logout — `POST /api/auth/logout`
Revokes the session matching the current refresh cookie and clears
both cookies. Does not error if there's no session (idempotent).

### Forgot / Reset password
- `POST /api/auth/forgot-password`: always returns the same success
  message whether or not the email exists (prevents account
  enumeration). If the user exists, generates a random 32-byte token,
  stores its **SHA-256 hash** (not the bcrypt hash — reset tokens need
  exact-match DB lookup by hash, which requires a deterministic
  digest; bcrypt is intentionally non-deterministic per hash) with a
  1-hour expiry. Email delivery is out of scope for this phase — the
  raw token is currently logged server-side so the flow is testable
  end-to-end; a mail service replaces that log line in a later phase.
- `POST /api/auth/reset-password`: validates the token (unused, not
  expired), hashes the new password, and as a side effect **revokes
  all of that user's active sessions** — a password reset should log
  the user out everywhere, including on the device that may have been
  compromised.

### Change password (service method, no public route yet)
`authService.changePassword` is implemented and ready to be wired to
a future settings-page route; it verifies the current password, then
also revokes all sessions on success.

### Email verification
`POST /api/auth/verify-email` — same single-use, hashed, expiring
token pattern as password reset. On success, flips
`emailVerified: true` and `status: ACTIVE`.

## Cookie security attributes

All auth cookies set `httpOnly: true`, `secure: true` in production,
`sameSite: 'lax'`, `path: '/'`. `lax` (rather than `strict`) is chosen
so a user following a link from email/elsewhere into the app doesn't
get logged out by the cookie being withheld on that first navigation,
while still blocking the cross-site POST requests CSRF attacks rely on.
