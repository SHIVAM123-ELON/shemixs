# Phase 7.3B — Razorpay, Email & WhatsApp: Architecture & Deliverables

## 1. Architecture Overview

Three independent provider integrations, each isolated the same way
Cloudinary was in Phase 7.3A, plus one orchestration layer that ties
all three (+ in-app) together:

```
server/razorpay/    config, low-level SDK+HMAC wrapper, order/verify/webhook services
server/email/       config, low-level nodemailer wrapper, templates
server/whatsapp/    config, low-level fetch-based Graph API wrapper
server/services/notification.service.ts   the ONE function every other module calls to notify a user
```

No module outside `server/razorpay/` imports the `razorpay` package;
no module outside `server/email/` imports `nodemailer`; no module
outside `server/whatsapp/` calls the Graph API directly. Every other
service (results, admissions, certificates, ...) that wants to notify
a user calls `notificationService.notify({ userId, title, body,
channels })` — it never touches email/WhatsApp specifics itself.

## 2. Razorpay (Payments) Flow

**Data model**: `Fee` (a line item a student owes) is separate from
`Payment` (one Razorpay order/attempt). A `Fee` can have multiple
`Payment`s against it — this is what makes partial payments work
without special-casing: `createOrderForFee` always creates an order
for the *remaining* balance (`fee.amount` minus the sum of prior
`PAID` payments), so paying in installments is just calling
create-order → checkout → verify multiple times.

**Create order** — `POST /api/payments/create-order` (`{ feeId }`):
looks up the fee, computes the remaining balance, calls
`razorpayService.createOrder`, persists a `Payment` row with status
`CREATED` and the Razorpay order id, returns everything the frontend's
Razorpay Checkout widget needs (`razorpayOrderId`, `razorpayKeyId`,
`amount`).

**Two independent settlement paths, same result:**
- **Client verify** — `POST /api/payments/verify` (called right after
  Razorpay's checkout widget returns success): verifies the HMAC
  signature (`order_id|payment_id` signed with the API secret),
  updates the `Payment` to `PAID`, recomputes the `Fee`'s status.
- **Webhook** — `POST /api/payments/webhook` (Razorpay's servers call
  this directly, no user session): verifies a *different* signature
  (the raw request body signed with the webhook secret), handles
  `payment.captured`/`payment.failed` events, does the same
  update-then-recompute.

Both paths call the exact same `recomputeFeeStatus()` function, so a
fee reaches the same `PENDING`/`PARTIALLY_PAID`/`PAID` status
regardless of which path fires first — and both are written to be
idempotent (re-processing an already-`PAID` payment is a no-op), since
the webhook *will* eventually fire even if the client-verify call
already handled it.

**Why the webhook is the source of truth, not just a bonus**: if a
user closes their browser the instant after paying (before the
`verify` call completes), the client-verify path never runs — the
webhook is what still settles the payment correctly.

## 3. Email Flow

Generic SMTP via `nodemailer`, not a provider SDK — works with Gmail,
SES, Mailgun, Postmark, or a self-hosted relay by changing only
`MAIL_HOST`/`MAIL_PORT`/`MAIL_USER`/`MAIL_PASSWORD`, no code changes.
`emailService.send({ to, subject, html })` is the only function
anything calls; it never throws (failures return `{ success: false,
error }`) so a broken SMTP config degrades to "notification not sent"
rather than crashing the operation that triggered it (a payment still
succeeds even if the receipt email fails to send).

`server/email/templates.ts` holds plain functions (no template-engine
dependency) for: password reset, admission status update, result
published, payment receipt, certificate issued.

**Wired examples** (2 of several possible trigger points, to prove the
pattern works end-to-end rather than leaving it purely theoretical):
- `authService.forgotPassword` now actually emails the reset link
  (Phase 7.1 only logged the raw token, since no email module existed
  yet).
- `verifyService.verify` (Razorpay) sends a payment-receipt email
  after a payment settles.

## 4. WhatsApp Flow

No SDK — `whatsapp.service.ts` calls Meta's WhatsApp Business Cloud
API directly with `fetch` (a REST call to
`https://graph.facebook.com/v20.0/{phone_number_id}/messages`), since
pulling in a wrapper package for one endpoint and two env vars
(`WHATSAPP_ACCESS_TOKEN`, `WHATSAPP_PHONE_NUMBER_ID`, both already
reserved in `.env.example` from Phase 7.1) would be the "unnecessary
dependency" the spec warns against.

**Important constraint documented in the code**: Meta's Cloud API only
allows free-text business-initiated messages within a 24-hour customer
service window (after the user has messaged the business number
first). Proactive notifications outside that window (e.g. "your
result is published" sent to someone who's never messaged in) require
a pre-approved message *template*, which isn't implemented here — see
Future Integration Points.

## 5. Notification Flow (in-app + orchestration)

`Notification` (Prisma) is channel-per-row: notifying a user across
`['IN_APP', 'EMAIL']` creates two rows, each tracked independently
(`QUEUED` → `SENT`/`FAILED`, or `READ` once the user opens it). This
means an email bounce never affects the in-app bell icon's unread
count, and vice versa.

`notificationService.notify(...)`:
1. Looks up the user (for their email/phone).
2. For each requested channel, creates a `Notification` row, then (for
   EMAIL/WHATSAPP) actually sends it and updates the row's status
   based on the result. IN_APP rows are `SENT` immediately — there's
   no external delivery step, the row *is* the notification.

**Endpoints** (every authenticated user reads only their own — no
module-level RBAC needed, ownership is the check):
- `GET /api/notifications` — paginated, filterable by channel/status,
  `meta.unreadCount` included for the bell-icon badge.
- `POST /api/notifications/[id]/read` — marks one as read (403s if it
  doesn't belong to the caller).
- `POST /api/notifications/read-all` — marks all of the caller's
  unread in-app notifications as read.

**Wired example**: `resultService.publishForTest` now notifies every
affected student in-app (`channels: ['IN_APP']`) when their results go
live, with a `data.resultId` deep-link the frontend can navigate to.

## 6. Security Strategy

- **Razorpay**: HMAC-SHA256 signature verification on both the
  client-verify path (order id + payment id, signed with the API
  secret) and the webhook path (raw body, signed with a *separate*
  webhook secret) — using Node's `crypto.timingSafeEqual` rather than
  `===` to avoid timing-attack signature guessing.
- **Email/WhatsApp credentials**: validated lazily and separately from
  the app-wide env schema (same pattern as Cloudinary in 7.3A) — the
  app boots fine without them; only code that actually sends a
  notification requires them configured.
- **Webhook route has no user session** — `/api/payments/webhook` is
  deliberately excluded from `authorize()`; its only gate is the HMAC
  signature check, matching how Razorpay's servers actually call it.
- **Notification ownership**: `markRead` verifies the notification
  belongs to the requesting user before allowing the mutation
  (`ForbiddenError` otherwise) — no notification-id enumeration path
  to read someone else's data.

## 7. Environment Variables

Added/updated in `.env.example` this phase:
```
RAZORPAY_KEY_ID=
RAZORPAY_KEY_SECRET=
RAZORPAY_WEBHOOK_SECRET=      # new — separate from the API secret, for webhook verification
MAIL_HOST=
MAIL_PORT=
MAIL_USER=
MAIL_PASSWORD=
MAIL_FROM=                    # new — the "From" address on outgoing emails
WHATSAPP_ACCESS_TOKEN=
WHATSAPP_PHONE_NUMBER_ID=
```

## 8. Future Integration Points

- **WhatsApp message templates**: proactive (outside-24h-window)
  notifications need Meta-approved templates, not free text — a
  `whatsappService.sendTemplate(to, templateName, params)` variant is
  the natural next addition once templates are approved in the Meta
  Business dashboard.
- **More email/WhatsApp trigger wiring**: only password-reset and
  payment-receipt (email) and result-publish (in-app) are wired as
  proof-of-pattern. Admission status changes, certificate issuance,
  and homework/assignment publish are equally natural
  `notificationService.notify(...)` call sites — same one-line
  pattern, not implemented everywhere yet to keep this phase's diff
  reviewable.
- **Notification preferences**: currently every wired trigger picks
  its own channel list. A `UserNotificationPreference` table (which
  channels a user wants for which event types) would let
  `notificationService.notify` filter `channels` per-user rather than
  every caller hard-coding them.
- **Refunds**: `PaymentStatus` includes `REFUNDED` in the enum, but no
  refund-initiation endpoint exists yet — `razorpayService` would need
  a `refund(paymentId, amount)` wrapper around Razorpay's refunds API.

---

## Known limitations

- Same sandbox network limitation as every prior phase: `prisma
  generate`/`migrate dev` couldn't run here (schema verified
  structurally — brace balance, model count — not against a live
  Prisma Client), and `npm run lint`/`npm run build` couldn't run for
  the same reason.
- **WhatsApp and email sends were not tested against real
  credentials/accounts** in this sandbox (no network path to Meta's
  Graph API or an SMTP server from here) — verify both against real
  test accounts before production use.
- Payment amounts are stored in the smallest currency unit (paise for
  INR) throughout, matching Razorpay's own convention — display code
  must divide by 100 (as the email template does) when showing rupees.
