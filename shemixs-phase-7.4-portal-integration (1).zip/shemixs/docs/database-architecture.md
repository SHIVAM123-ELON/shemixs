# Database Architecture — Phase 7.1

## Scope

This phase creates the **identity and access-control foundation** only:
users, roles, permissions, sessions, and minimal profile records for
each user type. No business-module tables (attendance, results, fees,
timetable, etc.) are created here — those arrive in later phases and
will reference these tables via foreign keys.

## Engine & ORM

- **PostgreSQL** as the database engine
- **Prisma ORM** (`@prisma/client` v5) for schema management, migrations,
  and type-safe queries
- Schema lives at `prisma/schema.prisma`; seed data at `prisma/seed.ts`

## Naming conventions

- Table names: `snake_case`, plural (`users`, `role_permissions`)
- Column names: `snake_case` in the database, `camelCase` in the
  Prisma schema/TS code, mapped via `@map(...)` / `@@map(...)`
- Primary keys: `id`, UUID (`@default(uuid())`), stored as native
  Postgres `uuid`
- Foreign keys: `<entity>_id` (e.g. `role_id`, `user_id`)
- Enums: singular, `SCREAMING_SNAKE_CASE` values, mapped to a
  lowercase Postgres enum type (e.g. `role_name`)

## Entity overview

```
Role ──< User >── Session
 │                  │
 │                  └── refresh token, device, IP, expiry, revoked
 │
 ├──< RolePermission >── Permission
 │        (join table)

User ── PasswordResetToken (1:N, single-use, hashed, expiring)
User ── EmailVerificationToken (1:N, single-use, hashed, expiring)

User ── Student (1:1, optional)
User ── Teacher (1:1, optional)
User ── Parent  (1:1, optional)
User ── Admin   (1:1, optional)
```

A `User` has exactly one `Role`. A `Role` has many `Users` and, through
`RolePermission`, many `Permission`s (a permission is an
`action` × `resource` pair, e.g. `PUBLISH` on `results`). This is a
standard RBAC join-table design — permissions are never assigned to
users directly, only to roles, which keeps authorization centrally
manageable as the school's org structure grows.

## Soft deletes

`User.deletedAt` implements soft deletion. Repositories filter
`deletedAt: null` on every read so a "deleted" user disappears from
the app immediately while the row (and its audit trail) is retained.
Hard deletes are not exposed anywhere in this phase.

## Indexes

Indexes are placed on every foreign key, on `User.status` (frequently
filtered in admin lists), on `Session.expiresAt` (used by a future
cleanup job), and on `Permission(action, resource)` (unique compound
index — a permission is uniquely identified by its action+resource
pair).

## Migrations

Run locally / in CI with:

```bash
npx prisma migrate dev     # creates + applies a migration, dev only
npx prisma migrate deploy  # applies existing migrations, production
npx prisma db seed         # runs prisma/seed.ts
```

No migration files are checked in yet from this sandbox — see the
root-level note in the PR description about why `prisma generate` /
`migrate dev` couldn't be executed in this environment, and run them
locally against a real `DATABASE_URL` before merging.
