# RBAC Overview — Phase 7.1

## Roles

Nine system roles, seeded by `prisma/seed.ts`, stored as a Postgres
enum (`role_name`) and a `Role` table row per value:

`SUPER_ADMIN`, `ADMIN`, `PRINCIPAL`, `COORDINATOR`, `TEACHER`,
`STUDENT`, `PARENT`, `ACCOUNTANT`, `RECEPTIONIST`.

Each `User` has exactly one `Role` (`User.roleId`, required,
`onDelete: Restrict` — a role in use can't be deleted out from under
its users).

## Permissions

A `Permission` is an `(action, resource)` pair — e.g. `PUBLISH` on
`results`, or `MANAGE` on `users`. Ten actions are defined (`CREATE`,
`READ`, `UPDATE`, `DELETE`, `EXPORT`, `IMPORT`, `PUBLISH`, `APPROVE`,
`ASSIGN`, `MANAGE`), matching the spec exactly. Resources are an open
string field (not an enum) so new business modules can introduce new
resources without a schema migration — `server/constants/permissions.ts`
tracks the currently-known resource list for validation/autocomplete
in tooling, but the DB itself doesn't hard-constrain it.

Permissions attach to roles, never to individual users, via the
`RolePermission` join table. This is the standard way to keep
authorization centrally manageable: change what a `TEACHER` can do
once, and every teacher account is affected immediately.

## Two layers of enforcement

**1. Route-level (coarse) — `middleware.ts`, Edge Runtime**
Protects `/portal/**`. Maps each portal segment (`admin`, `teacher`,
`student`, `parent`) to the roles allowed in `PORTAL_ROLE_MAP`
(`server/constants/roles.ts`). An unauthenticated visitor is
redirected to `/login`; an authenticated user with the wrong role is
redirected to their own portal's home instead of seeing a 403 page —
this is a UX choice (a parent hitting `/portal/admin` almost
certainly mis-navigated, not attempted an attack) and can be swapped
for a dedicated "forbidden" page later if preferred.

**2. API-level (fine-grained) — `server/auth/guard.ts`, Node runtime**
`requireUser(req)` verifies the access token and returns its payload
or throws `UnauthorizedError`. `requireRole(req, allowedRoles)` layers
a role check on top, throwing `ForbiddenError` (HTTP 403) if the
user's role isn't in the allowed list. Every API route that needs
protection calls one of these at the top of its handler.

Permission-level checks (can this specific role `PUBLISH` on
`results`?) are modeled in the schema and seeded for `SUPER_ADMIN`
in this phase, but a `requirePermission(...)` helper that queries
`RolePermission` at request time is intentionally **not** built yet —
there are no business-module routes to protect with it. It's a
natural, additive extension of `requireRole` once a later phase adds
actual CRUD endpoints for attendance/results/fees/etc.

## Session-level access control

Independent of RBAC, `Session.revoked` lets any session be
invalidated immediately (used by password reset/change, and available
for a future "log out this device" admin action) without waiting for
the JWT's own expiry — the refresh endpoint checks both the JWT
signature/expiry *and* the DB session's `revoked`/`expiresAt` fields.
