# Phase 7.2 — Core ERP Backend APIs: Architecture & Deliverables

## 1. API Architecture

Every module follows the same four-layer pipeline:

```
Route Handler  →  Controller  →  Service  →  Repository  →  Prisma
(HTTP shape)      (auth+parse)   (business logic+audit)   (queries)
```

- **Route Handler** (`app/api/**/route.ts`): 3–5 lines. Calls one
  controller method, wraps it in `try { } catch (e) { return
  handleApiError(e) }`. Nothing else.
- **Controller** (`server/controllers/*.controller.ts`): calls
  `authorize(req, ROLES)` first (auth + RBAC in one step), parses/
  validates the request body or query params with Zod, calls exactly
  one service method, shapes the response with `apiSuccess`/
  `apiPaginated`.
- **Service** (`server/services/*.service.ts`): all business logic —
  existence checks, conflict checks, multi-step workflows (e.g.
  admission approval → student creation), wraps mutations in
  `withTransaction`, calls `auditLogService.record` after every
  mutation.
- **Repository** (`server/repositories/*.repository.ts`): the only
  layer that imports Prisma types/queries. One `findMany` per module
  builds `where`/`orderBy`/`skip`/`take` from the shared query helper.

This is the same layering Phase 7.1 established for auth — Phase 7.2
just adds `controllers/` as a new layer sitting between routes and
services, matching this phase's spec.

## 2. Folder Structure

```
server/
├── controllers/     15 module controllers + base.controller.ts (authorize, parseSearchParams)
├── services/         15 module services + audit-log.service.ts
├── repositories/      15 module repositories + audit-log.repository.ts + base.repository.ts
├── validators/         15 module validator files + common.validators.ts (idParamSchema)
├── lib/
│   ├── query.ts       generic pagination/search/sort/date-range helper
│   ├── api-response.ts apiSuccess/apiPaginated/apiError
│   ├── errors.ts       AppError hierarchy + handleApiError
│   └── ...(env, logger, duration, request-meta — from Phase 7.1)
├── constants/roles.ts  MODULE_ROLE_MAP + moduleRoles() helper
└── auth/                (Phase 7.1 — jwt, password, cookies, guard)

app/api/
├── students/, teachers/, parents/, admissions/, courses/, subjects/,
│   batches/, sections/, timetable/, attendance/, homework/,
│   assignments/, tests/, results/, certificates/
    (80 route.ts files total across all modules)
```

## 3. Repository Pattern

Every repository extends `BaseRepository`, which supplies `this.db(tx)`
— returns the transaction client if one was passed, otherwise the
module-level Prisma singleton. This is how every write can
transparently participate in a service-level transaction without the
repository needing to know whether it's inside one.

Every list-capable repository's `findMany` follows the same shape:
build a `where` from `toPrismaBaseWhere` (soft-delete + date range) +
module-specific filters + `search` OR-clause, run `findMany` and
`count` in `Promise.all`, return `{ items, totalItems }`. The service
then calls `buildPaginationMeta(filters, totalItems)`.

## 4. Service Layer

Services own three things routes/controllers never should:
1. **Existence/conflict checks** before mutating (e.g. "does this
   admission number already exist").
2. **Transactions** — every create/update/delete that touches more
   than one table (or that must be audit-logged atomically) runs
   inside `withTransaction(async (tx) => { ... })`.
3. **Audit logging** — the last call inside every mutating
   transaction is `auditLogService.record(...)`, passed the same `tx`
   so the audit row and the data change commit or roll back together.

## 5. Route Handlers

RESTful, resource-based:
```
GET    /api/students              list (search/filter/sort/paginate)
GET    /api/students/[id]         get one
POST   /api/students              create
PUT    /api/students/[id]         update (full)
PATCH  /api/students/[id]         update (partial) — same handler as PUT
DELETE /api/students/[id]         soft delete
```
Module-specific actions get their own nested route rather than
overloading the base ones: `PATCH /api/students/[id]/status`, `POST
/api/students/[id]/restore`, `PATCH /api/students/[id]/enrollment`,
`POST /api/admissions/[id]/approve`, `POST
/api/certificates/[id]/revoke`, etc. — mirrors the "Example:
/api/students, /api/students/[id]" convention from the spec, extended
consistently for every module's named actions (verify/approve/reject,
publish/unpublish, link/unlink, assign, etc).

## 6. Validation Flow

Every module has a `server/validators/<module>.validators.ts` with a
Zod schema per operation (`create*Schema`, `update*Schema`,
`*ListQuerySchema`, plus action-specific ones like
`approveAdmissionSchema`). Controllers call `.parse()` — on failure
this throws `ZodError`, which `handleApiError` catches and converts to
a 422 with `error.details` containing Zod's field-level breakdown via
`.flatten()`. Route params (`[id]`) go through the shared
`idParamSchema` in `common.validators.ts` so every module validates
UUIDs identically. Query params for lists go through
`listQuerySchema` (page/pageSize/search/sortBy/sortOrder/status/
dateFrom/dateTo/createdBy/updatedBy), extended per-module with
domain-specific filters (e.g. `batchId` for students).

## 7. Authentication & Authorization Flow

Reused unchanged from Phase 7.1: JWT access-token cookie, verified via
`requireRole` (`server/auth/guard.ts`). Phase 7.2 adds
`MODULE_ROLE_MAP` (`server/constants/roles.ts`) — one entry per
module, matching the spec's examples exactly (Students: Admin/
Principal/Coordinator; Teachers: Admin/Principal; Finance:
Accountant/Super Admin). `moduleRoles('students')` returns that list
with `SUPER_ADMIN` always prepended. `authorize(req, ROLES)` in
`base.controller.ts` is the single call every controller method makes
first — it verifies the JWT *and* the role in one step, returning
`{ userId, role, email, meta }` for the controller to use.

One deliberate exception: `GET /api/certificates/verify/[code]` skips
`authorize()` entirely — certificate verification is a public-facing
check (e.g. an employer scanning a QR code on a printed certificate),
not an internal ERP operation, and it only accepts the unguessable
verification code, never the internal id.

## 8. Audit Log Architecture

One table (`AuditLog`, Phase 7.2 schema addition) serves every module
— `module` (string) + `action` (enum: CREATE/UPDATE/DELETE/RESTORE/
APPROVE/REJECT/PUBLISH/ASSIGN/LOGIN/LOGOUT) + `entityId` + JSON
`before`/`after` snapshots + `userId`/`userRole`/`ipAddress`/
`userAgent`/`createdAt`. A single-table design (rather than a table
per module) was chosen because: audit rows are written far more than
read, a generic writer (`auditLogService.record`) means every service
gets audit logging "for free" by following the same one-line call
pattern, and cross-module audit queries (e.g. "everything this admin
did today") don't require a UNION across 15 tables.

Every mutating service method's last transactional step is
`auditLogService.record({ userId, userRole, module, action, entityId,
before?, after?, meta }, tx)` — always inside the same `tx` as the
data change it's recording.

## 9. Pagination & Search Strategy

`server/lib/query.ts` is the single source of truth:
- `listQuerySchema` (Zod) — the query params every list endpoint accepts.
- `buildPaginationMeta(query, totalItems)` → `{ page, pageSize,
  totalItems, totalPages, hasNextPage, hasPreviousPage }`, returned as
  `meta.pagination` via `apiPaginated()`.
- `toPrismaSkipTake(query)` → `{ skip, take }`.
- `toPrismaOrderBy(query, allowedSortFields, defaultField)` — only
  allows sorting by fields the module explicitly allow-lists, falling
  back to `createdAt` (or a module-specific default like `issuedAt`
  for certificates) for anything else.
- `toPrismaBaseWhere(query)` — the shared `deletedAt: null` +
  `createdAt` date-range fragment every module's `where` starts from.

Search is per-module (different modules search different fields —
students search name/email/admission-no, courses search title only)
but always an `OR`-of-`contains`-`insensitive` built the same way.

**Deliberate exception**: Timetable list endpoints are NOT paginated
— a weekly schedule is a small, complete data set by nature (at most
a few dozen entries per section/teacher/batch), and paginating a
calendar view would be actively unhelpful to a client rendering it.

## 10. Future Integration Points

- **Attachments**: `Homework.attachmentUrls` and
  `AssignmentSubmission.contentUrl` are string/string[] placeholders
  today (spec: "Attachments Placeholder"). Wiring real file upload
  means adding Cloudinary env vars (already placeholdered in
  `.env.example` from Phase 7.1) and a signed-upload route.
- **Certificates as PDFs**: `Certificate` currently stores structured
  data + a verification code; rendering an actual PDF/image
  certificate is a natural next phase (the `pdf` skill in this
  environment could generate it from the stored `metadata`).
- **Notifications**: Admission status changes, homework/assignment
  publish, and result publish are all natural triggers for a future
  notification/email module — `AdmissionEvent` and the `AuditLog`
  already capture the "what happened, when" a notification dispatcher
  would consume.
- **Fine-grained `Permission` checks**: `RolePermission` (Phase 7.1)
  is seeded but only enforced at the role level in Phase 7.2
  (`requireRole`). A `requirePermission(req, resource, action)` helper
  querying `RolePermission` is a straightforward addition once
  business rules need per-action (not just per-module) authorization.
- **Bulk import/export**: Query helper already reserves `EXPORT`/
  `IMPORT` in `PermissionAction`; no endpoints implement them yet.

---

## Known limitations / things to verify before production

- **`npx prisma generate` / `migrate dev` could not be run** in this
  build sandbox (network egress doesn't reach `binaries.prisma.sh` —
  same limitation noted in Phase 7.1). All 34 models and ~140 new/
  changed TypeScript files were verified with an esbuild syntax sweep
  (parses cleanly) but **not** type-checked against the generated
  Prisma client. Run `npm install && npx prisma generate && npx prisma
  migrate dev` locally, then `npm run typecheck` and `npm run build`
  — fix any type mismatches Prisma's generated types surface that
  static syntax-checking couldn't catch.
- **`npm run lint` / `npm run build`** (requested in the spec's final
  step) could not be run for the same reason — the Next.js build
  needs the generated Prisma client to type-check API routes.
- Several relations were modeled with reasonable but unstated
  assumptions worth confirming against your actual data model:
  "Class Mapping" for Sections is treated as the same thing as batch
  mapping (no separate `Class` entity existed); a student's schedule
  is resolved through their `Section`; teacher/section double-booking
  is prevented in Timetable but batch/room conflicts are not checked.
