'use client';

import * as Icons from 'lucide-react';
import { PageHeader } from '@/components/portal/shared/page-header';
import { SectionCard } from '@/components/portal/shared/section-card';
import { SkeletonRow } from '@/components/portal/shared/skeletons';
import { EmptyState } from '@/components/portal/shared/empty-state';
import { ErrorState } from '@/components/portal/shared/error-state';
import { useApiQuery } from '@/lib/api/use-api-query';
import { useStudentResults } from '@/lib/api/use-results';

interface ParentSelfDto {
  studentLinks: { student: { id: string; user: { fullName: string } } }[];
}

const gradeColor = (grade: string | null) => {
  if (!grade) return 'text-muted-foreground';
  if (grade.startsWith('A+')) return 'text-success';
  if (grade.startsWith('A')) return 'text-primary';
  if (grade.startsWith('B')) return 'text-warning';
  return 'text-destructive';
};

export default function ParentResultsPage() {
  const { data: self, status: selfStatus, error: selfError, refetch: refetchSelf } = useApiQuery<ParentSelfDto>('/api/parents/me');
  const child = self?.studentLinks[0]?.student;
  const { data: results, status, error, refetch } = useStudentResults(child?.id ?? null);

  if (selfStatus === 'error') return <ErrorState description={selfError} onRetry={refetchSelf} />;

  return (
    <>
      <PageHeader title="Results" description={child ? `Viewing results for ${child.user.fullName}.` : "Your child's academic results."} />

      {selfStatus === 'success' && !child && (
        <EmptyState icon="UserX" title="No child linked" description="Your account isn't linked to a student yet." />
      )}

      {status === 'error' && <ErrorState description={error} onRetry={refetch} />}

      {child && (
        <SectionCard title="Test Results" icon={<Icons.ClipboardList className="h-4 w-4 text-primary" />}>
          {status === 'loading' && (
            <div className="space-y-1">
              {Array.from({ length: 5 }).map((_, i) => <SkeletonRow key={i} />)}
            </div>
          )}

          {status === 'success' && (!results || results.length === 0) && (
            <EmptyState icon="ClipboardList" title="No results published yet" />
          )}

          {status === 'success' && results && results.length > 0 && (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-border text-left text-muted-foreground">
                    <th className="pb-2 font-medium">Test</th>
                    <th className="pb-2 font-medium">Marks</th>
                    <th className="pb-2 font-medium">Grade</th>
                    <th className="pb-2 font-medium">Rank</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {results.map((r) => (
                    <tr key={r.id}>
                      <td className="py-3 font-medium text-foreground">{r.test.title}</td>
                      <td className="py-3 text-foreground">{r.marksObtained !== null ? `${r.marksObtained} / ${r.test.maxMarks}` : 'Pending'}</td>
                      <td className={`py-3 font-semibold ${gradeColor(r.grade)}`}>{r.grade ?? '—'}</td>
                      <td className="py-3 text-muted-foreground">{r.rank ?? '—'}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </SectionCard>
      )}
    </>
  );
}
