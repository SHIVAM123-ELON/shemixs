'use client';

import * as Icons from 'lucide-react';
import { PageHeader } from '@/components/portal/shared/page-header';
import { SectionCard } from '@/components/portal/shared/section-card';
import { StatCard } from '@/components/portal/shared/stat-card';
import { StatusBadge } from '@/components/portal/shared/status-badge';
import { EmptyState } from '@/components/portal/shared/empty-state';
import { ErrorState } from '@/components/portal/shared/error-state';
import { SkeletonCard } from '@/components/portal/shared/skeletons';
import { useApiQuery } from '@/lib/api/use-api-query';
import { useStudentAttendanceHistory, useStudentAttendanceReport } from '@/lib/api/use-attendance';

interface ParentSelfDto {
  studentLinks: { student: { id: string; user: { fullName: string } } }[];
}

const statusVariant = {
  PRESENT: 'success',
  ABSENT: 'destructive',
  LATE: 'warning',
  HALF_DAY: 'warning',
  EXCUSED: 'info',
} as const;

export default function ParentAttendancePage() {
  const { data: self, status: selfStatus, error: selfError, refetch: refetchSelf } = useApiQuery<ParentSelfDto>('/api/parents/me');
  const child = self?.studentLinks[0]?.student;

  const { data: history, status, error, refetch } = useStudentAttendanceHistory(child?.id ?? null);
  const { data: report } = useStudentAttendanceReport(child?.id ?? null);

  if (selfStatus === 'error') return <ErrorState description={selfError} onRetry={refetchSelf} />;

  const total = Object.values(report ?? {}).reduce((sum, n) => sum + (n ?? 0), 0);
  const present = report?.PRESENT ?? 0;
  const overallPct = total > 0 ? Math.round((present / total) * 100) : 0;

  return (
    <>
      <PageHeader title="Attendance" description={child ? `Viewing attendance for ${child.user.fullName}.` : "Your child's attendance record."} />

      {selfStatus === 'success' && !child && (
        <EmptyState icon="UserX" title="No child linked" description="Your account isn't linked to a student yet." />
      )}

      {status === 'error' && <ErrorState description={error} onRetry={refetch} />}

      {status === 'loading' && (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {Array.from({ length: 3 }).map((_, i) => <SkeletonCard key={i} />)}
        </div>
      )}

      {child && status === 'success' && (
        <>
          <div className="mb-6 grid gap-4 sm:grid-cols-3">
            <StatCard label="Overall Attendance" value={`${overallPct}%`} icon="CalendarCheck" accent="success" />
            <StatCard label="Present" value={present} icon="CheckCircle2" accent="primary" />
            <StatCard label="Total Classes" value={total} icon="CalendarDays" accent="secondary" />
          </div>

          <SectionCard title="Attendance Records" icon={<Icons.CalendarDays className="h-4 w-4 text-accent" />}>
            {!history || history.length === 0 ? (
              <EmptyState icon="CalendarX" title="No attendance records yet" />
            ) : (
              <div className="space-y-2">
                {history.map((record) => (
                  <div key={record.id} className="flex items-center gap-4 rounded-lg border border-border p-3">
                    <div className="flex w-12 shrink-0 flex-col items-center">
                      <span className="text-sm font-bold text-foreground">{new Date(record.date).getDate()}</span>
                      <span className="text-xs text-muted-foreground">{new Date(record.date).toLocaleDateString('en-US', { month: 'short' })}</span>
                    </div>
                    <div className="h-8 w-px bg-border" />
                    <div className="min-w-0 flex-1">
                      <p className="text-sm font-medium text-foreground">{record.remarks ?? 'No remarks'}</p>
                    </div>
                    <StatusBadge status={record.status.replace('_', ' ').toLowerCase()} variant={statusVariant[record.status]} />
                  </div>
                ))}
              </div>
            )}
          </SectionCard>
        </>
      )}
    </>
  );
}
