'use client';

import * as Icons from 'lucide-react';
import { PageHeader } from '@/components/portal/shared/page-header';
import { SectionCard } from '@/components/portal/shared/section-card';
import { SkeletonRow } from '@/components/portal/shared/skeletons';
import { EmptyState } from '@/components/portal/shared/empty-state';
import { ErrorState } from '@/components/portal/shared/error-state';
import { useAuth } from '@/lib/api/use-auth';
import { useApiQuery } from '@/lib/api/use-api-query';
import { useStudentResults } from '@/lib/api/use-results';

interface StudentSelfDto {
  id: string;
}

const gradeColor = (grade: string | null) => {
  if (!grade) return 'text-muted-foreground';
  if (grade.startsWith('A+')) return 'text-success';
  if (grade.startsWith('A')) return 'text-primary';
  if (grade.startsWith('B')) return 'text-warning';
  return 'text-destructive';
};

export default function ResultsPage() {
  const { user } = useAuth();
  const { data: self } = useApiQuery<StudentSelfDto>(user ? '/api/students/me' : null);
  const { data: results, status, error, refetch } = useStudentResults(self?.id ?? null);

  const graded = (results ?? []).filter((r) => r.marksObtained !== null);
  const avgPercentage =
    graded.length > 0
      ? Math.round(graded.reduce((sum, r) => sum + (r.marksObtained! / r.test.maxMarks) * 100, 0) / graded.length)
      : 0;
  const bestRank = graded.filter((r) => r.rank !== null).sort((a, b) => (a.rank ?? 0) - (b.rank ?? 0))[0]?.rank;

  return (
    <>
      <PageHeader title="Results" description="Your test results and academic performance overview." />

      {status === 'error' && <ErrorState description={error} onRetry={refetch} />}

      {status === 'success' && (
        <div className="mb-6 grid gap-4 sm:grid-cols-3">
          <div className="rounded-xl border border-border bg-card p-5">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                <Icons.Award className="h-5 w-5 text-primary" />
              </div>
              <div>
                <p className="text-2xl font-bold text-foreground">{avgPercentage}%</p>
                <p className="text-xs text-muted-foreground">Average Score</p>
              </div>
            </div>
          </div>
          <div className="rounded-xl border border-border bg-card p-5">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-success/10">
                <Icons.Trophy className="h-5 w-5 text-success" />
              </div>
              <div>
                <p className="text-2xl font-bold text-foreground">{bestRank ?? '—'}</p>
                <p className="text-xs text-muted-foreground">Best Rank</p>
              </div>
            </div>
          </div>
          <div className="rounded-xl border border-border bg-card p-5">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-accent/10">
                <Icons.FileCheck className="h-5 w-5 text-accent" />
              </div>
              <div>
                <p className="text-2xl font-bold text-foreground">{results?.length ?? 0}</p>
                <p className="text-xs text-muted-foreground">Published Results</p>
              </div>
            </div>
          </div>
        </div>
      )}

      <SectionCard title="Test Results" icon={<Icons.ClipboardList className="h-4 w-4 text-primary" />}>
        {status === 'loading' && (
          <div className="space-y-1">
            {Array.from({ length: 5 }).map((_, i) => <SkeletonRow key={i} />)}
          </div>
        )}

        {status === 'success' && (!results || results.length === 0) && (
          <EmptyState icon="ClipboardList" title="No results published yet" description="Check back once your teacher publishes test results." />
        )}

        {status === 'success' && results && results.length > 0 && (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-border text-left text-muted-foreground">
                  <th className="pb-2 font-medium">Test</th>
                  <th className="pb-2 font-medium">Marks</th>
                  <th className="pb-2 font-medium">Grade</th>
                  <th className="pb-2 font-medium">Rank</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {results.map((r) => (
                  <tr key={r.id}>
                    <td className="py-3 font-medium text-foreground">{r.test.title}</td>
                    <td className="py-3 text-foreground">
                      {r.marksObtained !== null ? `${r.marksObtained} / ${r.test.maxMarks}` : 'Pending'}
                    </td>
                    <td className={`py-3 font-semibold ${gradeColor(r.grade)}`}>{r.grade ?? '—'}</td>
                    <td className="py-3 text-muted-foreground">{r.rank ?? '—'}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </SectionCard>
    </>
  );
}
