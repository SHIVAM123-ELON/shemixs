'use client';

import * as Icons from 'lucide-react';
import { PageHeader } from '@/components/portal/shared/page-header';
import { SectionCard } from '@/components/portal/shared/section-card';
import { StatusBadge } from '@/components/portal/shared/status-badge';
import { EmptyState } from '@/components/portal/shared/empty-state';
import { ErrorState } from '@/components/portal/shared/error-state';
import { SkeletonCard } from '@/components/portal/shared/skeletons';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/lib/api/use-auth';
import { useApiQuery } from '@/lib/api/use-api-query';
import { useAssignments, useSubmitAssignment, type AssignmentDto } from '@/lib/api/use-assignments';

interface StudentSelfDto {
  id: string;
}

function formatDate(dateStr: string) {
  return new Date(dateStr).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
}

function AssignmentCard({ assignment, studentId, onSubmitted }: { assignment: AssignmentDto; studentId: string; onSubmitted: () => void }) {
  const { toast } = useToast();
  const submit = useSubmitAssignment(assignment.id);

  async function handleSubmit() {
    const result = await submit.mutate({ studentId });
    if (result !== undefined) {
      toast({ title: 'Assignment submitted', description: assignment.title });
      onSubmitted();
    } else if (submit.error) {
      toast({ title: 'Submission failed', description: submit.error, variant: 'destructive' });
    }
  }

  const overdue = new Date(assignment.dueDate) < new Date();

  return (
    <SectionCard title={assignment.title} icon={<Icons.FileText className="h-4 w-4 text-primary" />}>
      <div className="space-y-3">
        {assignment.description && <p className="text-sm text-muted-foreground">{assignment.description}</p>}
        <div className="flex flex-wrap items-center gap-2 text-xs text-muted-foreground">
          {assignment.subject && <span className="rounded-full bg-muted px-2 py-1">{assignment.subject.name}</span>}
          {assignment.maxMarks && <span>{assignment.maxMarks} marks</span>}
        </div>
        <div className="flex items-center justify-between">
          <span className="flex items-center gap-1.5 text-xs text-muted-foreground">
            <Icons.CalendarDays className="h-3.5 w-3.5" />
            Due {formatDate(assignment.dueDate)}
          </span>
          <StatusBadge status={overdue ? 'overdue' : 'upcoming'} variant={overdue ? 'destructive' : 'success'} />
        </div>
        <Button size="sm" className="w-full" onClick={handleSubmit} disabled={submit.isLoading}>
          {submit.isLoading ? 'Submitting…' : 'Submit Assignment'}
        </Button>
      </div>
    </SectionCard>
  );
}

export default function AssignmentsPage() {
  const { user } = useAuth();
  const { data: self } = useApiQuery<StudentSelfDto>(user ? '/api/students/me' : null);
  const { data: assignments, status, error, refetch } = useAssignments();

  return (
    <>
      <PageHeader title="Assignments" description="View and submit your assignments." />

      {status === 'loading' && (
        <div className="grid gap-4 sm:grid-cols-2">
          {Array.from({ length: 4 }).map((_, i) => <SkeletonCard key={i} />)}
        </div>
      )}

      {status === 'error' && <ErrorState description={error} onRetry={refetch} />}

      {status === 'success' && (!assignments || assignments.length === 0) && (
        <EmptyState icon="FileText" title="No assignments found" />
      )}

      {status === 'success' && assignments && assignments.length > 0 && self && (
        <div className="grid gap-4 sm:grid-cols-2">
          {assignments.map((a) => (
            <AssignmentCard key={a.id} assignment={a} studentId={self.id} onSubmitted={refetch} />
          ))}
        </div>
      )}
    </>
  );
}
