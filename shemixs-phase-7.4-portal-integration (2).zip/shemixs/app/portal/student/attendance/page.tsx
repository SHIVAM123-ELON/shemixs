'use client';

import * as Icons from 'lucide-react';
import { PageHeader } from '@/components/portal/shared/page-header';
import { SectionCard } from '@/components/portal/shared/section-card';
import { StatCard } from '@/components/portal/shared/stat-card';
import { StatusBadge } from '@/components/portal/shared/status-badge';
import { SkeletonCard } from '@/components/portal/shared/skeletons';
import { EmptyState } from '@/components/portal/shared/empty-state';
import { ErrorState } from '@/components/portal/shared/error-state';
import { cn } from '@/lib/utils';
import { useAuth } from '@/lib/api/use-auth';
import { useApiQuery } from '@/lib/api/use-api-query';
import { useStudentAttendanceHistory, useStudentAttendanceReport } from '@/lib/api/use-attendance';

interface StudentSelfDto {
  id: string;
}

const statusVariant = {
  PRESENT: 'success',
  ABSENT: 'destructive',
  LATE: 'warning',
  HALF_DAY: 'warning',
  EXCUSED: 'info',
} as const;

const breakdownColor: Record<string, string> = {
  PRESENT: 'bg-success',
  ABSENT: 'bg-destructive',
  LATE: 'bg-warning',
  HALF_DAY: 'bg-warning',
  EXCUSED: 'bg-accent',
};

export default function AttendancePage() {
  const { user } = useAuth();
  const { data: self } = useApiQuery<StudentSelfDto>(user ? '/api/students/me' : null);

  const { data: history, status, error, refetch } = useStudentAttendanceHistory(self?.id ?? null);
  const { data: report } = useStudentAttendanceReport(self?.id ?? null);

  const total = Object.values(report ?? {}).reduce((sum, n) => sum + (n ?? 0), 0);
  const present = report?.PRESENT ?? 0;
  const absent = report?.ABSENT ?? 0;
  const overallPct = total > 0 ? Math.round((present / total) * 100) : 0;

  return (
    <>
      <PageHeader title="Attendance" description="Track your class attendance and identify trends." />

      {status === 'loading' && (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {Array.from({ length: 4 }).map((_, i) => <SkeletonCard key={i} />)}
        </div>
      )}

      {status === 'error' && <ErrorState description={error} onRetry={refetch} />}

      {status === 'success' && (
        <>
          <div className="mb-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            <StatCard label="Overall Attendance" value={`${overallPct}%`} icon="CalendarCheck" accent="success" />
            <StatCard label="Classes Attended" value={present} icon="CheckCircle2" accent="primary" />
            <StatCard label="Classes Missed" value={absent} icon="XCircle" accent="destructive" />
            <StatCard label="Total Classes" value={total} icon="CalendarDays" accent="secondary" />
          </div>

          {report && total > 0 && (
            <div className="mb-6">
              <SectionCard title="Breakdown" icon={<Icons.PieChart className="h-4 w-4 text-primary" />}>
                <div className="space-y-3">
                  {Object.entries(report).map(([key, value]) => (
                    <div key={key}>
                      <div className="mb-1 flex items-center justify-between text-sm">
                        <span className="capitalize text-muted-foreground">{key.replace('_', ' ').toLowerCase()}</span>
                        <span className="font-semibold text-foreground">{value}</span>
                      </div>
                      <div className="h-2 overflow-hidden rounded-full bg-muted">
                        <div className={cn('h-full rounded-full', breakdownColor[key])} style={{ width: `${((value ?? 0) / total) * 100}%` }} />
                      </div>
                    </div>
                  ))}
                </div>
              </SectionCard>
            </div>
          )}

          <SectionCard title="Attendance Records" icon={<Icons.CalendarDays className="h-4 w-4 text-accent" />}>
            {!history || history.length === 0 ? (
              <EmptyState icon="CalendarX" title="No attendance records yet" />
            ) : (
              <div className="space-y-2">
                {history.map((record) => (
                  <div key={record.id} className="flex items-center gap-4 rounded-lg border border-border p-3">
                    <div className="flex w-12 shrink-0 flex-col items-center">
                      <span className="text-sm font-bold text-foreground">{new Date(record.date).getDate()}</span>
                      <span className="text-xs text-muted-foreground">{new Date(record.date).toLocaleDateString('en-US', { month: 'short' })}</span>
                    </div>
                    <div className="h-8 w-px bg-border" />
                    <div className="min-w-0 flex-1">
                      <p className="text-sm font-medium text-foreground">{record.remarks ?? 'No remarks'}</p>
                    </div>
                    <StatusBadge status={record.status.replace('_', ' ').toLowerCase()} variant={statusVariant[record.status]} />
                  </div>
                ))}
              </div>
            )}
          </SectionCard>
        </>
      )}
    </>
  );
}
