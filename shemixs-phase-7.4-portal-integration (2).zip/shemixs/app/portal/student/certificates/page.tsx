'use client';

import * as Icons from 'lucide-react';
import { PageHeader } from '@/components/portal/shared/page-header';
import { StatusBadge } from '@/components/portal/shared/status-badge';
import { EmptyState } from '@/components/portal/shared/empty-state';
import { ErrorState } from '@/components/portal/shared/error-state';
import { SkeletonCard } from '@/components/portal/shared/skeletons';
import { useAuth } from '@/lib/api/use-auth';
import { useApiQuery } from '@/lib/api/use-api-query';
import { useStudentCertificates } from '@/lib/api/use-certificates';

interface StudentSelfDto {
  id: string;
}

function formatDate(dateStr: string) {
  return new Date(dateStr).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
}

export default function CertificatesPage() {
  const { user } = useAuth();
  const { data: self } = useApiQuery<StudentSelfDto>(user ? '/api/students/me' : null);
  const { data: certificates, status, error, refetch } = useStudentCertificates(self?.id ?? null);

  return (
    <>
      <PageHeader title="Certificates" description="View and verify your issued certificates." />

      {status === 'loading' && (
        <div className="grid gap-4 sm:grid-cols-2">
          {Array.from({ length: 3 }).map((_, i) => <SkeletonCard key={i} />)}
        </div>
      )}

      {status === 'error' && <ErrorState description={error} onRetry={refetch} />}

      {status === 'success' && (!certificates || certificates.length === 0) && (
        <EmptyState icon="Award" title="No certificates yet" description="Certificates you earn will appear here." />
      )}

      {status === 'success' && certificates && certificates.length > 0 && (
        <div className="grid gap-4 sm:grid-cols-2">
          {certificates.map((cert) => (
            <div key={cert.id} className="rounded-xl border border-border bg-card p-5">
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-lg bg-warning/10 text-warning">
                    <Icons.Award className="h-5 w-5" />
                  </div>
                  <div>
                    <h3 className="text-sm font-semibold text-foreground">{cert.title}</h3>
                    <p className="text-xs text-muted-foreground">{cert.type}</p>
                  </div>
                </div>
                <StatusBadge status={cert.status.toLowerCase()} variant={cert.status === 'ISSUED' ? 'success' : 'destructive'} />
              </div>
              <div className="mt-4 flex items-center justify-between text-xs">
                <span className="text-muted-foreground">Issued {formatDate(cert.issuedAt)}</span>
                <code className="rounded bg-muted px-2 py-1 font-mono text-[10px] text-muted-foreground">{cert.verificationCode}</code>
              </div>
            </div>
          ))}
        </div>
      )}
    </>
  );
}
