'use client';

import * as Icons from 'lucide-react';
import { PageHeader } from '@/components/portal/shared/page-header';
import { SectionCard } from '@/components/portal/shared/section-card';
import { StatusBadge } from '@/components/portal/shared/status-badge';
import { EmptyState } from '@/components/portal/shared/empty-state';
import { ErrorState } from '@/components/portal/shared/error-state';
import { SkeletonCard } from '@/components/portal/shared/skeletons';
import { useHomework } from '@/lib/api/use-homework';

function formatDate(dateStr: string) {
  return new Date(dateStr).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
}

function isOverdue(dueDate: string) {
  return new Date(dueDate) < new Date();
}

export default function HomeworkPage() {
  const { data: homework, status, error, refetch } = useHomework();

  return (
    <>
      <PageHeader title="Homework" description="View and track your homework assignments." />

      {status === 'loading' && (
        <div className="grid gap-4 sm:grid-cols-2">
          {Array.from({ length: 4 }).map((_, i) => <SkeletonCard key={i} />)}
        </div>
      )}

      {status === 'error' && <ErrorState description={error} onRetry={refetch} />}

      {status === 'success' && (!homework || homework.length === 0) && (
        <EmptyState icon="Pencil" title="No homework found" description="You're all caught up!" />
      )}

      {status === 'success' && homework && homework.length > 0 && (
        <div className="grid gap-4 sm:grid-cols-2">
          {homework.map((hw) => (
            <SectionCard key={hw.id} title={hw.title} icon={<Icons.Pencil className="h-4 w-4 text-primary" />}>
              <div className="space-y-3">
                {hw.description && <p className="text-sm text-muted-foreground">{hw.description}</p>}
                <div className="flex flex-wrap items-center gap-2 text-xs text-muted-foreground">
                  {hw.subject && (
                    <span className="rounded-full bg-muted px-2 py-1">{hw.subject.name}</span>
                  )}
                  {hw.teacher && <span>{hw.teacher.user.fullName}</span>}
                </div>
                <div className="flex items-center justify-between">
                  <span className="flex items-center gap-1.5 text-xs text-muted-foreground">
                    <Icons.CalendarDays className="h-3.5 w-3.5" />
                    Due {formatDate(hw.dueDate)}
                  </span>
                  <StatusBadge
                    status={isOverdue(hw.dueDate) ? 'overdue' : 'upcoming'}
                    variant={isOverdue(hw.dueDate) ? 'destructive' : 'success'}
                  />
                </div>
                {hw.attachmentUrls.length > 0 && (
                  <a href={hw.attachmentUrls[0]} target="_blank" rel="noreferrer" className="inline-flex items-center gap-1.5 text-xs font-medium text-primary hover:underline">
                    <Icons.Paperclip className="h-3.5 w-3.5" />
                    View attachment
                  </a>
                )}
              </div>
            </SectionCard>
          ))}
        </div>
      )}
    </>
  );
}
