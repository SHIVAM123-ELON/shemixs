'use client';

import * as Icons from 'lucide-react';
import { PageHeader } from '@/components/portal/shared/page-header';
import { SectionCard } from '@/components/portal/shared/section-card';
import { StatusBadge } from '@/components/portal/shared/status-badge';
import { EmptyState } from '@/components/portal/shared/empty-state';
import { ErrorState } from '@/components/portal/shared/error-state';
import { SkeletonCard } from '@/components/portal/shared/skeletons';
import { useTests } from '@/lib/api/use-tests';

const typeVariant = {
  MCQ: 'info',
  SUBJECTIVE: 'default',
  PRACTICE: 'muted',
  MOCK: 'warning',
} as const;

function formatDateTime(dateStr: string | null) {
  if (!dateStr) return 'Not scheduled';
  return new Date(dateStr).toLocaleString('en-US', { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' });
}

export default function TestsPage() {
  const { data: tests, status, error, refetch } = useTests();

  return (
    <>
      <PageHeader title="Online Tests" description="Upcoming, practice, and mock tests." />

      {status === 'loading' && (
        <div className="grid gap-4 sm:grid-cols-2">
          {Array.from({ length: 4 }).map((_, i) => <SkeletonCard key={i} />)}
        </div>
      )}

      {status === 'error' && <ErrorState description={error} onRetry={refetch} />}

      {status === 'success' && (!tests || tests.length === 0) && (
        <EmptyState icon="ClipboardCheck" title="No tests available" description="Check back later for upcoming tests." />
      )}

      {status === 'success' && tests && tests.length > 0 && (
        <div className="grid gap-4 sm:grid-cols-2">
          {tests.map((test) => (
            <SectionCard key={test.id} title={test.title} icon={<Icons.ClipboardCheck className="h-4 w-4 text-primary" />}>
              <div className="space-y-3">
                {test.description && <p className="text-sm text-muted-foreground">{test.description}</p>}
                <div className="flex flex-wrap items-center gap-2">
                  <StatusBadge status={test.type.toLowerCase()} variant={typeVariant[test.type]} />
                  <span className="rounded-full bg-muted px-2 py-1 text-xs text-muted-foreground">{test.mode}</span>
                  {test.subject && <span className="rounded-full bg-muted px-2 py-1 text-xs text-muted-foreground">{test.subject.name}</span>}
                </div>
                <div className="flex items-center justify-between text-xs text-muted-foreground">
                  <span className="flex items-center gap-1.5">
                    <Icons.Clock className="h-3.5 w-3.5" />
                    {formatDateTime(test.scheduledAt)}
                  </span>
                  <span>{test.maxMarks} marks{test.durationMinutes ? ` · ${test.durationMinutes} min` : ''}</span>
                </div>
              </div>
            </SectionCard>
          ))}
        </div>
      )}
    </>
  );
}
