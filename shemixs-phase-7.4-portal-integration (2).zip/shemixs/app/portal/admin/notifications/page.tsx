'use client';

import { useState } from 'react';
import * as Icons from 'lucide-react';
import { PageHeader } from '@/components/portal/shared/page-header';
import { EmptyState } from '@/components/portal/shared/empty-state';
import { ErrorState } from '@/components/portal/shared/error-state';
import { SkeletonRow } from '@/components/portal/shared/skeletons';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import { useNotifications, useMarkNotificationRead, useMarkAllNotificationsRead } from '@/lib/api/use-notifications';

const filters = ['all', 'unread'] as const;

function formatTimestamp(ts: string) {
  const date = new Date(ts);
  const diffMs = Date.now() - date.getTime();
  const diffH = Math.floor(diffMs / (1000 * 60 * 60));
  if (diffH < 1) return 'Just now';
  if (diffH < 24) return `${diffH}h ago`;
  return `${Math.floor(diffH / 24)}d ago`;
}

export default function NotificationsPage() {
  const [filter, setFilter] = useState<(typeof filters)[number]>('all');
  const { data: notifications, status, error, refetch, unreadCount } = useNotifications();
  const markRead = useMarkNotificationRead();
  const markAllRead = useMarkAllNotificationsRead();

  const filtered = (notifications ?? []).filter((n) => filter === 'all' || !n.readAt);

  async function handleMarkAllRead() {
    await markAllRead.mutate(undefined);
    refetch();
  }

  async function handleMarkRead(id: string) {
    await markRead.mutate(id);
    refetch();
  }

  return (
    <>
      <PageHeader title="Notifications" description="Stay updated with classes, homework, payments, and more.">
        {unreadCount > 0 && (
          <Button size="sm" variant="outline" onClick={handleMarkAllRead} disabled={markAllRead.isLoading}>
            <Icons.CheckCheck className="mr-2 h-4 w-4" />
            Mark all as read
          </Button>
        )}
      </PageHeader>

      <div className="mb-6 flex gap-2">
        {filters.map((f) => (
          <button
            key={f}
            onClick={() => setFilter(f)}
            className={cn(
              'rounded-full px-3 py-1.5 text-xs font-medium capitalize transition-colors',
              filter === f ? 'bg-primary text-primary-foreground' : 'border border-border text-muted-foreground hover:bg-muted'
            )}
          >
            {f === 'unread' ? `Unread (${unreadCount})` : 'All'}
          </button>
        ))}
      </div>

      {status === 'loading' && (
        <div className="space-y-1 rounded-xl border border-border p-2">
          {Array.from({ length: 5 }).map((_, i) => <SkeletonRow key={i} />)}
        </div>
      )}

      {status === 'error' && <ErrorState description={error} onRetry={refetch} />}

      {status === 'success' && filtered.length === 0 && (
        <EmptyState icon="BellOff" title="No notifications" description="You're all caught up." />
      )}

      {status === 'success' && filtered.length > 0 && (
        <div className="divide-y divide-border rounded-xl border border-border">
          {filtered.map((n) => (
            <div
              key={n.id}
              className={cn('flex items-start gap-3 p-4 transition-colors', !n.readAt && 'bg-primary/5')}
            >
              <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-accent/10 text-accent">
                <Icons.Bell className="h-4 w-4" />
              </div>
              <div className="min-w-0 flex-1">
                <div className="flex items-center justify-between gap-2">
                  <p className="text-sm font-medium text-foreground">{n.title}</p>
                  <span className="shrink-0 text-xs text-muted-foreground">{formatTimestamp(n.createdAt)}</span>
                </div>
                <p className="mt-0.5 text-sm text-muted-foreground">{n.body}</p>
              </div>
              {!n.readAt && (
                <button
                  onClick={() => handleMarkRead(n.id)}
                  className="mt-1 h-2 w-2 shrink-0 rounded-full bg-primary"
                  aria-label="Mark as read"
                  title="Mark as read"
                />
              )}
            </div>
          ))}
        </div>
      )}
    </>
  );
}
