'use client';

import { useApiQuery } from './use-api-query';
import { useApiMutation } from './use-api-mutation';
import type { PaginationMeta } from './use-students';

export interface AssignmentDto {
  id: string;
  title: string;
  description: string | null;
  dueDate: string;
  maxMarks: number | null;
  status: 'DRAFT' | 'PUBLISHED';
  subject: { id: string; name: string; code: string } | null;
}

export function useAssignments(page = 1, pageSize = 20) {
  const result = useApiQuery<AssignmentDto[]>('/api/assignments', { page, pageSize, sortBy: 'dueDate', sortOrder: 'asc' });
  return { ...result, pagination: result.meta?.pagination as PaginationMeta | undefined };
}

export interface SubmitAssignmentInput {
  studentId: string;
  contentUrl?: string;
}

export function useSubmitAssignment(assignmentId: string) {
  return useApiMutation<SubmitAssignmentInput, unknown>('post', `/api/assignments/${assignmentId}/submit`);
}
