'use client';

import { useApiQuery } from './use-api-query';

export interface AttendanceRecordDto {
  id: string;
  date: string;
  status: 'PRESENT' | 'ABSENT' | 'LATE' | 'HALF_DAY' | 'EXCUSED';
  remarks: string | null;
}

export type AttendanceReportDto = Partial<Record<AttendanceRecordDto['status'], number>>;

export function useStudentAttendanceHistory(studentId: string | null) {
  return useApiQuery<AttendanceRecordDto[]>(studentId ? `/api/students/${studentId}/attendance` : null);
}

export function useStudentAttendanceReport(studentId: string | null) {
  return useApiQuery<AttendanceReportDto>(studentId ? `/api/students/${studentId}/attendance/report` : null);
}
