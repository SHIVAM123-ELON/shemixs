'use client';

import { useApiQuery } from './use-api-query';
import type { PaginationMeta } from './use-students';

export interface HomeworkDto {
  id: string;
  title: string;
  description: string | null;
  dueDate: string;
  status: 'DRAFT' | 'PUBLISHED';
  subject: { id: string; name: string; code: string } | null;
  teacher: { id: string; user: { fullName: string } } | null;
  attachmentUrls: string[];
}

export function useHomework(page = 1, pageSize = 20) {
  const result = useApiQuery<HomeworkDto[]>('/api/homework', { page, pageSize, sortBy: 'dueDate', sortOrder: 'asc' });
  return { ...result, pagination: result.meta?.pagination as PaginationMeta | undefined };
}
