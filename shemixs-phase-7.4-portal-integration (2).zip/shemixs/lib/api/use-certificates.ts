'use client';

import { useApiQuery } from './use-api-query';

export interface CertificateDto {
  id: string;
  type: string;
  title: string;
  verificationCode: string;
  status: 'ISSUED' | 'REVOKED';
  issuedAt: string;
}

export function useStudentCertificates(studentId: string | null) {
  return useApiQuery<CertificateDto[]>(studentId ? `/api/students/${studentId}/certificates` : null);
}
