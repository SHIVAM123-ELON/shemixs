'use client';

import { useApiQuery } from './use-api-query';
import type { PaginationMeta } from './use-students';

export interface TestDto {
  id: string;
  title: string;
  description: string | null;
  type: 'MCQ' | 'SUBJECTIVE' | 'PRACTICE' | 'MOCK';
  mode: 'ONLINE' | 'OFFLINE';
  status: 'DRAFT' | 'PUBLISHED';
  maxMarks: number;
  durationMinutes: number | null;
  scheduledAt: string | null;
  subject: { id: string; name: string } | null;
}

export function useTests(page = 1, pageSize = 20) {
  const result = useApiQuery<TestDto[]>('/api/tests', { page, pageSize, sortBy: 'scheduledAt', sortOrder: 'asc' });
  return { ...result, pagination: result.meta?.pagination as PaginationMeta | undefined };
}
