'use client';

import { useApiQuery } from './use-api-query';

export interface ResultDto {
  id: string;
  marksObtained: number | null;
  grade: string | null;
  rank: number | null;
  status: 'DRAFT' | 'PUBLISHED';
  test: { id: string; title: string; maxMarks: number };
}

export function useStudentResults(studentId: string | null) {
  return useApiQuery<ResultDto[]>(studentId ? `/api/students/${studentId}/results` : null);
}
