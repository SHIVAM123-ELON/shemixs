'use client';

import { useApiQuery } from './use-api-query';
import { useApiMutation } from './use-api-mutation';
import type { PaginationMeta } from './use-students';

export interface NotificationDto {
  id: string;
  channel: 'IN_APP' | 'EMAIL' | 'WHATSAPP';
  status: 'QUEUED' | 'SENT' | 'FAILED' | 'READ';
  title: string;
  body: string;
  data: Record<string, unknown> | null;
  createdAt: string;
  readAt: string | null;
}

export function useNotifications(page = 1, pageSize = 20) {
  const result = useApiQuery<NotificationDto[]>('/api/notifications', { channel: 'IN_APP', page, pageSize });
  return {
    ...result,
    pagination: result.meta?.pagination as PaginationMeta | undefined,
    unreadCount: (result.meta?.unreadCount as number | undefined) ?? 0,
  };
}

export function useMarkNotificationRead() {
  return useApiMutation<string, NotificationDto>('post', (id) => `/api/notifications/${id}/read`);
}

export function useMarkAllNotificationsRead() {
  return useApiMutation<undefined, null>('post', '/api/notifications/read-all');
}
