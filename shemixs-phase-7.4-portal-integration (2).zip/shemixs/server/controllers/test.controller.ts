import type { NextRequest } from 'next/server';
import { authorize, parseSearchParams } from './base.controller';
import { testService } from '../services/test.service';
import { moduleRoles } from '../constants/roles';
import { apiPaginated, apiSuccess } from '../lib/api-response';
import { createTestSchema, updateTestSchema, testListQuerySchema } from '../validators/test.validators';
import { idParamSchema } from '../validators/common.validators';
import { ForbiddenError } from '../lib/errors';

const ROLES = moduleRoles('tests');
const READ_ROLES = [...ROLES, 'STUDENT', 'PARENT'] as const;

export const testController = {
  async list(req: NextRequest) {
    const ctx = await authorize(req, [...READ_ROLES]);
    const query = testListQuerySchema.parse(parseSearchParams(req));
    const isStaff = (ROLES as readonly string[]).includes(ctx.role);
    const { items, pagination } = await testService.list(isStaff ? query : { ...query, status: 'PUBLISHED' });
    return apiPaginated(items, pagination);
  },

  async getById(req: NextRequest, params: { id: string }) {
    const ctx = await authorize(req, [...READ_ROLES]);
    const { id } = idParamSchema.parse(params);
    const test = await testService.getById(id);
    const isStaff = (ROLES as readonly string[]).includes(ctx.role);
    if (!isStaff && test.status !== 'PUBLISHED') throw new ForbiddenError();

    if (!isStaff) {
      // Never expose correct answers to students before they submit —
      // there is no "attempt" concept yet (Known Gap, see Phase 7.4
      // docs), so this is the only guard preventing answer leakage today.
      return apiSuccess({
        ...test,
        questions: test.questions.map(({ correctAnswer: _correctAnswer, ...q }) => q),
      });
    }

    return apiSuccess(test);
  },

  async create(req: NextRequest) {
    const ctx = await authorize(req, ROLES);
    const body = createTestSchema.parse(await req.json());
    const test = await testService.create(body, ctx);
    return apiSuccess(test, { status: 201, message: 'Test created successfully' });
  },

  async update(req: NextRequest, params: { id: string }) {
    const ctx = await authorize(req, ROLES);
    const { id } = idParamSchema.parse(params);
    const body = updateTestSchema.parse(await req.json());
    const test = await testService.update(id, body, ctx);
    return apiSuccess(test, { message: 'Test updated successfully' });
  },

  async publish(req: NextRequest, params: { id: string }) {
    const ctx = await authorize(req, ROLES);
    const { id } = idParamSchema.parse(params);
    const test = await testService.publish(id, ctx);
    return apiSuccess(test, { message: 'Test published' });
  },

  async unpublish(req: NextRequest, params: { id: string }) {
    const ctx = await authorize(req, ROLES);
    const { id } = idParamSchema.parse(params);
    const test = await testService.unpublish(id, ctx);
    return apiSuccess(test, { message: 'Test moved to draft' });
  },

  async remove(req: NextRequest, params: { id: string }) {
    const ctx = await authorize(req, ROLES);
    const { id } = idParamSchema.parse(params);
    await testService.softDelete(id, ctx);
    return apiSuccess(null, { message: 'Test deleted successfully' });
  },
};
