import type { NextRequest } from 'next/server';
import { authorize, parseSearchParams } from './base.controller';
import { assertOwnsStudent } from './ownership';
import { resultService } from '../services/result.service';
import { moduleRoles } from '../constants/roles';
import { apiSuccess } from '../lib/api-response';
import {
  createResultSchema,
  updateResultSchema,
  bulkCreateResultsSchema,
  resultListQuerySchema,
} from '../validators/result.validators';
import { idParamSchema } from '../validators/common.validators';

const ROLES = moduleRoles('results');
const READ_ROLES = [...ROLES, 'STUDENT', 'PARENT'] as const;

export const resultController = {
  async list(req: NextRequest) {
    await authorize(req, ROLES);
    const query = resultListQuerySchema.parse(parseSearchParams(req));
    const results = await resultService.list(query);
    return apiSuccess(results);
  },

  async getById(req: NextRequest, params: { id: string }) {
    await authorize(req, ROLES);
    const { id } = idParamSchema.parse(params);
    const result = await resultService.getById(id);
    return apiSuccess(result);
  },

  async create(req: NextRequest) {
    const ctx = await authorize(req, ROLES);
    const body = createResultSchema.parse(await req.json());
    const result = await resultService.create(body, ctx);
    return apiSuccess(result, { status: 201, message: 'Result recorded successfully' });
  },

  async bulkCreate(req: NextRequest) {
    const ctx = await authorize(req, ROLES);
    const body = bulkCreateResultsSchema.parse(await req.json());
    const results = await resultService.bulkCreate(body, ctx);
    return apiSuccess(results, { status: 201, message: `Results recorded for ${body.entries.length} student(s)` });
  },

  async update(req: NextRequest, params: { id: string }) {
    const ctx = await authorize(req, ROLES);
    const { id } = idParamSchema.parse(params);
    const body = updateResultSchema.parse(await req.json());
    const result = await resultService.update(id, body, ctx);
    return apiSuccess(result, { message: 'Result updated successfully' });
  },

  async publishForTest(req: NextRequest, params: { id: string }) {
    const ctx = await authorize(req, ROLES);
    const { id } = idParamSchema.parse(params);
    const results = await resultService.publishForTest(id, ctx);
    return apiSuccess(results, { message: 'Results published' });
  },

  async studentHistory(req: NextRequest, params: { id: string }) {
    const ctx = await authorize(req, [...READ_ROLES]);
    const { id } = idParamSchema.parse(params);
    await assertOwnsStudent(ctx, id);
    const history = await resultService.studentHistory(id);
    return apiSuccess(history);
  },
};
