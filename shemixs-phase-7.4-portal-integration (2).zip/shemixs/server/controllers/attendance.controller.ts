import type { NextRequest } from 'next/server';
import { authorize, parseSearchParams } from './base.controller';
import { assertOwnsStudent } from './ownership';
import { attendanceService } from '../services/attendance.service';
import { moduleRoles } from '../constants/roles';
import { apiSuccess } from '../lib/api-response';
import {
  markStudentAttendanceSchema,
  markBulkStudentAttendanceSchema,
  markTeacherAttendanceSchema,
  updateAttendanceSchema,
  attendanceHistoryQuerySchema,
} from '../validators/attendance.validators';
import { idParamSchema } from '../validators/common.validators';

const ROLES = moduleRoles('attendance');
// Marking/updating attendance stays staff-only (ROLES above). Reading
// one's own attendance additionally allows STUDENT/PARENT — gated by
// assertOwnsStudent, not just role membership, so a student can't
// pass a different student's id and read their attendance instead.
const READ_ROLES = [...ROLES, 'STUDENT', 'PARENT'] as const;

export const attendanceController = {
  async markStudent(req: NextRequest) {
    const ctx = await authorize(req, ROLES);
    const body = markStudentAttendanceSchema.parse(await req.json());
    const result = await attendanceService.markStudent(body, ctx);
    return apiSuccess(result, { status: 201, message: 'Attendance marked' });
  },

  async markBulkStudent(req: NextRequest) {
    const ctx = await authorize(req, ROLES);
    const body = markBulkStudentAttendanceSchema.parse(await req.json());
    const result = await attendanceService.markBulkStudent(body, ctx);
    return apiSuccess(result, { status: 201, message: `Attendance marked for ${result.length} student(s)` });
  },

  async updateStudent(req: NextRequest, params: { id: string }) {
    const ctx = await authorize(req, ROLES);
    const { id } = idParamSchema.parse(params);
    const body = updateAttendanceSchema.parse(await req.json());
    const result = await attendanceService.updateStudent(id, body, ctx);
    return apiSuccess(result, { message: 'Attendance updated' });
  },

  async studentHistory(req: NextRequest, params: { id: string }) {
    const ctx = await authorize(req, [...READ_ROLES]);
    const { id } = idParamSchema.parse(params);
    await assertOwnsStudent(ctx, id);
    const query = attendanceHistoryQuerySchema.parse(parseSearchParams(req));
    const history = await attendanceService.studentHistory(id, query);
    return apiSuccess(history);
  },

  async studentReport(req: NextRequest, params: { id: string }) {
    const ctx = await authorize(req, [...READ_ROLES]);
    const { id } = idParamSchema.parse(params);
    await assertOwnsStudent(ctx, id);
    const report = await attendanceService.studentReport(id);
    return apiSuccess(report);
  },

  async markTeacher(req: NextRequest) {
    const ctx = await authorize(req, ROLES);
    const body = markTeacherAttendanceSchema.parse(await req.json());
    const result = await attendanceService.markTeacher(body, ctx);
    return apiSuccess(result, { status: 201, message: 'Attendance marked' });
  },

  async updateTeacher(req: NextRequest, params: { id: string }) {
    const ctx = await authorize(req, ROLES);
    const { id } = idParamSchema.parse(params);
    const body = updateAttendanceSchema.parse(await req.json());
    const result = await attendanceService.updateTeacher(id, body, ctx);
    return apiSuccess(result, { message: 'Attendance updated' });
  },

  async teacherHistory(req: NextRequest, params: { id: string }) {
    await authorize(req, ROLES);
    const { id } = idParamSchema.parse(params);
    const query = attendanceHistoryQuerySchema.parse(parseSearchParams(req));
    const history = await attendanceService.teacherHistory(id, query);
    return apiSuccess(history);
  },
};
