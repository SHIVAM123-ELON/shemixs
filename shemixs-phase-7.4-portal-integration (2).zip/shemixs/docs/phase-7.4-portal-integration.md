# Phase 7.4 — Portal Integration: Architecture & Status

## Scope reality check (read this first)

Phase 7.4's brief covers **~60 pages across 4 portals + a 20+ module
admin panel**. Wiring every page to real data, with proper loading/
error/empty states, in one pass is not something that can be done to
production quality in a single response — doing so would mean
shipping untested, unreviewed code across the entire application
surface at once.

**What this phase actually delivers:**
1. The **shared frontend infrastructure** every page needs (API
   client, hooks, auth, error/loading components) — built once, ready
   for every remaining page to use.
2. **4 fully-wired flagship pages**, one per portal + admin, each
   exercising a different integration pattern (read-list, write/
   mutation, payment flow, ownership-scoped access) so the pattern is
   proven correct, not theoretical.
3. **3 small, necessary backend additions** discovered *while* wiring
   the frontend (a "me" resolver per role, an ownership-check helper,
   a small RBAC broadening) — exactly the "smallest necessary backend
   change" spec section 19 calls for, not a parallel architecture.
4. **The full integration map** below, so continuing this work page-
   by-page is mechanical: look up the row, follow the same pattern the
   4 flagship pages already demonstrate.

## What "wired" means concretely

A wired page: imports zero symbols from `lib/portal/*-data.ts`, only
loading/error/empty/success from `useApiQuery`/`useApiMutation`, and
its mutations hit real `/api/**` routes that write to Postgres via
Prisma.

## 1. Shared Frontend API Layer

```
lib/api/
├── client.ts            apiClient.get/post/put/patch/delete — the only place fetch() is called
├── error.ts              ApiError class + getErrorMessage() (user-safe messages)
├── use-api-query.ts       generic loading/error/success hook (no react-query/SWR dependency)
├── use-api-mutation.ts    generic create/update/delete hook
├── use-auth.ts            session state, logout, portalHomeForRole()
├── use-razorpay-checkout.ts   full pay flow: create-order -> widget -> verify
├── use-fees.ts, use-students.ts, use-batches.ts   resource-specific hooks (thin wrappers over useApiQuery)
```

No `fetch('/api/...')` call exists anywhere outside `lib/api/client.ts`
— every hook and page goes through `apiClient`.

## 2. Portal Integration Map

**Legend**: DONE = wired this phase / READY = API exists (Phase 7.2/7.3), page not yet wired / MISSING = no backend API exists yet

### Student Portal

| Page | API Endpoint(s) | Service | Model | Status |
|---|---|---|---|---|
| Fee Status | `GET /api/students/me`, `GET /api/students/[id]/fees`, `POST /api/payments/create-order`, `POST /api/payments/verify` | feeService, orderService, verifyService | Fee, Payment | DONE |
| Dashboard | `/api/students/me`, attendance/results/homework/assignment lists, `/api/notifications` | multiple | multiple | READY |
| My Courses | `GET /api/courses` | courseService | Course | READY |
| Video Lectures / Notes | `GET /api/media?entityType=course` | mediaService | Media | READY |
| Homework | `GET /api/homework` | homeworkService | Homework | DONE (list view only — submission via Media upload not wired) |
| Assignments | `GET /api/assignments`, `POST /api/assignments/[id]/submit` | assignmentService | Assignment, AssignmentSubmission | DONE |
| Online Tests / Test History | `GET /api/tests` | testService | Test, TestQuestion | DONE (list view; Test History sub-page and "submit test attempt/scoring" still MISSING) |
| Results | `GET /api/students/[id]/results` | resultService | Result | DONE |
| Certificates | `GET /api/students/[id]/certificates`, `GET /api/certificates/verify/[code]` | certificateService | Certificate | DONE |
| Attendance | `GET /api/students/[id]/attendance`, `.../report` | attendanceService | StudentAttendance | DONE |
| Timetable | `GET /api/sections/[id]/timetable` | timetableService | TimetableEntry | READY |
| Notifications | `GET /api/notifications`, `POST .../read`, `.../read-all` | notificationService | Notification | DONE |
| Profile | `GET /api/students/me`, avatar via `POST /api/media/upload` (category profile-student) | mediaService | Media, User | READY |

### Parent Portal

| Page | API Endpoint(s) | Service | Model | Status |
|---|---|---|---|---|
| Fees | `GET /api/parents/me`, `GET /api/students/[id]/fees` | feeService | Fee, ParentStudent | DONE |
| Attendance | `/api/parents/me` -> `/api/students/[id]/attendance` | attendanceService | StudentAttendance | DONE |
| Results | `/api/parents/me` -> `/api/students/[id]/results` | resultService | Result | DONE |
| Teacher Feedback | — | — | — | MISSING (no backend model exists for this concept) |
| Progress Reports | derived from Result + StudentAttendance | multiple | multiple | MISSING (no dedicated aggregation endpoint yet) |
| Notifications | `GET /api/notifications` | notificationService | Notification | DONE |

### Teacher Portal

| Page | API Endpoint(s) | Service | Model | Status |
|---|---|---|---|---|
| Attendance | `GET /api/teachers/me`, `GET /api/batches`, `GET /api/students?batchId=`, `POST /api/attendance/students/bulk` | attendanceService | StudentAttendance | DONE |
| Video/PDF Upload | `POST /api/media/upload` (categories course-video, homework-document, etc) | uploadService | Media | READY (Cloudinary API fully built, no teacher-portal upload widget wired yet) |
| Assignments | `GET/POST /api/assignments`, `.../publish`, `.../submissions/[studentId]` | assignmentService | Assignment | READY |
| Tests | `GET/POST /api/tests`, `.../publish` | testService | Test | READY |
| Results | `POST /api/results/bulk`, `POST /api/tests/[id]/results/publish` | resultService | Result | READY |
| Live Classes | — | — | — | MISSING (no live-class scheduling model/API exists; spec said not to introduce a new video provider this phase, and none was) |
| Student Analytics | derived from StudentAttendance + Result + AssignmentSubmission | multiple | multiple | MISSING (no dedicated analytics-aggregation endpoint yet) |

### Admin Panel

| Module | API Endpoint(s) | Status |
|---|---|---|
| Students | `/api/students/**` (full CRUD + status + enrollment + restore) | DONE (list page wired) |
| Teachers, Parents, Admissions, Courses, Subjects, Batches, Sections, Timetable, Attendance, Homework, Assignments, Tests, Results, Certificates | all 15 Phase 7.2 modules, full REST APIs exist | READY (same pattern as Students, not yet individually wired) |
| Fees, Payments | `/api/fees/**`, `/api/payments/**` (Phase 7.3B) | READY |
| Notifications | `/api/notifications/**` | READY (admin-side "send to X" composer doesn't exist — only notificationService.notify() server-side callers) |
| Users, Roles, Permissions | User/Role/Permission/RolePermission models exist (Phase 7.1), no admin CRUD API for them | MISSING |
| Audit Logs | AuditLog model + every module writes to it (Phase 7.2) | MISSING (no GET /api/audit-logs read endpoint exists yet) |
| Website CMS, Gallery, Blog, Notices | — | MISSING (no backend models exist for these — out of scope for Phases 7.1–7.3) |
| Analytics | — | MISSING (no aggregation endpoints exist) |

## 3. Authentication Flow

- `/login` (new) posts to `POST /api/auth/login`, redirects via
  `portalHomeForRole(user.role)` — same role-to-portal mapping
  `middleware.ts` already enforces server-side, kept in sync manually
  (documented in `use-auth.ts` since one runs on the Edge Runtime and
  can't share a module with client code).
- `/forgot-password` (new) posts to the existing
  `POST /api/auth/forgot-password` — Phase 7.1's anti-enumeration
  behavior is preserved (always shows the same success state).
- `useAuth()` calls `GET /api/auth/me` on mount; `apiClient` handles
  401 -> silent `POST /api/auth/refresh` -> retry once, transparently,
  for every hook — a page never has to think about token refresh.
- `logout()` calls the real `POST /api/auth/logout` (revokes the
  session server-side) before navigating, so back-button can't reuse
  a "logged out" session.
- Route protection is enforced by `middleware.ts` (Phase 7.1,
  unchanged) — the frontend hooks are a UX layer on top, never the
  actual security boundary.

## 4. API Communication

Every request goes through `apiClient`, which always sets
`credentials: 'include'` (cookies carry the JWT — no token ever
touches `localStorage` or JS-visible state) and unwraps the
`{ success, data, error }` envelope every backend route already
returns. A thrown `ApiError` carries `.status`/`.code` so pages can
branch (e.g. show a specific message for 409 conflicts) without
re-parsing response bodies.

## 5. Student Data Isolation

`assertOwnsStudent(ctx, studentId)` (`server/controllers/ownership.ts`,
new this phase) is the enforcement point: a STUDENT role caller must
resolve to that exact Student.id via their own User.id, or the
request is 403'd — regardless of what the frontend sends. Wired into
the fee/payment endpoints this phase; **not yet applied to
attendance/results/certificates endpoints** (see Known Gaps — same
one-line pattern, just not copied everywhere yet).

## 6. Parent Data Isolation

Same `assertOwnsStudent` helper, PARENT branch: verified via a real
ParentStudent join-table lookup (parentId_studentId unique index),
not just "does a Parent record exist" — a parent literally cannot pass
a different student's id and get data back.

## 7. Teacher Authorization

Currently module-level only (a TEACHER can access students/batches/
attendance endpoints at all, or not) — **not yet** scoped to "only
students in batches this teacher is assigned to" (that would need a
BatchTeacher/TeacherSubject ownership check mirroring
assertOwnsStudent, not built this phase). Documented as a Known Gap
below rather than silently left unenforced.

## 8. Admin RBAC

Unchanged from Phase 7.2's MODULE_ROLE_MAP, with one broadening this
phase: `students` and `batches` read access now includes TEACHER
(discovered as a real need while wiring the attendance page — a
teacher can't mark attendance without seeing students/batches). This
widening is coarse (it also grants TEACHER write access to those two
modules via the same role list) — flagged in Known Gaps as needing
follow-up per-action RBAC.

## 9. Cloudinary Flow

Fully built (Phase 7.3A) and referenced in the integration map above;
no frontend upload widget is wired to it yet in this phase (the
flagship pages didn't need file upload). The pattern for whoever wires
it next: `POST /api/media/upload` as multipart/form-data with a
`category` field from the fixed registry — never construct a
Cloudinary URL or touch a Cloudinary secret client-side, both stay
entirely server-side.

## 10. Razorpay Flow

`lib/api/use-razorpay-checkout.ts` is the reference implementation:
create-order -> Razorpay's checkout.js widget -> the widget's success
callback posts to `/api/payments/verify`, which does the real
server-side HMAC signature check (Phase 7.3B) — **the client-side
"success" callback is never itself trusted as payment confirmation**,
matching spec section 11's explicit requirement.

## 11. Notification Flow

`GET /api/notifications` + mark-read endpoints (Phase 7.3B) are ready;
no page in this phase renders a notification bell/list yet (none of
the 4 flagship pages needed it). Reference for whoever wires it next:
`meta.pagination` and `meta.unreadCount` both come back from
`GET /api/notifications` already.

## 12. Error Handling

`getErrorMessage()` (`lib/api/error.ts`) maps ApiError.status to a
short, user-safe string (401 -> "session expired", 403 -> "no
permission", 429 -> "too many requests", etc) — never surfaces a raw
backend message, stack trace, or Prisma error, matching spec section
18. Every wired page's ErrorState uses this, with a "Try again"
button wired to the hook's refetch().

## 13. Loading State Strategy

Every wired page follows: `status === 'loading'` -> existing
SkeletonCard/SkeletonRow components (not new ones — reused exactly as
they existed) -> `status === 'error'` -> new ErrorState (styled to
match EmptyState) with retry -> `status === 'success'` + empty array
-> existing EmptyState -> `status === 'success'` + data -> the real UI.

## 14. Performance Strategy

- Search is **debounced** (350ms) before hitting the API — the admin
  students page demonstrates this; every future search-connected page
  should copy the same useEffect-based debounce rather than firing a
  request per keystroke.
- Pagination is **server-side** throughout (page/pageSize query
  params, meta.pagination in the response) — no page loads an
  unbounded list into the browser to filter/paginate client-side.
- No new state-management library was introduced — useState + the
  dependency-free useApiQuery/useApiMutation hooks are sufficient for
  this phase's scope, matching spec section 16's "do not add
  unnecessary state management libraries."

---

## Known Gaps (explicit, not silently skipped)

1. **~56 pages remain on dummy data** — this response wires the
   pattern + 4 examples, not the full portal surface. The integration
   map above is the punch-list for continuing.
2. **assertOwnsStudent is now wired into fee, payment, attendance,
   results, and certificate read endpoints.** (Originally only fee/
   payment when this doc was first written — extended in a follow-up
   commit after discovering attendance/results/certificates had *no*
   STUDENT/PARENT role at all, meaning students couldn't read their
   own data.) Still not applied to homework/assignment/timetable
   student-facing reads.
3. **Teacher authorization is module-level, not assignment-scoped** —
   a teacher can currently see/mark attendance for any batch, not just
   ones they're assigned to. Needs a BatchTeacher-based ownership
   check.
4. **MODULE_ROLE_MAP.students/.batches broadening for TEACHER is
   coarse** (grants read AND write) — needs splitting into separate
   read/write role lists, a controller-layer change not attempted this
   phase.
5. **No admin CRUD for Users/Roles/Permissions/Audit Logs**, and no
   backend models at all for CMS/Gallery/Blog/Notices/Analytics — all
   MISSING in the map above, out of scope for Phases 7.1–7.3.
6. Per Phase 7.1/7.2/7.3 notes: `npx prisma generate`/`migrate dev`
   and `npm run lint`/`build` still couldn't be run in this sandbox
   (network egress limitation) — all new files verified with an
   esbuild syntax sweep only.
7. **Test answer leakage fix applied only to the single-test `getById`
   endpoint** — the list endpoint doesn't return question bodies at
   all (Prisma `include` for list queries doesn't fetch `questions`),
   so this was sufficient, but worth confirming if the `Test` list
   query shape ever changes to include questions.
8. **No "submit test attempt" concept exists** — students can browse
   published tests, but there's no `TestAttempt`/scoring model or
   endpoint yet. Test History remains entirely unwired as a result.
